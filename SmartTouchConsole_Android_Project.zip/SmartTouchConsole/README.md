# Smart Touch Console (Huawei Y5 Edition v2.1)

Нативное легковесное Android-приложение (Kotlin, `minSdk = 26`, `targetSdk = 34`), превращающее смартфон **Huawei Y5** (`720×1440 px`, 18:9, Android 8.1 Go / 9 Pie) в настольную сенсорную смарт-консоль управления **Mi TV Stick** (`http://192.168.0.2:8765`) и умным светом **Tuya Smart Life** (`openapi.tuyaeu.com`).

## Ключевые обновления прототипа v2.1:
1. **Сетевой клиент Mi TV Stick без консольного `adb`**:
   - Отправка команд на кастомный лаунчер ТВ (`http://192.168.0.2:8765`):
     - Клавиши: `GET /key?k=DPAD_UP`, `DPAD_DOWN`, `DPAD_LEFT`, `DPAD_RIGHT`, `DPAD_CENTER`, `BACK`, `HOME`, `VOL_UP`, `VOL_DOWN`, `PLAY_PAUSE`.
     - Запуск приложений: `GET /app?pkg=com.google.android.youtube.tv` (Kick, Browser).
     - Передача голоса: `GET /voice?text=...`.
     - Пинг статуса ТВ: быстрая проверка порта 8765 (300 мс) -> «[Экран: ВКЛ]» / «[Экран: СПИТ]».
2. **Синхронизация времени Tuya OpenAPI (фикс ошибок 1004 / 1013)**:
   - Автоматическая калибровка серверного времени (`serverTimeOffsetMs = serverT - System.currentTimeMillis()`) с автоматическим повтором при рассинхроне часов телефона.
   - Точная подпись HMAC-SHA256 без лишних полей: `StringToSign = "$method\n$contentSha256\n\n$path"`.
3. **Запасной голосовой ввод по тапу (для Huawei EMUI Go)**:
   - Если фоновый слушатель `SpeechRecognizer` не поддерживается облегчённой прошивкой EMUI Go, одиночный тап по верхней неоновой полоске (Dynamic Island) вызывает стандартное системное диалоговое окно `ACTION_RECOGNIZE_SPEECH`.

## Структура проекта

```text
SmartTouchConsole/
├── .github/workflows/
│   └── build-apk.yml                # Автосборка APK через GitHub Actions
├── app/
│   ├── build.gradle.kts             # Конфигурация модуля приложения (ViewBinding, Coroutines, OkHttp)
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml      # Портретный полноэкранный режим, KeepScreenOn, права
│       ├── java/com/smartconsole/touch/
│       │   ├── MainActivity.kt      # UI-контроллер, тактильный отклик, пружинная анимация, часы
│       │   ├── network/
│       │   │   ├── MiTvController.kt    # HTTP GET запросы к лаунчеру на 192.168.0.2:8765 (300 мс)
│       │   │   └── TuyaController.kt    # Прямой клиент Tuya OpenAPI v2.0 с автокалибровкой времени
│       │   └── voice/
│       │       └── VoiceAssistantEngine.kt # Фоновый микрофон + маршрутизация ТВ/Телефон
│       └── res/
│           ├── drawable/            # Текстура шлифованного металла Clickpad, матовые капсулы, неоновая линия
│           ├── layout/
│           │   └── activity_main.xml # Фиксированный 100vh макет без скролла под экран 18:9
│           └── values/
│               ├── colors.xml       # Палитра #090A0D, glassmorphism и 6 пресетов Tuya
│               ├── strings.xml
│               └── themes.xml
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/
│   └── gradle-wrapper.properties
└── settings.gradle.kts
```

## Сборка APK
- **В GitHub Actions**: Залейте файлы в репозиторий GitHub -> перейдите в **Actions** -> скачайте готовый `app-debug.apk` из **Artifacts**.
- **Локально**:
  ```bash
  ./gradlew assembleDebug
  ```
