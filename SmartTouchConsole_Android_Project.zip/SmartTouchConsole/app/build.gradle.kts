plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.smartconsole.touch"
    compileSdk = 34

    // Auto-increment versionCode on every build so Android always allows installing over the existing app
    val dynamicVersionCode = ((System.currentTimeMillis() / 1000L) - 1700000000L).toInt().coerceAtLeast(100)

    defaultConfig {
        applicationId = "com.smartconsole.touch"
        minSdk = 26
        targetSdk = 34
        versionCode = dynamicVersionCode
        versionName = "4.2.$dynamicVersionCode"

        vectorDrawables {
            useSupportLibrary = true
        }
    }

    signingConfigs {
        create("consoleKey") {
            storeFile = file("console-signing-key.jks")
            storePassword = "smartconsole123"
            keyAlias = "smartconsole"
            keyPassword = "smartconsole123"
            enableV1Signing = true
            enableV2Signing = true
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("consoleKey")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            signingConfig = signingConfigs.getByName("consoleKey")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    androidResources {
        // Vosk model files must not be compressed / mangled
        noCompress += listOf("fst", "mdl", "int", "conf", "mat", "dubm", "ie", "stats", "carpa", "txt", "bin")
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // Offline always-on wake word + command recognition
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")
}
