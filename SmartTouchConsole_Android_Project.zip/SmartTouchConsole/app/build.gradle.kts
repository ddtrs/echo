plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val runNumber = providers.environmentVariable("GITHUB_RUN_NUMBER").orNull?.toIntOrNull() ?: 1
val dynamicVersionCode = 100 + runNumber
val dynamicVersionName = "4.2.$runNumber"

android {
    namespace = "com.smartconsole.touch"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.smartconsole.touch"
        minSdk = 26
        targetSdk = 34
        versionCode = dynamicVersionCode
        versionName = dynamicVersionName

        vectorDrawables {
            useSupportLibrary = true
        }
    }

    signingConfigs {
        create("consoleSigning") {
            storeFile = file("console-signing-key.jks")
            storePassword = "smartconsole123"
            keyAlias = "smartconsole"
            keyPassword = "smartconsole123"
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("consoleSigning")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("consoleSigning")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
