Offline voice model: put the unpacked vosk-model-small-ru-0.22 folder at app/src/main/assets/model-ru
(GitHub Actions does this automatically). Without it the app falls back to the old SpeechRecognizer loop.
