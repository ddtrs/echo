package com.smartconsole.touch.ui

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView

/**
 * Pure visual behaviour: elastic scale (0.94) on touch.
 * Does not touch click listeners, so existing logic (setOnClickListener) keeps working as is.
 */
internal object SpringPress {
    private const val PRESSED_SCALE = 0.94f

    fun track(view: View, event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> view.animate()
                .scaleX(PRESSED_SCALE).scaleY(PRESSED_SCALE)
                .setDuration(70L)
                .setInterpolator(DecelerateInterpolator())
                .start()

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate()
                .scaleX(1f).scaleY(1f)
                .setDuration(380L)
                .setInterpolator(OvershootInterpolator(3f))
                .start()
        }
    }
}

class SpringImageView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : AppCompatImageView(context, attrs, defStyleAttr) {
    init { isClickable = true }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        SpringPress.track(this, event)
        return super.onTouchEvent(event)
    }
}

class SpringTextView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : AppCompatTextView(context, attrs, defStyleAttr) {
    init { isClickable = true }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        SpringPress.track(this, event)
        return super.onTouchEvent(event)
    }
}

class SpringFrameLayout @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {
    init { isClickable = true }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        SpringPress.track(this, event)
        return super.onTouchEvent(event)
    }
}
