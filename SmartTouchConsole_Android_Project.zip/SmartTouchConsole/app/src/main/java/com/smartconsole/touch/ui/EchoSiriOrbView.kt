package com.smartconsole.touch.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.util.AttributeSet
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.core.graphics.ColorUtils
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Верхний голосовой индикатор-капля (Siri Orb + EchoView):
 * - В покое (expandProgress = 0f): рисует 1-в-1 оригинальную неоновую полоску 180x3dp
 *   с горизонтальным градиентом растворения краёв (#0000F0FF -> #FF00F0FF -> #00FF007F, alpha = 0.28).
 * - При вызове (expandProgress: 0f -> 1f):
 *   1) Сначала быстро сжимает луч по ширине со 180dp до 102dp к центру, собирая свет в ядро,
 *   2) И упруго вытягивает его вниз (3dp -> 96dp) в округлую каплю Siri с тонкой 1dp рамкой,
 *      нижней плазменной волной и маскотом EchoView внутри.
 * - При закрытии (1f -> 0f): втягивает каплю вверх и плавно распускает обратно в 180dp градиентный луч.
 */
class EchoSiriOrbView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr), Choreographer.FrameCallback {

    private val density = resources.displayMetrics.density
    private val scaledDensity = resources.displayMetrics.scaledDensity

    val echoRenderer = EchoView(context)

    var onOrbTapped: (() -> Unit)? = null
    var onOrbLongPressed: (() -> Unit)? = null
    var onOrbPetted: (() -> Unit)? = null

    private var expandProgress = 0f
    private var expandAnimator: ValueAnimator? = null
    private var isExpandedTarget = false

    private var captionText: String = ""
    private var wavePhase = 0f
    private var voiceLevel = 0.22f
    private var targetVoiceLevel = 0.22f

    // Цвета системы и оригинального градиента полоски (bg_neon_line.xml)
    private val cyanColor = Color.parseColor("#00F0FF")
    private val pinkEdgeColor = Color.parseColor("#FF007F")
    private val errorColor = Color.parseColor("#FF5A5F")
    private val orbTopColor = Color.parseColor("#090B10")
    private val orbMidColor = Color.parseColor("#10131C")
    private val orbBottomColor = Color.parseColor("#131722")

    private val shapePath = Path()
    private val wavePath = Path()
    private val orbRect = RectF()
    private val captionRect = RectF()
    private val radii = FloatArray(8)

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.05f * density
    }
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.25f * density
    }
    private val stripGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val captionBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(228, 14, 16, 24)
    }
    private val captionBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f * density
        color = Color.argb(32, 255, 255, 255)
    }
    private val captionTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F5F5F7")
        textSize = 10.5f * scaledDensity
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private var isLoopRunning = false
    private var downX = 0f
    private var downY = 0f
    private var downTimeMs = 0L
    private var longPressTriggered = false
    private var petDistancePx = 0f
    private var lastTouchX = 0f

    private val longPressRunnable = Runnable {
        if (isPressed) {
            longPressTriggered = true
            onOrbLongPressed?.invoke()
        }
    }

    fun setOrbState(mood: EchoView.Mood, caption: String = "", expanded: Boolean = (mood != EchoView.Mood.IDLE)) {
        echoRenderer.mood = mood
        if (caption.isNotEmpty() || !expanded) {
            captionText = caption
        }
        targetVoiceLevel = when (mood) {
            EchoView.Mood.LISTENING, EchoView.Mood.SPEAKING -> 0.78f
            EchoView.Mood.THINKING -> 0.42f
            else -> 0.18f
        }
        animateExpansion(expanded)
        updateAnimationLoop()
        invalidate()
    }

    fun updateVoiceLevel(level: Float) {
        val clamped = level.coerceIn(0f, 1f)
        targetVoiceLevel = clamped
        echoRenderer.targetLevel = clamped
    }

    private fun animateExpansion(expand: Boolean) {
        if (isExpandedTarget == expand && expandAnimator?.isRunning == true) return
        isExpandedTarget = expand
        expandAnimator?.cancel()

        val start = expandProgress
        val end = if (expand) 1f else 0f
        if (abs(start - end) < 0.005f) {
            expandProgress = end
            invalidate()
            return
        }

        expandAnimator = ValueAnimator.ofFloat(start, end).apply {
            duration = if (expand) 540L else 380L
            interpolator = if (expand) OvershootInterpolator(1.14f) else DecelerateInterpolator(1.6f)
            addUpdateListener { anim ->
                expandProgress = (anim.animatedValue as Float).coerceIn(0f, 1.10f)
                invalidate()
            }
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        updateAnimationLoop()
    }

    override fun onDetachedFromWindow() {
        stopAnimationLoop()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        updateAnimationLoop()
    }

    private fun updateAnimationLoop() {
        val shouldRun = isAttachedToWindow && visibility == VISIBLE
        if (shouldRun && !isLoopRunning) {
            isLoopRunning = true
            Choreographer.getInstance().postFrameCallback(this)
        } else if (!shouldRun && isLoopRunning) {
            stopAnimationLoop()
        }
    }

    private fun stopAnimationLoop() {
        if (isLoopRunning) {
            isLoopRunning = false
            Choreographer.getInstance().removeFrameCallback(this)
        }
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!isLoopRunning) return

        val nowMs = SystemClock.elapsedRealtime()
        wavePhase += 0.10f

        val activeVoice = echoRenderer.mood == EchoView.Mood.LISTENING || echoRenderer.mood == EchoView.Mood.SPEAKING
        val desiredAmp = if (activeVoice) {
            max(targetVoiceLevel, 0.45f + 0.38f * abs(sin(nowMs * 0.0075f)))
        } else {
            targetVoiceLevel
        }
        voiceLevel += (desiredAmp - voiceLevel) * 0.16f
        echoRenderer.level = voiceLevel

        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val w = width.toFloat()
        val p = expandProgress.coerceIn(0f, 1f)
        val hitW = lerp(190f * density, 114f * density, p)
        val hitH = lerp(26f * density, 106f * density, p)
        val left = (w - hitW) * 0.5f
        val right = left + hitW

        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            if (event.x < left || event.x > right || event.y > hitH) {
                return false
            }
            isPressed = true
            downX = event.x
            downY = event.y
            lastTouchX = event.x
            petDistancePx = 0f
            downTimeMs = SystemClock.elapsedRealtime()
            longPressTriggered = false
            postDelayed(longPressRunnable, 550L)
            return true
        }

        when (event.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                val dx = abs(event.x - lastTouchX)
                lastTouchX = event.x
                if (expandProgress > 0.6f && event.y < hitH * 0.55f) {
                    petDistancePx += dx
                    if (petDistancePx > 42f * density && echoRenderer.mood != EchoView.Mood.HAPPY) {
                        removeCallbacks(longPressRunnable)
                        longPressTriggered = true
                        petDistancePx = 0f
                        onOrbPetted?.invoke()
                    }
                }
                if (abs(event.x - downX) > 18f * density || abs(event.y - downY) > 18f * density) {
                    removeCallbacks(longPressRunnable)
                }
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPressRunnable)
                isPressed = false
                if (!longPressTriggered && SystemClock.elapsedRealtime() - downTimeMs < 550L) {
                    performClick()
                    onOrbTapped?.invoke()
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPressRunnable)
                isPressed = false
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val vw = width.toFloat()
        val vh = height.toFloat()
        if (vw <= 4f || vh <= 4f) return

        val p = expandProgress.coerceIn(0f, 1.10f)
        val clampedP = p.coerceIn(0f, 1f)
        val isError = echoRenderer.mood == EchoView.Mood.ERROR
        val activeColor = if (isError) errorColor else cyanColor

        // Двухфазная физика морфинга:
        // 1) Сжатие ширины полоски (p = 0.0 -> 0.30): с оригинальных 180dp до 102dp (ширины капли).
        // 2) Вытягивание капли вниз (p = 0.14 -> 1.0): с 3dp до 96dp с выходом Эхо изнутри!
        val stripW = 180f * density
        val stripH = 3.0f * density
        val orbW = 102f * density
        val orbH = 96f * density

        val widthCompressT = (clampedP / 0.30f).coerceIn(0f, 1f)
        val smoothWidthT = widthCompressT * widthCompressT * (3f - 2f * widthCompressT)
        val heightDropT = if (p <= 0.12f) {
            0f
        } else {
            (p - 0.12f) / 0.88f
        }

        val curW = lerp(stripW, orbW, smoothWidthT)
        val curH = lerp(stripH, orbH, heightDropT)
        val topY = lerp(9.5f * density, 2f * density, smoothWidthT)
        val leftX = (vw - curW) * 0.5f
        val rightX = leftX + curW
        val bottomY = topY + curH

        orbRect.set(leftX, topY, rightX, bottomY)

        val dropClamped = heightDropT.coerceIn(0f, 1f)
        val topRadius = lerp(2.0f * density, 16f * density, dropClamped)
        val bottomRadius = lerp(2.0f * density, curW * 0.5f, dropClamped)

        radii[0] = topRadius; radii[1] = topRadius
        radii[2] = topRadius; radii[3] = topRadius
        radii[4] = bottomRadius; radii[5] = bottomRadius
        radii[6] = bottomRadius; radii[7] = bottomRadius

        shapePath.reset()
        shapePath.addRoundRect(orbRect, radii, Path.Direction.CW)

        // 1. Отрисовка оригинального градиентного луча (bg_neon_line.xml: #0000F0FF -> #FF00F0FF -> #00FF007F)
        // В покое (clampedP = 0) прозрачность ровно 0.28f, как в оригинале! При начале сжатия вспыхивает до 0.95f.
        if (dropClamped < 0.28f) {
            val stripVisibility = (1f - (dropClamped / 0.28f)).coerceIn(0f, 1f)
            val baseAlpha = lerp(0.28f, 0.92f, smoothWidthT) * stripVisibility
            val centerAlphaInt = (baseAlpha * 255f).toInt().coerceIn(0, 255)
            // При сжатии края постепенно уплотняются к центру
            val edgeAlphaInt = (baseAlpha * smoothWidthT * 180f).toInt().coerceIn(0, 255)

            stripGlowPaint.shader = LinearGradient(
                leftX, topY, rightX, topY,
                intArrayOf(
                    ColorUtils.setAlphaComponent(cyanColor, edgeAlphaInt),
                    ColorUtils.setAlphaComponent(cyanColor, centerAlphaInt),
                    ColorUtils.setAlphaComponent(pinkEdgeColor, edgeAlphaInt)
                ),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(orbRect, topRadius, topRadius, stripGlowPaint)
            stripGlowPaint.shader = null
        }

        // 2. Отрисовка вытягивающейся округлой капли Siri и выходящего из неё Эхо
        if (dropClamped > 0.02f) {
            val orbOpacity = (dropClamped / 0.22f).coerceIn(0f, 1f)

            canvas.save()
            canvas.clipPath(shapePath)

            fillPaint.shader = LinearGradient(
                0f, topY, 0f, bottomY,
                intArrayOf(
                    ColorUtils.setAlphaComponent(orbTopColor, (255 * orbOpacity).toInt()),
                    ColorUtils.setAlphaComponent(orbMidColor, (255 * orbOpacity).toInt()),
                    ColorUtils.setAlphaComponent(orbBottomColor, (255 * orbOpacity).toInt())
                ),
                floatArrayOf(0f, 0.75f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRect(orbRect, fillPaint)
            fillPaint.shader = null

            val contentAlpha = ((dropClamped - 0.10f) / 0.90f).coerceIn(0f, 1f)
            if (contentAlpha > 0.01f) {
                val glowCenterX = (leftX + rightX) * 0.5f
                val glowCenterY = bottomY + 2f * density
                val glowRadius = max(curW * 0.68f, 10f)

                val glowColors = if (isError) {
                    intArrayOf(
                        ColorUtils.setAlphaComponent(Color.rgb(255, 210, 215), (235 * contentAlpha).toInt()),
                        ColorUtils.setAlphaComponent(errorColor, (180 * contentAlpha).toInt()),
                        ColorUtils.setAlphaComponent(Color.rgb(180, 20, 45), (70 * contentAlpha).toInt()),
                        Color.TRANSPARENT
                    )
                } else {
                    intArrayOf(
                        ColorUtils.setAlphaComponent(Color.rgb(235, 252, 255), (235 * contentAlpha).toInt()),
                        ColorUtils.setAlphaComponent(cyanColor, (190 * contentAlpha).toInt()),
                        ColorUtils.setAlphaComponent(Color.rgb(0, 102, 255), (95 * contentAlpha).toInt()),
                        Color.TRANSPARENT
                    )
                }

                wavePaint.shader = RadialGradient(
                    glowCenterX, glowCenterY, glowRadius,
                    glowColors,
                    floatArrayOf(0f, 0.28f, 0.62f, 1f),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRect(leftX, topY + curH * 0.32f, rightX, bottomY, wavePaint)

                val waveH = (6f + voiceLevel * 9f) * density * contentAlpha
                val baseY = bottomY - 14f * density
                wavePath.reset()
                wavePath.moveTo(leftX, bottomY)
                val steps = 20
                for (i in 0..steps) {
                    val normX = i.toFloat() / steps
                    val x = leftX + normX * curW
                    val env = sin(normX * PI).toFloat()
                    val dy = (sin(normX * 4.5f + wavePhase) * waveH * env) +
                        (cos(normX * 7.2f - wavePhase * 1.3f) * (waveH * 0.42f) * env)
                    wavePath.lineTo(x, baseY - dy)
                }
                wavePath.lineTo(rightX, bottomY)
                wavePath.close()

                wavePaint.shader = LinearGradient(
                    0f, baseY - waveH, 0f, bottomY,
                    if (isError) {
                        intArrayOf(
                            ColorUtils.setAlphaComponent(errorColor, (140 * contentAlpha).toInt()),
                            ColorUtils.setAlphaComponent(Color.WHITE, (210 * contentAlpha).toInt())
                        )
                    } else {
                        intArrayOf(
                            ColorUtils.setAlphaComponent(cyanColor, (150 * contentAlpha).toInt()),
                            ColorUtils.setAlphaComponent(Color.WHITE, (215 * contentAlpha).toInt())
                        )
                    },
                    null,
                    Shader.TileMode.CLAMP
                )
                canvas.drawPath(wavePath, wavePaint)
                wavePaint.shader = null

                // Эхо плавно выплывает сверху вниз из сжавшейся полоски
                canvas.save()
                val echoScale = 0.38f + 0.62f * contentAlpha
                val cx = (leftX + rightX) * 0.5f
                val cy = lerp(topY + 12f * density, topY + curH * 0.46f, contentAlpha)
                canvas.translate(cx, cy)
                canvas.scale(echoScale, echoScale)
                val echoBoxW = curW * 0.88f
                val echoBoxH = orbH * 0.78f
                canvas.translate(-echoBoxW * 0.5f, -echoBoxH * 0.5f)
                echoRenderer.drawEchoToCanvas(canvas, echoBoxW, echoBoxH)
                canvas.restore()
            }

            canvas.restore()

            // Тонкая 1dp рамка в стиль пульта + нижний блик линзы
            borderPaint.color = if (isError) {
                ColorUtils.setAlphaComponent(errorColor, (105 * orbOpacity).toInt())
            } else {
                ColorUtils.setAlphaComponent(Color.WHITE, (34 * orbOpacity).toInt())
            }
            canvas.drawPath(shapePath, borderPaint)

            rimPaint.shader = LinearGradient(
                0f, topY + curH * 0.55f, 0f, bottomY,
                Color.TRANSPARENT,
                ColorUtils.setAlphaComponent(activeColor, (95 * orbOpacity).toInt()),
                Shader.TileMode.CLAMP
            )
            canvas.drawPath(shapePath, rimPaint)
            rimPaint.shader = null
        }

        // 3. Компактная подпись статуса под каплей
        if (dropClamped > 0.60f && captionText.isNotBlank()) {
            val capAlpha = ((dropClamped - 0.60f) / 0.40f).coerceIn(0f, 1f)
            val maxTextW = vw - 24f * density
            val ellipsized = TextUtils.ellipsize(
                captionText,
                captionTextPaint,
                maxTextW,
                TextUtils.TruncateAt.END
            ).toString()

            val textW = captionTextPaint.measureText(ellipsized)
            val padH = 10f * density
            val pillW = (textW + padH * 2f).coerceAtMost(vw - 16f * density)
            val pillH = 20f * density
            val pillTop = bottomY + 4f * density
            val pillLeft = (vw - pillW) * 0.5f

            captionRect.set(pillLeft, pillTop, pillLeft + pillW, pillTop + pillH)
            captionBgPaint.alpha = (225 * capAlpha).toInt()
            captionBorderPaint.color = if (isError) {
                ColorUtils.setAlphaComponent(errorColor, (115 * capAlpha).toInt())
            } else {
                ColorUtils.setAlphaComponent(Color.WHITE, (32 * capAlpha).toInt())
            }
            captionTextPaint.alpha = (245 * capAlpha).toInt()

            val r = pillH * 0.5f
            canvas.drawRoundRect(captionRect, r, r, captionBgPaint)
            canvas.drawRoundRect(captionRect, r, r, captionBorderPaint)

            val fontMetrics = captionTextPaint.fontMetrics
            val textBaseline = captionRect.centerY() - (fontMetrics.ascent + fontMetrics.descent) * 0.5f
            canvas.drawText(ellipsized, captionRect.centerX(), textBaseline, captionTextPaint)
        }
    }

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t
}
