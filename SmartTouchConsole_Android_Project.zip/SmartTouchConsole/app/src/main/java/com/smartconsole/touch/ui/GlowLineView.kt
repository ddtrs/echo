package com.smartconsole.touch.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Invisible at rest. While listening, an ultra-thin cold-white light thread runs along
 * the very top edge with a short voice-like wave, then fades out.
 * API: setListening(true/false)
 */
class GlowLineView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val d = resources.displayMetrics.density
    private val path = Path()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private var phase = 0f
    private var envelope = 0f
    private var shaderW = -1

    private val phaseAnimator = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 900L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }
    private var envelopeAnimator: ValueAnimator? = null

    fun setListening(active: Boolean) {
        envelopeAnimator?.cancel()
        if (active && !phaseAnimator.isRunning) phaseAnimator.start()
        envelopeAnimator = ValueAnimator.ofFloat(envelope, if (active) 1f else 0f).apply {
            duration = if (active) 380L else 750L
            addUpdateListener { envelope = it.animatedValue as Float; invalidate() }
            if (!active) {
                addListener(object : AnimatorListenerAdapter() {
                    private var cancelled = false
                    override fun onAnimationCancel(animation: Animator) { cancelled = true }
                    override fun onAnimationEnd(animation: Animator) {
                        if (!cancelled) { phaseAnimator.cancel(); invalidate() }
                    }
                })
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        phaseAnimator.cancel()
        envelopeAnimator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        if (envelope <= 0.01f) return
        val w = width.toFloat()
        if (w <= 0f) return
        if (shaderW != width) {
            shaderW = width
            val edge = Color.parseColor("#00DCF5FF")
            val core = Color.parseColor("#FFEBFAFF")
            paint.shader = LinearGradient(0f, 0f, w, 0f, intArrayOf(edge, core, edge), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
        }

        val mid = w / 2f
        val y0 = 1.5f * d
        val mod = 0.6f + 0.4f * sin(phase * 3f)
        val amp = 7f * d * envelope * mod

        path.reset()
        var x = 0f
        while (x <= w) {
            val nx = (x - mid) / (w * 0.5f)
            val win = exp(-nx * nx * 3.2f)
            val y = y0 + win * amp * (sin(x * 0.045f / d * 1f - phase) + 0.5f * sin(x * 0.11f / d + phase * 1.3f))
            if (x == 0f) path.moveTo(x, y) else path.lineTo(x, y)
            x += 4f
        }

        // soft halo (layered strokes) + bright thin core
        paint.strokeWidth = 6f * d; paint.alpha = (255 * 0.07f * envelope).toInt(); canvas.drawPath(path, paint)
        paint.strokeWidth = 3f * d; paint.alpha = (255 * 0.16f * envelope).toInt(); canvas.drawPath(path, paint)
        paint.strokeWidth = 1.2f * d; paint.alpha = (255 * envelope).toInt(); canvas.drawPath(path, paint)
    }
}
