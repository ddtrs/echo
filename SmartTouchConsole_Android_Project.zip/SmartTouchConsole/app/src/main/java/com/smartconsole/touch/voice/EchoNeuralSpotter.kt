package com.smartconsole.touch.voice

import android.content.Context
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * On-Device Neural Keyword Spotter + Self-Learning Voiceprint Engine ("Эй Эхо" / "Эхо"):
 *  1. Computes 32-band Log-Mel Spectrogram frames (50 ms hop, 24 frames = 1.2s window) with
 *     per-window Z-score normalization (distance-invariant from 0.3m to 5m).
 *  2. Runs the 3-layer Neural Network (`echo_neural_kws.bin`, 768 -> 128 -> 64 -> 1) trained in
 *     GitHub Actions on Russian & Ukrainian neural speech + far-field room reverb + hard negatives.
 *  3. On-Device Self-Learning (`echo_voice_memory.bin`):
 *     - Positive Voiceprints (`positivePrints`): learns your exact voice + room acoustics when you
 *       either run 3-phrase calibration OR automatically whenever a wake-up is followed by a real command.
 *     - Negative Anti-Prints (`negativePrints`): automatically blacklists false-trigger sounds from the TV
 *       whenever a wake window expires without a valid command.
 */
class EchoNeuralSpotter(private val context: Context) {

    companion object {
        private const val SR = 16000
        private const val N_FFT = 512
        private const val WIN_LEN = 400     // 25 ms
        private const val HOP_LEN = 800     // 50 ms
        private const val N_MELS = 32
        private const val N_FRAMES = 24     // 1.20 s window
        private const val FEAT_DIM = N_FRAMES * N_MELS // 768
        private const val PRINT_DIM = 128   // 64 neural embedding + 64 temporal Mel-contour
        private const val MAX_POS_PRINTS = 30
        private const val MAX_NEG_PRINTS = 40
    }

    private val w1 = FloatArray(FEAT_DIM * 128)
    private val b1 = FloatArray(128)
    private val w2 = FloatArray(128 * 64)
    private val b2 = FloatArray(64)
    private val w3 = FloatArray(64)
    private var b3 = 0f
    private val protoPos = FloatArray(64)
    private val protoNeg = FloatArray(64)
    @Volatile var modelLoaded = false
        private set

    private val melFb: Array<FloatArray> = buildMelFilterbank()
    private val hamming = FloatArray(WIN_LEN) { i ->
        (0.54 - 0.46 * cos(2.0 * PI * i / (WIN_LEN - 1))).toFloat()
    }

    // Ring of last 24 Mel frames (each 32 floats)
    private val melRing = Array(N_FRAMES) { FloatArray(N_MELS) }
    private var melWritePos = 0
    private var melFramesFilled = 0

    // Pre-allocated buffers for zero-GC inference in the audio loop
    private val fftReal = FloatArray(N_FFT)
    private val fftImag = FloatArray(N_FFT)
    private val powerSpec = FloatArray(N_FFT / 2 + 1)
    private val normWindow = FloatArray(FEAT_DIM)
    private val h1Buf = FloatArray(128)
    private val embBuf = FloatArray(64)
    private var lastFeaturePrint = FloatArray(PRINT_DIM)

    private val positivePrints = CopyOnWriteArrayList<FloatArray>()
    private val negativePrints = CopyOnWriteArrayList<FloatArray>()
    private val memoryFile = File(context.filesDir, "echo_voice_memory.bin")

    val learnedPositiveCount: Int get() = positivePrints.size
    val learnedNegativeCount: Int get() = negativePrints.size

    init {
        loadNeuralWeightsFromAssets()
        loadSelfLearnedMemory()
    }

    private fun hzToMel(hz: Double): Double = 2595.0 * log10(1.0 + hz / 700.0)
    private fun melToHz(mel: Double): Double = 700.0 * (Math.pow(10.0, mel / 2595.0) - 1.0)

    private fun buildMelFilterbank(): Array<FloatArray> {
        val lowMel = hzToMel(130.0)
        val highMel = hzToMel(6800.0)
        val melPoints = DoubleArray(N_MELS + 2) { i ->
            lowMel + (highMel - lowMel) * i / (N_MELS + 1)
        }
        val binPoints = IntArray(N_MELS + 2) { i ->
            ((N_FFT + 1) * melToHz(melPoints[i]) / SR).toInt()
        }
        return Array(N_MELS) { m ->
            val row = FloatArray(N_FFT / 2 + 1)
            val fmMinus = binPoints[m]
            val fm = binPoints[m + 1]
            val fmPlus = binPoints[m + 2]
            for (k in fmMinus until fm) {
                if (fm > fmMinus && k in row.indices) {
                    row[k] = (k - fmMinus).toFloat() / (fm - fmMinus).toFloat()
                }
            }
            for (k in fm until fmPlus) {
                if (fmPlus > fm && k in row.indices) {
                    row[k] = (fmPlus - k).toFloat() / (fmPlus - fm).toFloat()
                }
            }
            row
        }
    }

    private fun loadNeuralWeightsFromAssets() {
        try {
            val bytes = context.assets.open("echo_neural_kws.bin").use { it.readBytes() }
            val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            val magic = buf.int
            val version = buf.int
            if (magic != 0x4543484F || version != 1) return
            for (i in w1.indices) w1[i] = buf.float
            for (i in b1.indices) b1[i] = buf.float
            for (i in w2.indices) w2[i] = buf.float
            for (i in b2.indices) b2[i] = buf.float
            for (i in w3.indices) w3[i] = buf.float
            b3 = buf.float
            for (i in protoPos.indices) protoPos[i] = buf.float
            for (i in protoNeg.indices) protoNeg[i] = buf.float
            modelLoaded = true
        } catch (_: Exception) {
            modelLoaded = false
        }
    }

    /**
     * Feeds a 100ms (1600 samples) pre-filtered audio chunk ( adds 2 frames of 50ms each)
     * and returns the neural + self-learning wake confidence score in 0.0f .. 1.0f.
     */
    fun processChunk100ms(samples: ShortArray, count: Int): Float {
        if (count < 1600) return 0f
        pushMelFrame(samples, 0)
        pushMelFrame(samples, 800)
        if (melFramesFilled < N_FRAMES) return 0f
        return evaluateWindow()
    }

    private fun pushMelFrame(samples: ShortArray, offset: Int) {
        for (i in 0 until N_FFT) {
            fftReal[i] = if (i < WIN_LEN && offset + i < samples.size) {
                (samples[offset + i].toFloat() / 32768f) * hamming[i]
            } else {
                0f
            }
            fftImag[i] = 0f
        }
        fft512(fftReal, fftImag)
        for (k in 0..(N_FFT / 2)) {
            val re = fftReal[k]
            val im = fftImag[k]
            powerSpec[k] = re * re + im * im
        }
        val dest = melRing[melWritePos]
        for (m in 0 until N_MELS) {
            val fbRow = melFb[m]
            var sum = 0f
            for (k in 0..(N_FFT / 2)) {
                val w = fbRow[k]
                if (w != 0f) sum += w * powerSpec[k]
            }
            dest[m] = ln(max(sum, 1e-7f))
        }
        melWritePos = (melWritePos + 1) % N_FRAMES
        if (melFramesFilled < N_FRAMES) melFramesFilled++
    }

    private fun evaluateWindow(): Float {
        // 1. Flatten 24x32 ring in chronological order and Z-normalize
        var sum = 0f
        var idx = 0
        for (f in 0 until N_FRAMES) {
            val frame = melRing[(melWritePos + f) % N_FRAMES]
            for (m in 0 until N_MELS) {
                val v = frame[m]
                normWindow[idx++] = v
                sum += v
            }
        }
        val mean = sum / FEAT_DIM
        var sqSum = 0f
        for (i in 0 until FEAT_DIM) {
            val d = normWindow[i] - mean
            normWindow[i] = d
            sqSum += d * d
        }
        val std = sqrt(sqSum / FEAT_DIM + 1e-5f)
        for (i in 0 until FEAT_DIM) {
            normWindow[i] /= std
        }

        // 2. Neural forward pass: 768 -> 128 -> 64 -> 1
        var baseProb = 0.5f
        if (modelLoaded) {
            for (j in 0 until 128) {
                var acc = b1[j]
                var wIdx = j
                for (i in 0 until FEAT_DIM) {
                    acc += normWindow[i] * w1[wIdx]
                    wIdx += 128
                }
                h1Buf[j] = if (acc > 0f) acc else 0f
            }
            var embNormSq = 0f
            for (k in 0 until 64) {
                var acc = b2[k]
                var wIdx = k
                for (j in 0 until 128) {
                    acc += h1Buf[j] * w2[wIdx]
                    wIdx += 64
                }
                val v = if (acc > 0f) acc else 0f
                embBuf[k] = v
                embNormSq += v * v
            }
            val invNorm = 1f / sqrt(embNormSq + 1e-6f)
            var logit = b3
            for (k in 0 until 64) {
                embBuf[k] *= invNorm
                logit += embBuf[k] * w3[k]
            }
            val clamped = logit.coerceIn(-15f, 15f)
            baseProb = 1f / (1f + exp(-clamped))
        }

        // 3. Build 128-dim combined voiceprint (64 neural embedding + 64 pooled Mel-contour)
        val print = FloatArray(PRINT_DIM)
        for (i in 0 until 64) {
            print[i] = embBuf[i]
        }
        // Pool 768 Mel features into 64 temporal-spectral blocks of 12
        for (b in 0 until 64) {
            var s = 0f
            val base = b * 12
            for (k in 0 until 12) s += normWindow[base + k]
            print[64 + b] = s / 12f
        }
        normalizeL2(print)
        lastFeaturePrint = print

        // 4. Check Negative Anti-Prints (TV false-trigger blacklist)
        var maxNegSim = -1f
        for (neg in negativePrints) {
            val sim = cosineSim(print, neg)
            if (sim > maxNegSim) maxNegSim = sim
        }
        if (maxNegSim >= 0.87f) {
            return 0f // Hard-blocked by self-learned negative memory!
        }

        // 5. Check Positive Personal Voiceprints (user voice + room reverb memory)
        var maxPosSim = -1f
        for (pos in positivePrints) {
            val sim = cosineSim(print, pos)
            if (sim > maxPosSim) maxPosSim = sim
        }

        return when {
            maxPosSim >= 0.80f -> max(baseProb, 0.88f)
            maxPosSim >= 0.72f -> (baseProb * 0.55f + maxPosSim * 0.45f).coerceIn(0f, 1f)
            else -> baseProb
        }
    }

    /** Captures a snapshot of the current 128-dim voiceprint at the moment of wake detection. */
    fun snapshotCurrentPrint(): FloatArray = lastFeaturePrint.copyOf()

    /**
     * Self-Learning Positive: called when a wake-up was followed by a real command (or during manual voice calibration).
     */
    fun learnPositive(print: FloatArray = lastFeaturePrint) {
        val copy = print.copyOf()
        normalizeL2(copy)
        // If very close to an existing positive print, blend via EMA so it refines rather than duplicates
        for (i in 0 until positivePrints.size) {
            val existing = positivePrints[i]
            if (cosineSim(existing, copy) >= 0.88f) {
                for (k in existing.indices) existing[k] = existing[k] * 0.7f + copy[k] * 0.3f
                normalizeL2(existing)
                saveSelfLearnedMemory()
                return
            }
        }
        if (positivePrints.size >= MAX_POS_PRINTS) {
            positivePrints.removeAt(0)
        }
        positivePrints.add(copy)
        saveSelfLearnedMemory()
    }

    /**
     * Self-Learning Negative: called when a wake-up turned out to be a false alarm (no valid command spoken).
     */
    fun learnNegative(print: FloatArray = lastFeaturePrint) {
        val copy = print.copyOf()
        normalizeL2(copy)
        // Never blacklist a sound that strongly matches a confirmed positive user voiceprint
        for (pos in positivePrints) {
            if (cosineSim(pos, copy) >= 0.84f) return
        }
        if (negativePrints.size >= MAX_NEG_PRINTS) {
            negativePrints.removeAt(0)
        }
        negativePrints.add(copy)
        saveSelfLearnedMemory()
    }

    fun clearLearnedMemory() {
        positivePrints.clear()
        negativePrints.clear()
        try { memoryFile.delete() } catch (_: Exception) {}
    }

    private fun saveSelfLearnedMemory() {
        try {
            DataOutputStream(memoryFile.outputStream().buffered()).use { out ->
                out.writeInt(0x454D454D)
                out.writeInt(positivePrints.size)
                for (p in positivePrints) {
                    for (v in p) out.writeFloat(v)
                }
                out.writeInt(negativePrints.size)
                for (n in negativePrints) {
                    for (v in n) out.writeFloat(v)
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun loadSelfLearnedMemory() {
        if (!memoryFile.exists()) return
        try {
            DataInputStream(memoryFile.inputStream().buffered()).use { inp ->
                if (inp.readInt() != 0x454D454D) return
                val posCount = inp.readInt().coerceIn(0, MAX_POS_PRINTS)
                positivePrints.clear()
                repeat(posCount) {
                    val arr = FloatArray(PRINT_DIM) { inp.readFloat() }
                    positivePrints.add(arr)
                }
                val negCount = inp.readInt().coerceIn(0, MAX_NEG_PRINTS)
                negativePrints.clear()
                repeat(negCount) {
                    val arr = FloatArray(PRINT_DIM) { inp.readFloat() }
                    negativePrints.add(arr)
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun normalizeL2(v: FloatArray) {
        var sq = 0f
        for (x in v) sq += x * x
        val inv = 1f / sqrt(sq + 1e-6f)
        for (i in v.indices) v[i] *= inv
    }

    private fun cosineSim(a: FloatArray, b: FloatArray): Float {
        var dot = 0f
        for (i in a.indices) dot += a[i] * b[i]
        return dot
    }

    /** In-place 512-point radix-2 Cooley-Tukey FFT (zero allocations). */
    private fun fft512(real: FloatArray, imag: FloatArray) {
        val n = N_FFT
        var j = 0
        for (i in 0 until n) {
            if (i < j) {
                val tr = real[i]; real[i] = real[j]; real[j] = tr
                val ti = imag[i]; imag[i] = imag[j]; imag[j] = ti
            }
            var m = n shr 1
            while (m >= 1 && j >= m) {
                j -= m
                m = m shr 1
            }
            j += m
        }
        var len = 2
        while (len <= n) {
            val half = len shr 1
            val ang = (-2.0 * PI / len)
            val wlenRe = cos(ang).toFloat()
            val wlenIm = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var wRe = 1f
                var wIm = 0f
                for (k in 0 until half) {
                    val uRe = real[i + k]
                    val uIm = imag[i + k]
                    val vRe = real[i + k + half] * wRe - imag[i + k + half] * wIm
                    val vIm = real[i + k + half] * wIm + imag[i + k + half] * wRe
                    real[i + k] = uRe + vRe
                    imag[i + k] = uIm + vIm
                    real[i + k + half] = uRe - vRe
                    imag[i + k + half] = uIm - vIm
                    val nextWRe = wRe * wlenRe - wIm * wlenIm
                    wIm = wRe * wlenIm + wIm * wlenRe
                    wRe = nextWRe
                }
                i += len
            }
            len = len shl 1
        }
    }
}
