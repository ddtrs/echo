package com.smartconsole.touch.network

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.Certificate
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.util.Date
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager
import javax.security.auth.x500.X500Principal

/**
 * Minimal Protobuf writer (only what the Android TV Remote v2 protocol needs).
 */
internal class PbWriter {
    private val out = ByteArrayOutputStream()

    fun varint(field: Int, value: Long): PbWriter {
        writeVarint((field shl 3).toLong())
        writeVarint(value)
        return this
    }

    fun bytes(field: Int, data: ByteArray): PbWriter {
        writeVarint(((field shl 3) or 2).toLong())
        writeVarint(data.size.toLong())
        out.write(data)
        return this
    }

    fun string(field: Int, value: String): PbWriter = bytes(field, value.toByteArray(Charsets.UTF_8))

    fun message(field: Int, block: PbWriter.() -> Unit): PbWriter =
        bytes(field, PbWriter().apply(block).toByteArray())

    fun toByteArray(): ByteArray = out.toByteArray()

    private fun writeVarint(value: Long) {
        var x = value
        while ((x and 0x7FL.inv()) != 0L) {
            out.write(((x and 0x7FL) or 0x80L).toInt())
            x = x ushr 7
        }
        out.write(x.toInt())
    }
}

internal class PbField(val num: Int, val wire: Int, val number: Long, val data: ByteArray?)

internal fun parsePb(data: ByteArray): List<PbField> {
    val result = ArrayList<PbField>()
    var i = 0
    fun readVarint(): Long {
        var shift = 0
        var value = 0L
        while (i < data.size) {
            val b = data[i++].toInt() and 0xFF
            value = value or ((b and 0x7F).toLong() shl shift)
            if ((b and 0x80) == 0) break
            shift += 7
        }
        return value
    }
    while (i < data.size) {
        val tag = readVarint().toInt()
        val num = tag ushr 3
        when (val wire = tag and 7) {
            0 -> result.add(PbField(num, wire, readVarint(), null))
            2 -> {
                val len = readVarint().toInt()
                if (len < 0 || i + len > data.size) return result
                result.add(PbField(num, wire, 0L, data.copyOfRange(i, i + len)))
                i += len
            }
            1 -> { i += 8 }
            5 -> { i += 4 }
            else -> return result
        }
    }
    return result
}

/**
 * Native client for the Google "Android TV Remote Service" protocol v2
 * (the same one the official Google TV app uses):
 *   - port 6467: one-time pairing with a 6-digit code shown on the TV
 *   - port 6466: persistent TLS connection that accepts key events, app links, pings
 *
 * The client certificate lives in the AndroidKeyStore, so pairing survives app restarts.
 * TV certificates are self-signed, so the server certificate is not validated
 * (traffic stays inside the local network).
 */
class AtvRemoteClient(context: Context) {

    enum class SendResult { OK, UNPAIRED, UNREACHABLE }

    companion object {
        private const val PAIR_PORT = 6467
        private const val REMOTE_PORT = 6466
        private const val KEY_ALIAS = "smart_console_atv_client"
        private const val CLIENT_NAME = "Smart Touch Console"
        private const val FEATURES = 622L
        private const val PREF_PAIRED = "atv_paired"
    }

    private val prefs = context.applicationContext
        .getSharedPreferences("smart_console_prefs", Context.MODE_PRIVATE)

    var isPaired: Boolean
        get() = prefs.getBoolean(PREF_PAIRED, false)
        private set(value) { prefs.edit().putBoolean(PREF_PAIRED, value).apply() }

    @Volatile private var pairingSocket: SSLSocket? = null
    @Volatile private var remoteSocket: SSLSocket? = null
    @Volatile private var remoteIp: String = ""
    @Volatile private var configLatch: CountDownLatch = CountDownLatch(1)
    private val writeLock = Any()
    private val connectLock = Any()

    val isConnected: Boolean
        get() = remoteSocket?.let { !it.isClosed && it.isConnected } == true

    // ------------------------------------------------------------------ TLS

    private fun keyStore(): KeyStore {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias(KEY_ALIAS)) {
            val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore")
            val spec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
            )
                .setKeySize(2048)
                .setDigests(
                    KeyProperties.DIGEST_SHA256,
                    KeyProperties.DIGEST_SHA1,
                    KeyProperties.DIGEST_NONE
                )
                .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
                .setCertificateSubject(X500Principal("CN=smart-touch-console"))
                .setCertificateSerialNumber(BigInteger.valueOf(System.currentTimeMillis()))
                .setCertificateNotBefore(Date(System.currentTimeMillis() - 86_400_000L))
                .setCertificateNotAfter(Date(System.currentTimeMillis() + 20L * 365 * 86_400_000L))
                .build()
            kpg.initialize(spec)
            kpg.generateKeyPair()
        }
        return ks
    }

    private fun openTls(ip: String, port: Int): SSLSocket {
        val ks = keyStore()
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, null)
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val ctx = SSLContext.getInstance("TLSv1.2")
        ctx.init(kmf.keyManagers, arrayOf(trustAll), SecureRandom())
        val socket = ctx.socketFactory.createSocket() as SSLSocket
        socket.tcpNoDelay = true
        socket.connect(InetSocketAddress(ip, port), 2500)
        socket.soTimeout = 6000
        socket.startHandshake()
        return socket
    }

    // ------------------------------------------------------------ Framing

    private fun sendFrame(out: OutputStream, payload: ByteArray) {
        val frame = ByteArrayOutputStream()
        var len = payload.size
        while ((len and 0x7F.inv()) != 0) {
            frame.write((len and 0x7F) or 0x80)
            len = len ushr 7
        }
        frame.write(len)
        frame.write(payload)
        synchronized(writeLock) {
            out.write(frame.toByteArray())
            out.flush()
        }
    }

    private fun readFrame(input: InputStream): ByteArray? {
        var len = 0
        var shift = 0
        while (true) {
            val b = input.read()
            if (b < 0) return null
            len = len or ((b and 0x7F) shl shift)
            if ((b and 0x80) == 0) break
            shift += 7
            if (shift > 28) return null
        }
        val buf = ByteArray(len)
        var read = 0
        while (read < len) {
            val n = input.read(buf, read, len - read)
            if (n < 0) return null
            read += n
        }
        return buf
    }

    // ------------------------------------------------------------ Pairing

    private fun pairMsg(block: PbWriter.() -> Unit): ByteArray =
        PbWriter().apply {
            varint(1, 2)      // protocol_version
            varint(2, 200)    // status OK
            block()
        }.toByteArray()

    private fun expectPairField(input: InputStream, field: Int) {
        val frame = readFrame(input) ?: error("TV closed connection")
        val fields = parsePb(frame)
        val status = fields.firstOrNull { it.num == 2 }?.number ?: 200L
        check(status == 200L) { "Pairing status $status" }
        check(fields.any { it.num == field }) { "Unexpected pairing reply" }
    }

    /** Step 1: connect to the TV and make it show the 6-character code. */
    suspend fun beginPairing(ip: String): Boolean = withContext(Dispatchers.IO) {
        closePairing()
        try {
            val socket = openTls(ip, PAIR_PORT)
            val out = socket.outputStream
            val inp = socket.inputStream

            sendFrame(out, pairMsg {
                message(10) { string(1, "atvremote"); string(2, CLIENT_NAME) }
            })
            expectPairField(inp, 11)

            sendFrame(out, pairMsg {
                message(20) {
                    message(1) { varint(1, 3); varint(2, 6) }   // HEXADECIMAL, 6 symbols
                    varint(3, 1)                                  // role INPUT
                }
            })
            expectPairField(inp, 20)

            sendFrame(out, pairMsg {
                message(30) {
                    message(1) { varint(1, 3); varint(2, 6) }
                    varint(2, 1)
                }
            })
            expectPairField(inp, 31)

            pairingSocket = socket
            true
        } catch (_: Exception) {
            closePairing()
            false
        }
    }

    /** Step 2: send the code the user read from the TV screen. */
    suspend fun finishPairing(code: String): Boolean = withContext(Dispatchers.IO) {
        val socket = pairingSocket ?: return@withContext false
        try {
            val cleaned = code.trim().uppercase()
            if (!Regex("^[0-9A-F]{6}$").matches(cleaned)) return@withContext false
            val codeBytes = ByteArray(3) { cleaned.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

            val clientCert: Certificate = keyStore().getCertificate(KEY_ALIAS)
            val serverCert: Certificate = socket.session.peerCertificates[0]
            val clientKey = clientCert.publicKey as RSAPublicKey
            val serverKey = serverCert.publicKey as RSAPublicKey

            val sha = MessageDigest.getInstance("SHA-256")
            sha.update(hexBytes(clientKey.modulus))
            sha.update(hexBytes(clientKey.publicExponent))
            sha.update(hexBytes(serverKey.modulus))
            sha.update(hexBytes(serverKey.publicExponent))
            sha.update(codeBytes.copyOfRange(1, codeBytes.size))
            val hash = sha.digest()
            if (hash[0] != codeBytes[0]) return@withContext false   // wrong code

            sendFrame(socket.outputStream, pairMsg {
                message(40) { bytes(1, hash) }
            })
            expectPairField(socket.inputStream, 41)
            isPaired = true
            closePairing()
            true
        } catch (_: Exception) {
            closePairing()
            false
        }
    }

    private fun hexBytes(n: BigInteger): ByteArray {
        var hex = n.toString(16)
        if (hex.length % 2 != 0) hex = "0$hex"
        return ByteArray(hex.length / 2) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    fun closePairing() {
        try { pairingSocket?.close() } catch (_: Exception) {}
        pairingSocket = null
    }

    // ------------------------------------------------------------- Remote

    private fun connectRemote(ip: String): SendResult = synchronized(connectLock) {
        if (isConnected && remoteIp == ip) return SendResult.OK
        disconnect()
        if (!isPaired) return SendResult.UNPAIRED
        try {
            val socket = openTls(ip, REMOTE_PORT)
            socket.soTimeout = 0
            remoteSocket = socket
            remoteIp = ip
            configLatch = CountDownLatch(1)
            val latch = configLatch
            startReader(socket, latch)
            val ok = latch.await(3, TimeUnit.SECONDS)
            if (!ok) {
                val closed = socket.isClosed
                disconnect()
                if (closed) {
                    // TV dropped us right after the handshake -> it forgot our certificate
                    isPaired = false
                    return SendResult.UNPAIRED
                }
                return SendResult.UNREACHABLE
            }
            SendResult.OK
        } catch (_: Exception) {
            disconnect()
            SendResult.UNREACHABLE
        }
    }

    private fun startReader(socket: SSLSocket, latch: CountDownLatch) {
        Thread {
            try {
                val inp = socket.inputStream
                val out = socket.outputStream
                while (true) {
                    val frame = readFrame(inp) ?: break
                    for (f in parsePb(frame)) {
                        when (f.num) {
                            1 -> { // TV remote_configure -> answer with our device info
                                sendFrame(out, PbWriter().message(1) {
                                    varint(1, FEATURES)
                                    message(2) {
                                        string(1, "Smart Touch Console")
                                        string(2, "Smart Touch")
                                        varint(3, 1)
                                        string(4, "1")
                                        string(5, "com.smartconsole.touch")
                                        string(6, "1.0.0")
                                    }
                                }.toByteArray())
                            }
                            2 -> { // TV remote_set_active -> activate
                                sendFrame(out, PbWriter().message(2) { varint(1, FEATURES) }.toByteArray())
                                latch.countDown()
                            }
                            8 -> { // ping request -> pong
                                val v = f.data?.let { parsePb(it).firstOrNull { p -> p.num == 1 }?.number } ?: 0L
                                sendFrame(out, PbWriter().message(9) { varint(1, v) }.toByteArray())
                            }
                            3 -> { /* remote_error: ignore, connection will be retried */ }
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                try { socket.close() } catch (_: Exception) {}
                if (remoteSocket === socket) remoteSocket = null
            }
        }.apply { isDaemon = true; name = "atv-remote-reader" }.start()
    }

    fun disconnect() {
        try { remoteSocket?.close() } catch (_: Exception) {}
        remoteSocket = null
    }

    private fun writeRemote(payload: ByteArray): Boolean {
        val socket = remoteSocket ?: return false
        return try {
            sendFrame(socket.outputStream, payload)
            true
        } catch (_: Exception) {
            disconnect()
            false
        }
    }

    private fun sendWithReconnect(ip: String, payload: ByteArray): SendResult {
        var result = connectRemote(ip)
        if (result != SendResult.OK) return result
        if (writeRemote(payload)) return SendResult.OK
        result = connectRemote(ip)
        if (result != SendResult.OK) return result
        return if (writeRemote(payload)) SendResult.OK else SendResult.UNREACHABLE
    }

    /** Short key press (like pressing a button on the physical remote). */
    suspend fun sendKey(androidKeyCode: Int, ip: String): SendResult = withContext(Dispatchers.IO) {
        val payload = PbWriter().message(10) {
            varint(1, androidKeyCode.toLong())
            varint(2, 3) // SHORT
        }.toByteArray()
        sendWithReconnect(ip, payload)
    }

    /** Opens an app via deep link (e.g. https://www.youtube.com). */
    suspend fun openAppLink(link: String, ip: String): SendResult = withContext(Dispatchers.IO) {
        val payload = PbWriter().message(90) { string(1, link) }.toByteArray()
        sendWithReconnect(ip, payload)
    }

    /** Pre-opens the connection so the first tap has no connect delay. */
    suspend fun warmUp(ip: String): SendResult = withContext(Dispatchers.IO) { connectRemote(ip) }
}
