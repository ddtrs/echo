package com.smartconsole.touch.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * Ergonomic Brushed-Metal Touch Clickpad View (222dp) with:
 * 1. 3D Mechanical Pivot Tilt: pressing UP, DOWN, LEFT, RIGHT physically tilts and depresses
 *    the disc in 3D space toward the pressed edge (`rotationX`, `rotationY`, `translation`),
 *    springing back on release.
 * 2. Sleek Bang & Olufsen / Hi-Fi Rotary Jog Dial:
 *    - Thin graduated cyan-silver arc trail + precision radial tick mark (no bulky dots).
 *    - Displays real synchronized TV volume percentage (`47%`) in the center while turning.
 */
class TouchClickpadView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class Zone { NONE, CENTER, UP, DOWN, LEFT, RIGHT }

    var onZoneClicked: ((Zone) -> Unit)? = null
    var onZonePressedHaptic: (() -> Unit)? = null
    var onVolumeRotaryStep: ((Int) -> Unit)? = null // +1 for Vol Up (CW), -1 for Vol Down (CCW)

    /** Real synchronized TV volume percentage (0..100). */
    var volumePercent: Int = 45
        set(value) {
            field = value.coerceIn(0, 100)
            if (isRotatingVolume) invalidate()
        }

    private var activeZone: Zone = Zone.NONE
    private var isRotatingVolume: Boolean = false
    private var lastTouchAngleDeg: Float = 0f
    private var accumulatedRotationDeg: Float = 0f
    private var currentRotaryIndicatorDeg: Float = -90f

    private val outerRect = RectF()
    private val rotaryArcRect = RectF()

    private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        color = Color.parseColor("#2EFFFFFF")
    }
    private val groovePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        color = Color.parseColor("#14FFFFFF")
    }
    // Zero cheap blue/cyan fill: disk stays solid pure brushed dark metal
    private val subtleHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#0DFFFFFF") // ultra-subtle sheen only
    }
    // Thin precision track & sleek arc for rotary volume
    private val rotaryTrackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        color = Color.parseColor("#1FFFFFFF")
    }
    private val rotaryArcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#E600F0FF")
    }
    private val rotaryTickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#F5F7FA")
    }
    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val centerBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.2f
        color = Color.parseColor("#38FFFFFF")
    }
    private val chevronPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4.2f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.parseColor("#B8C0D4")
    }
    private val okTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F5F7FA")
        textSize = 40f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val volSubPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8C93A4")
        textSize = 20f
        textAlign = Paint.Align.CENTER
        letterSpacing = 0.12f
    }

    init {
        // Set camera distance for realistic 3D perspective tilt
        val density = resources.displayMetrics.density
        cameraDistance = 4200f * density
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        val r = min(cx, cy) - 6f
        outerRect.set(cx - r, cy - r, cx + r, cy + r)
        val arcR = r * 0.91f
        rotaryArcRect.set(cx - arcR, cy - arcR, cx + arcR, cy + arcR)

        discPaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(
                Color.parseColor("#141720"),
                Color.parseColor("#232838"),
                Color.parseColor("#141720"),
                Color.parseColor("#232838"),
                Color.parseColor("#141720")
            ),
            null
        )

        centerPaint.shader = RadialGradient(
            cx, cy, r * 0.40f,
            Color.parseColor("#2A3042"),
            Color.parseColor("#171A24"),
            Shader.TileMode.CLAMP
        )
        okTextPaint.textSize = r * 0.155f
        volSubPaint.textSize = r * 0.075f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val outerR = min(cx, cy) - 6f
        val centerR = outerR * 0.39f

        // 1. Base brushed metal disc
        canvas.drawCircle(cx, cy, outerR, discPaint)
        canvas.drawCircle(cx, cy, outerR, borderPaint)

        // Concentric machined grooves
        canvas.drawCircle(cx, cy, outerR * 0.84f, groovePaint)
        canvas.drawCircle(cx, cy, outerR * 0.68f, groovePaint)

        // 2. Rotary volume mode: sleek ultra-thin progress ring from top (-90 deg) + radial tick mark
        if (isRotatingVolume) {
            canvas.drawCircle(cx, cy, outerR * 0.91f, rotaryTrackPaint)
            val sweepAngle = (volumePercent / 100f) * 360f
            canvas.drawArc(
                rotaryArcRect,
                -90f,
                sweepAngle,
                false,
                rotaryArcPaint
            )
            // Sleek radial metallic-white tick line at current finger angle
            val rad = Math.toRadians((-90f + sweepAngle).toDouble())
            val innerTickR = outerR * 0.86f
            val outerTickR = outerR * 0.955f
            val x1 = cx + innerTickR * cos(rad).toFloat()
            val y1 = cy + innerTickR * sin(rad).toFloat()
            val x2 = cx + outerTickR * cos(rad).toFloat()
            val y2 = cy + outerTickR * sin(rad).toFloat()
            canvas.drawLine(x1, y1, x2, y2, rotaryTickPaint)
        }

        // 3. Draw 4 crisp vector chevrons on the ring (shift slightly toward pressed edge for depth)
        val chevDist = outerR * 0.69f
        val chevSize = outerR * 0.062f
        val pressOffset = outerR * 0.018f
        drawChevron(
            canvas,
            cx,
            cy - chevDist - (if (activeZone == Zone.UP) pressOffset else 0f),
            chevSize,
            0f,
            !isRotatingVolume && activeZone == Zone.UP
        )
        drawChevron(
            canvas,
            cx,
            cy + chevDist + (if (activeZone == Zone.DOWN) pressOffset else 0f),
            chevSize,
            180f,
            !isRotatingVolume && activeZone == Zone.DOWN
        )
        drawChevron(
            canvas,
            cx - chevDist - (if (activeZone == Zone.LEFT) pressOffset else 0f),
            cy,
            chevSize,
            270f,
            !isRotatingVolume && activeZone == Zone.LEFT
        )
        drawChevron(
            canvas,
            cx + chevDist + (if (activeZone == Zone.RIGHT) pressOffset else 0f),
            cy,
            chevSize,
            90f,
            !isRotatingVolume && activeZone == Zone.RIGHT
        )

        // 4. Center OK button with spring scale (or real Volume % while rotating)
        val okScale = if (!isRotatingVolume && activeZone == Zone.CENTER) 0.90f else 1.0f
        canvas.save()
        canvas.scale(okScale, okScale, cx, cy)
        canvas.drawCircle(cx, cy, centerR, centerPaint)
        canvas.drawCircle(cx, cy, centerR, centerBorderPaint)

        if (isRotatingVolume) {
            val pctText = "$volumePercent%"
            val textY = cy - (okTextPaint.descent() + okTextPaint.ascent()) / 2f - outerR * 0.025f
            canvas.drawText(pctText, cx, textY, okTextPaint)
            canvas.drawText("ЗВУК", cx, textY + outerR * 0.12f, volSubPaint)
        } else {
            val textY = cy - (okTextPaint.descent() + okTextPaint.ascent()) / 2f
            canvas.drawText("OK", cx, textY, okTextPaint)
        }
        canvas.restore()
    }

    private fun drawChevron(
        canvas: Canvas,
        x: Float,
        y: Float,
        size: Float,
        rotationDeg: Float,
        highlighted: Boolean
    ) {
        chevronPaint.color = if (highlighted) Color.WHITE else Color.parseColor("#9BA3B8")
        canvas.save()
        canvas.translate(x, y)
        canvas.rotate(rotationDeg)
        val path = Path().apply {
            moveTo(-size, size * 0.45f)
            lineTo(0f, -size * 0.55f)
            lineTo(size, size * 0.45f)
        }
        canvas.drawPath(path, chevronPaint)
        canvas.restore()
    }

    private fun apply3dMechanicalTilt(zone: Zone) {
        val density = resources.displayMetrics.density
        val shift = 3.2f * density
        animate().cancel()
        when (zone) {
            Zone.UP -> animate()
                .rotationX(8.5f)
                .rotationY(0f)
                .translationX(0f)
                .translationY(-shift)
                .scaleX(0.985f)
                .scaleY(0.985f)
                .setDuration(65L)
                .setInterpolator(DecelerateInterpolator())
                .start()
            Zone.DOWN -> animate()
                .rotationX(-8.5f)
                .rotationY(0f)
                .translationX(0f)
                .translationY(shift)
                .scaleX(0.985f)
                .scaleY(0.985f)
                .setDuration(65L)
                .setInterpolator(DecelerateInterpolator())
                .start()
            Zone.LEFT -> animate()
                .rotationX(0f)
                .rotationY(-8.5f)
                .translationX(-shift)
                .translationY(0f)
                .scaleX(0.985f)
                .scaleY(0.985f)
                .setDuration(65L)
                .setInterpolator(DecelerateInterpolator())
                .start()
            Zone.RIGHT -> animate()
                .rotationX(0f)
                .rotationY(8.5f)
                .translationX(shift)
                .translationY(0f)
                .scaleX(0.985f)
                .scaleY(0.985f)
                .setDuration(65L)
                .setInterpolator(DecelerateInterpolator())
                .start()
            Zone.CENTER -> animate()
                .rotationX(0f)
                .rotationY(0f)
                .translationX(0f)
                .translationY(1.8f * density)
                .scaleX(0.965f)
                .scaleY(0.965f)
                .setDuration(65L)
                .setInterpolator(DecelerateInterpolator())
                .start()
            Zone.NONE -> reset3dMechanicalTilt()
        }
    }

    private fun reset3dMechanicalTilt() {
        animate().cancel()
        animate()
            .rotationX(0f)
            .rotationY(0f)
            .translationX(0f)
            .translationY(0f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(260L)
            .setInterpolator(OvershootInterpolator(2.3f))
            .start()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val cx = width / 2f
        val cy = height / 2f
        val outerR = min(cx, cy) - 6f
        val centerR = outerR * 0.39f

        val dx = event.x - cx
        val dy = event.y - cy
        val dist = hypot(dx, dy)
        val angleDeg = computeAngleDeg(dx, dy)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (dist > outerR * 1.08f) return false
                isRotatingVolume = false
                accumulatedRotationDeg = 0f
                lastTouchAngleDeg = angleDeg
                currentRotaryIndicatorDeg = angleDeg
                activeZone = detectZone(dx, dy, dist, centerR)
                apply3dMechanicalTilt(activeZone)
                onZonePressedHaptic?.invoke()
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dist > centerR * 0.95f) {
                    var delta = angleDeg - lastTouchAngleDeg
                    if (delta > 180f) delta -= 360f
                    if (delta < -180f) delta += 360f

                    if (abs(delta) < 45f) {
                        accumulatedRotationDeg += delta
                        currentRotaryIndicatorDeg = angleDeg
                    }
                    lastTouchAngleDeg = angleDeg

                    if (!isRotatingVolume && abs(accumulatedRotationDeg) >= 18f) {
                        isRotatingVolume = true
                        activeZone = Zone.NONE
                        reset3dMechanicalTilt()
                    }

                    val stepThreshold = 18f
                    while (accumulatedRotationDeg >= stepThreshold) {
                        accumulatedRotationDeg -= stepThreshold
                        onZonePressedHaptic?.invoke()
                        onVolumeRotaryStep?.invoke(1)
                    }
                    while (accumulatedRotationDeg <= -stepThreshold) {
                        accumulatedRotationDeg += stepThreshold
                        onZonePressedHaptic?.invoke()
                        onVolumeRotaryStep?.invoke(-1)
                    }
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                val wasRotating = isRotatingVolume
                val triggered = activeZone
                isRotatingVolume = false
                activeZone = Zone.NONE
                accumulatedRotationDeg = 0f
                reset3dMechanicalTilt()
                invalidate()
                if (!wasRotating && triggered != Zone.NONE) {
                    onZoneClicked?.invoke(triggered)
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                isRotatingVolume = false
                activeZone = Zone.NONE
                accumulatedRotationDeg = 0f
                reset3dMechanicalTilt()
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun computeAngleDeg(dx: Float, dy: Float): Float {
        var deg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
        if (deg < 0f) deg += 360f
        return deg
    }

    private fun detectZone(dx: Float, dy: Float, dist: Float, centerR: Float): Zone {
        if (dist <= centerR) return Zone.CENTER
        val deg = computeAngleDeg(dx, dy)
        return when {
            deg >= 315f || deg < 45f -> Zone.RIGHT
            deg >= 45f && deg < 135f -> Zone.DOWN
            deg >= 135f && deg < 225f -> Zone.LEFT
            else -> Zone.UP
        }
    }
}
