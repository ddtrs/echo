package com.smartconsole.touch.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.min

/**
 * Ergonomic Brushed-Metal Touch Clickpad View (210dp).
 * Divides the disc mathematically into:
 * - Center OK circle (radius <= 38% of disc radius)
 * - 4 large 90-degree directional sectors (UP, DOWN, LEFT, RIGHT) covering the entire outer ring.
 * Impossible to miss with a thumb, with instant visual sector highlight and spring scale animation.
 */
class TouchClickpadView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class Zone { NONE, CENTER, UP, DOWN, LEFT, RIGHT }

    var onZoneClicked: ((Zone) -> Unit)? = null
    var onZonePressedHaptic: (() -> Unit)? = null

    private var activeZone: Zone = Zone.NONE
    private val outerRect = RectF()

    private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = Color.parseColor("#2AFFFFFF")
    }
    private val groovePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
        color = Color.parseColor("#14FFFFFF")
    }
    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#2E00F0FF")
    }
    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val centerBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        color = Color.parseColor("#38FFFFFF")
    }
    private val chevronPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4.5f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.parseColor("#B8C0D4")
    }
    private val okTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F5F7FA")
        textSize = 42f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        val r = min(cx, cy) - 6f
        outerRect.set(cx - r, cy - r, cx + r, cy + r)

        discPaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(
                Color.parseColor("#141720"),
                Color.parseColor("#232838"),
                Color.parseColor("#141720"),
                Color.parseColor("#232838"),
                Color.parseColor("#141720")
            ),
            null
        )

        centerPaint.shader = RadialGradient(
            cx, cy, r * 0.40f,
            Color.parseColor("#2A3042"),
            Color.parseColor("#171A24"),
            Shader.TileMode.CLAMP
        )
        okTextPaint.textSize = r * 0.16f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val outerR = min(cx, cy) - 6f
        val centerR = outerR * 0.39f

        // 1. Base brushed metal disc
        canvas.drawCircle(cx, cy, outerR, discPaint)
        canvas.drawCircle(cx, cy, outerR, borderPaint)

        // Concentric subtle machined grooves
        canvas.drawCircle(cx, cy, outerR * 0.84f, groovePaint)
        canvas.drawCircle(cx, cy, outerR * 0.68f, groovePaint)

        // 2. Highlight active directional sector when pressed
        when (activeZone) {
            Zone.RIGHT -> canvas.drawArc(outerRect, -45f, 90f, true, highlightPaint)
            Zone.DOWN -> canvas.drawArc(outerRect, 45f, 90f, true, highlightPaint)
            Zone.LEFT -> canvas.drawArc(outerRect, 135f, 90f, true, highlightPaint)
            Zone.UP -> canvas.drawArc(outerRect, 225f, 90f, true, highlightPaint)
            else -> {}
        }

        // 3. Draw 4 crisp vector chevrons on the ring
        val chevDist = outerR * 0.69f
        val chevSize = outerR * 0.065f
        drawChevron(canvas, cx, cy - chevDist, chevSize, 0f, activeZone == Zone.UP)
        drawChevron(canvas, cx, cy + chevDist, chevSize, 180f, activeZone == Zone.DOWN)
        drawChevron(canvas, cx - chevDist, cy, chevSize, 270f, activeZone == Zone.LEFT)
        drawChevron(canvas, cx + chevDist, cy, chevSize, 90f, activeZone == Zone.RIGHT)

        // 4. Center OK button with spring scale
        val okScale = if (activeZone == Zone.CENTER) 0.91f else 1.0f
        canvas.save()
        canvas.scale(okScale, okScale, cx, cy)
        canvas.drawCircle(cx, cy, centerR, centerPaint)
        if (activeZone == Zone.CENTER) {
            canvas.drawCircle(cx, cy, centerR, highlightPaint)
        }
        canvas.drawCircle(cx, cy, centerR, centerBorderPaint)

        val textY = cy - (okTextPaint.descent() + okTextPaint.ascent()) / 2f
        canvas.drawText("OK", cx, textY, okTextPaint)
        canvas.restore()
    }

    private fun drawChevron(
        canvas: Canvas,
        x: Float,
        y: Float,
        size: Float,
        rotationDeg: Float,
        highlighted: Boolean
    ) {
        chevronPaint.color = if (highlighted) Color.WHITE else Color.parseColor("#9BA3B8")
        canvas.save()
        canvas.translate(x, y)
        canvas.rotate(rotationDeg)
        val path = Path().apply {
            moveTo(-size, size * 0.45f)
            lineTo(0f, -size * 0.55f)
            lineTo(size, size * 0.45f)
        }
        canvas.drawPath(path, chevronPaint)
        canvas.restore()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val cx = width / 2f
        val cy = height / 2f
        val outerR = min(cx, cy) - 6f
        val centerR = outerR * 0.39f

        val dx = event.x - cx
        val dy = event.y - cy
        val dist = hypot(dx, dy)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (dist > outerR * 1.06f) return false
                activeZone = detectZone(dx, dy, dist, centerR)
                onZonePressedHaptic?.invoke()
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val current = if (dist <= outerR * 1.15f) {
                    detectZone(dx, dy, dist, centerR)
                } else {
                    Zone.NONE
                }
                if (current != activeZone) {
                    activeZone = current
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                val triggered = activeZone
                activeZone = Zone.NONE
                invalidate()
                if (triggered != Zone.NONE) {
                    onZoneClicked?.invoke(triggered)
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                activeZone = Zone.NONE
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun detectZone(dx: Float, dy: Float, dist: Float, centerR: Float): Zone {
        if (dist <= centerR) return Zone.CENTER
        var deg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
        if (deg < 0f) deg += 360f
        return when {
            deg >= 315f || deg < 45f -> Zone.RIGHT
            deg >= 45f && deg < 135f -> Zone.DOWN
            deg >= 135f && deg < 225f -> Zone.LEFT
            else -> Zone.UP
        }
    }
}
