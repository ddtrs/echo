package com.smartconsole.touch.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

class TuyaColorWheelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var hue: Float = 270f
        set(value) {
            field = ((value % 360f) + 360f) % 360f
            invalidate()
        }

    var saturation: Float = 0.95f
        set(value) {
            field = value.coerceIn(0.05f, 1f)
            invalidate()
        }

    var brightness: Float = 1.0f
        set(value) {
            field = value.coerceIn(0.01f, 1f)
            invalidate()
        }

    var isLightOn: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    /**
     * When true, the wheel switches from the 360° RGB rainbow to the White Color Temperature
     * spectrum (Warm 2700K <-> Daylight 4500K <-> Cool 6500K) for the LED Bulb.
     */
    var isWhiteMode: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                rebuildRingShader()
                invalidate()
            }
        }

    /** White color temperature in promille: 0 = Warm 2700K, 500 = Daylight, 1000 = Cool 6500K. */
    var whiteTempPromille: Int = 500
        set(value) {
            field = value.coerceIn(0, 1000)
            invalidate()
        }

    var onHueChanged: ((Float, Boolean) -> Unit)? = null
    var onWhiteTempChanged: ((Int, Boolean) -> Unit)? = null
    var onCenterPowerToggle: (() -> Unit)? = null
    var onHapticTick: (() -> Unit)? = null

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val thumbStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        color = Color.WHITE
    }
    private val thumbFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val coreGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val coreCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val ledRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 14f
        color = Color.parseColor("#E6FFFFFF")
    }
    private val ledDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private var isDraggingRing = false
    private var lastTickAngle = -100f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        val r = min(cx, cy)
        ringPaint.strokeWidth = r * 0.11f
        labelPaint.textSize = r * 0.12f
        rebuildRingShader()
    }

    private fun rebuildRingShader() {
        if (width <= 0 || height <= 0) return
        val cx = width / 2f
        val cy = height / 2f
        val colors = if (isWhiteMode) {
            intArrayOf(
                Color.parseColor("#FFB454"), // 0°   Warm 2700K
                Color.parseColor("#FFD18C"), // 60°  Soft Warm 3200K
                Color.parseColor("#FFF4E0"), // 120° Neutral 4200K
                Color.parseColor("#CCE4FF"), // 180° Cool 6500K
                Color.parseColor("#FFF4E0"), // 240° Neutral 4200K
                Color.parseColor("#FFD18C"), // 300° Soft Warm 3200K
                Color.parseColor("#FFB454")  // 360° Warm 2700K
            )
        } else {
            intArrayOf(
                Color.HSVToColor(floatArrayOf(0f, 1f, 1f)),
                Color.HSVToColor(floatArrayOf(60f, 1f, 1f)),
                Color.HSVToColor(floatArrayOf(120f, 1f, 1f)),
                Color.HSVToColor(floatArrayOf(180f, 1f, 1f)),
                Color.HSVToColor(floatArrayOf(240f, 1f, 1f)),
                Color.HSVToColor(floatArrayOf(300f, 1f, 1f)),
                Color.HSVToColor(floatArrayOf(360f, 1f, 1f))
            )
        }
        ringPaint.shader = SweepGradient(cx, cy, colors, null)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val maxR = min(cx, cy)
        val ringR = maxR * 0.84f
        val coreR = maxR * 0.50f

        val baseColor = if (isWhiteMode) {
            tempPromilleToColor(whiteTempPromille)
        } else {
            Color.HSVToColor(floatArrayOf(hue, saturation, brightness.coerceAtLeast(0.25f)))
        }

        val activeColor = if (isLightOn) {
            if (isWhiteMode) applyBrightnessToColor(baseColor, brightness.coerceAtLeast(0.35f)) else baseColor
        } else {
            Color.parseColor("#232733")
        }

        coreGlowPaint.shader = RadialGradient(
            cx, cy, maxR * 0.78f,
            Color.argb(if (isLightOn) 115 else 20, Color.red(activeColor), Color.green(activeColor), Color.blue(activeColor)),
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, maxR * 0.78f, coreGlowPaint)

        canvas.drawCircle(cx, cy, ringR, ringPaint)

        coreCirclePaint.color = activeColor
        canvas.drawCircle(cx, cy, coreR, coreCirclePaint)

        val trackR = coreR * 0.70f
        ledRingPaint.strokeWidth = maxR * 0.055f
        canvas.drawCircle(cx, cy, trackR, ledRingPaint)

        ledDotPaint.color = activeColor
        val numLeds = 20
        val dotR = maxR * 0.015f
        for (i in 0 until numLeds) {
            val angleRad = Math.toRadians((i * 360.0 / numLeds))
            val lx = cx + trackR * cos(angleRad).toFloat()
            val ly = cy + trackR * sin(angleRad).toFloat()
            canvas.drawCircle(lx, ly, dotR, ledDotPaint)
        }

        val statusText = if (isLightOn) "${(brightness * 100).toInt()}%" else "OFF"
        val textY = cy - (labelPaint.descent() + labelPaint.ascent()) / 2f
        labelPaint.color = if (isLightOn && isWhiteMode) Color.parseColor("#181C26") else Color.WHITE
        canvas.drawText(statusText, cx, textY, labelPaint)

        val thumbAngleDeg = if (isWhiteMode) {
            // Map 0..1000 temp to top semicircular sweep 0..180°
            (whiteTempPromille / 1000f) * 180f
        } else {
            hue
        }
        val angleRad = Math.toRadians(thumbAngleDeg.toDouble())
        val thumbX = cx + ringR * cos(angleRad).toFloat()
        val thumbY = cy + ringR * sin(angleRad).toFloat()
        val thumbR = maxR * 0.095f

        thumbFillPaint.color = if (isWhiteMode) {
            tempPromilleToColor(whiteTempPromille)
        } else {
            Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
        }
        canvas.drawCircle(thumbX, thumbY, thumbR, thumbFillPaint)
        canvas.drawCircle(thumbX, thumbY, thumbR, thumbStrokePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val cx = width / 2f
        val cy = height / 2f
        val maxR = min(cx, cy)
        val coreR = maxR * 0.52f

        val dx = event.x - cx
        val dy = event.y - cy
        val dist = hypot(dx, dy)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (dist <= coreR) {
                    isDraggingRing = false
                    onHapticTick?.invoke()
                    onCenterPowerToggle?.invoke()
                    return true
                }
                if (dist <= maxR * 1.05f) {
                    isDraggingRing = true
                    updateFromTouch(dx, dy, isFinal = false)
                    return true
                }
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (isDraggingRing) {
                    updateFromTouch(dx, dy, isFinal = false)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isDraggingRing) {
                    isDraggingRing = false
                    updateFromTouch(dx, dy, isFinal = true)
                    return true
                }
            }
        }
        return super.onTouchEvent(event)
    }

    private fun updateFromTouch(dx: Float, dy: Float, isFinal: Boolean) {
        var deg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
        if (deg < 0f) deg += 360f
        isLightOn = true
        if (abs(deg - lastTickAngle) >= 12f) {
            lastTickAngle = deg
            onHapticTick?.invoke()
        }
        if (isWhiteMode) {
            // Symmetric mapping: 0° = 0 (2700K), 180° = 1000 (6500K), 180..360° mirrors back 1000..0
            val folded = if (deg <= 180f) deg else (360f - deg)
            whiteTempPromille = ((folded / 180f) * 1000f).toInt().coerceIn(0, 1000)
            onWhiteTempChanged?.invoke(whiteTempPromille, isFinal)
        } else {
            hue = deg
            onHueChanged?.invoke(hue, isFinal)
        }
    }

    companion object {
        fun tempPromilleToColor(tempPromille: Int): Int {
            val t = (tempPromille.coerceIn(0, 1000)) / 1000f
            return if (t <= 0.5f) {
                val f = t / 0.5f
                lerpColor(Color.parseColor("#FFB454"), Color.parseColor("#FFF6EB"), f)
            } else {
                val f = (t - 0.5f) / 0.5f
                lerpColor(Color.parseColor("#FFF6EB"), Color.parseColor("#CCE4FF"), f)
            }
        }

        private fun lerpColor(c1: Int, c2: Int, f: Float): Int {
            val r = (Color.red(c1) + (Color.red(c2) - Color.red(c1)) * f).toInt().coerceIn(0, 255)
            val g = (Color.green(c1) + (Color.green(c2) - Color.green(c1)) * f).toInt().coerceIn(0, 255)
            val b = (Color.blue(c1) + (Color.blue(c2) - Color.blue(c1)) * f).toInt().coerceIn(0, 255)
            return Color.rgb(r, g, b)
        }

        private fun applyBrightnessToColor(c: Int, b: Float): Int {
            val r = (Color.red(c) * b).toInt().coerceIn(0, 255)
            val g = (Color.green(c) * b).toInt().coerceIn(0, 255)
            val bl = (Color.blue(c) * b).toInt().coerceIn(0, 255)
            return Color.rgb(r, g, bl)
        }
    }
}
