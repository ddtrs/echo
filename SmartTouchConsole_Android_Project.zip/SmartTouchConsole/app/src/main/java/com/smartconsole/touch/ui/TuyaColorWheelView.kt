package com.smartconsole.touch.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * Interactive Tuya Smart Life-style Neon Color Wheel View.
 * - Outer neon rainbow hue ring with a crisp white thumb indicator.
 * - Inner glowing LED strip core with 24 virtual LEDs and center power toggle.
 */
class TuyaColorWheelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var hue: Float = 270f
        set(value) {
            field = ((value % 360f) + 360f) % 360f
            invalidate()
        }

    var saturation: Float = 0.95f
        set(value) {
            field = value.coerceIn(0.05f, 1f)
            invalidate()
        }

    var brightness: Float = 1.0f
        set(value) {
            field = value.coerceIn(0.01f, 1f)
            invalidate()
        }

    var isLightOn: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    var onHueChanged: ((Float, Boolean) -> Unit)? = null
    var onCenterPowerToggle: (() -> Unit)? = null
    var onHapticTick: (() -> Unit)? = null

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val thumbStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        color = Color.WHITE
    }
    private val thumbFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val coreGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val coreCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val ledRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 14f
        color = Color.parseColor("#E6FFFFFF")
    }
    private val ledDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private var isDraggingRing = false
    private var lastTickHue = -100f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        val r = min(cx, cy)
        ringPaint.strokeWidth = r * 0.11f

        val colors = intArrayOf(
            Color.HSVToColor(floatArrayOf(0f, 1f, 1f)),
            Color.HSVToColor(floatArrayOf(60f, 1f, 1f)),
            Color.HSVToColor(floatArrayOf(120f, 1f, 1f)),
            Color.HSVToColor(floatArrayOf(180f, 1f, 1f)),
            Color.HSVToColor(floatArrayOf(240f, 1f, 1f)),
            Color.HSVToColor(floatArrayOf(300f, 1f, 1f)),
            Color.HSVToColor(floatArrayOf(360f, 1f, 1f))
        )
        ringPaint.shader = SweepGradient(cx, cy, colors, null)
        labelPaint.textSize = r * 0.12f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val maxR = min(cx, cy)
        val ringR = maxR * 0.84f
        val coreR = maxR * 0.50f

        val activeColor = if (isLightOn) {
            Color.HSVToColor(floatArrayOf(hue, saturation, brightness.coerceAtLeast(0.25f)))
        } else {
            Color.parseColor("#232733")
        }

        // 1. Ambient radial glow behind the core
        coreGlowPaint.shader = RadialGradient(
            cx, cy, maxR * 0.78f,
            Color.argb(if (isLightOn) 115 else 20, Color.red(activeColor), Color.green(activeColor), Color.blue(activeColor)),
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, maxR * 0.78f, coreGlowPaint)

        // 2. Outer Hue Rainbow Ring
        canvas.drawCircle(cx, cy, ringR, ringPaint)

        // 3. Center LED Strip Preview Core (like Tuya Smart Life screenshot)
        coreCirclePaint.color = activeColor
        canvas.drawCircle(cx, cy, coreR, coreCirclePaint)

        // Inner decorative LED strip track with 20 diode squares
        val trackR = coreR * 0.70f
        ledRingPaint.strokeWidth = maxR * 0.055f
        canvas.drawCircle(cx, cy, trackR, ledRingPaint)

        ledDotPaint.color = activeColor
        val numLeds = 20
        val dotR = maxR * 0.015f
        for (i in 0 until numLeds) {
            val angleRad = Math.toRadians((i * 360.0 / numLeds))
            val lx = cx + trackR * cos(angleRad).toFloat()
            val ly = cy + trackR * sin(angleRad).toFloat()
            canvas.drawCircle(lx, ly, dotR, ledDotPaint)
        }

        // Center status text (ON% or OFF)
        val statusText = if (isLightOn) "${(brightness * 100).toInt()}%" else "OFF"
        val textY = cy - (labelPaint.descent() + labelPaint.ascent()) / 2f
        canvas.drawText(statusText, cx, textY, labelPaint)

        // 4. White Thumb Selector on the Outer Ring
        val angleRad = Math.toRadians(hue.toDouble())
        val thumbX = cx + ringR * cos(angleRad).toFloat()
        val thumbY = cy + ringR * sin(angleRad).toFloat()
        val thumbR = maxR * 0.095f

        thumbFillPaint.color = Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
        canvas.drawCircle(thumbX, thumbY, thumbR, thumbFillPaint)
        canvas.drawCircle(thumbX, thumbY, thumbR, thumbStrokePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val cx = width / 2f
        val cy = height / 2f
        val maxR = min(cx, cy)
        val coreR = maxR * 0.52f

        val dx = event.x - cx
        val dy = event.y - cy
        val dist = hypot(dx, dy)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (dist <= coreR) {
                    isDraggingRing = false
                    onHapticTick?.invoke()
                    onCenterPowerToggle?.invoke()
                    return true
                }
                if (dist <= maxR * 1.05f) {
                    isDraggingRing = true
                    updateHueFromTouch(dx, dy, isFinal = false)
                    return true
                }
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (isDraggingRing) {
                    updateHueFromTouch(dx, dy, isFinal = false)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isDraggingRing) {
                    isDraggingRing = false
                    updateHueFromTouch(dx, dy, isFinal = true)
                    return true
                }
            }
        }
        return super.onTouchEvent(event)
    }

    private fun updateHueFromTouch(dx: Float, dy: Float, isFinal: Boolean) {
        var deg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
        if (deg < 0f) deg += 360f
        hue = deg
        isLightOn = true
        if (kotlin.math.abs(hue - lastTickHue) >= 12f) {
            lastTickHue = hue
            onHapticTick?.invoke()
        }
        onHueChanged?.invoke(hue, isFinal)
    }
}
