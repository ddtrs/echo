package com.smartconsole.touch.network

import android.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Direct Tuya OpenAPI v2.0 Controller (Central Europe Data Center: https://openapi.tuyaeu.com).
 * Includes automatic server timestamp calibration to fix codes 1004 / 1013 on skewed phone clocks.
 */
class TuyaController(
    private val clientId: String = "dvrtg3uh53ty5wfv4dam",
    private val clientSecret: String = "891832be155644d2921fa5921b64ff27",
    val stripDeviceId: String = "bf4adac28e8e4f5b0bsfuq",
    val sconceDeviceId: String = "bf4adac28e8e4f5b0bsfuq_sconce"
) {
    companion object {
        private const val BASE_URL = "https://openapi.tuyaeu.com"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }

    enum class LightPreset(
        val id: String,
        val titleRu: String,
        val hue: Int,
        val satPromille: Int,
        val valPromille: Int,
        val previewHexColor: Int
    ) {
        CYBER("cyber", "Кибер", 184, 1000, 1000, Color.parseColor("#00F0FF")),
        SAPPHIRE("sapphire", "Сапфир", 224, 1000, 1000, Color.parseColor("#1E5BFF")),
        VIOLET("violet", "Фиолет", 271, 850, 1000, Color.parseColor("#8A2BE2")),
        RASPBERRY("raspberry", "Малина", 336, 1000, 1000, Color.parseColor("#FF0066")),
        SUNSET("sunset", "Закат", 20, 1000, 1000, Color.parseColor("#FF5500")),
        WARM("warm", "Тёплый", 34, 280, 1000, Color.parseColor("#FFCF96"));

        fun toTuyaHexHsv(): String {
            return String.format("%04x%04x%04x", hue, satPromille, valPromille)
        }
    }

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(4, TimeUnit.SECONDS)
        .writeTimeout(4, TimeUnit.SECONDS)
        .build()

    @Volatile
    private var cachedAccessToken: String? = null

    @Volatile
    private var tokenExpiresAtMs: Long = 0L

    // Server time offset in ms: serverTime = System.currentTimeMillis() + serverTimeOffsetMs
    @Volatile
    private var serverTimeOffsetMs: Long = 0L

    private fun getCalibratedTimestamp(): Long {
        return System.currentTimeMillis() + serverTimeOffsetMs
    }

    /**
     * Toggles switch_led on the specified Tuya device.
     */
    suspend fun setPower(deviceId: String, enabled: Boolean): Boolean = withContext(Dispatchers.IO) {
        val commands = JSONArray().apply {
            put(JSONObject().apply {
                put("code", "switch_led")
                put("value", enabled)
            })
        }
        sendDeviceCommands(deviceId, commands)
    }

    /**
     * Applies one of the 6 HSV presets to the LED strip while keeping switch_led = true
     * and work_mode = "colour".
     */
    suspend fun applyPreset(deviceId: String = stripDeviceId, preset: LightPreset): Boolean =
        withContext(Dispatchers.IO) {
            val hsvHex = preset.toTuyaHexHsv()
            val commands = JSONArray().apply {
                put(JSONObject().apply {
                    put("code", "switch_led")
                    put("value", true)
                })
                put(JSONObject().apply {
                    put("code", "work_mode")
                    put("value", "colour")
                })
                put(JSONObject().apply {
                    put("code", "colour_data")
                    put("value", hsvHex)
                })
            }
            sendDeviceCommands(deviceId, commands)
        }

    private fun sendDeviceCommands(deviceId: String, commands: JSONArray, isRetry: Boolean = false): Boolean {
        val token = getValidAccessToken() ?: return false
        val path = "/v1.0/iot-03/devices/$deviceId/commands"
        val payload = JSONObject().apply {
            put("commands", commands)
        }.toString()

        val timestamp = getCalibratedTimestamp().toString()
        val contentSha256 = sha256Hex(payload)
        val stringToSign = "POST\n$contentSha256\n\n$path"
        val signPayload = clientId + token + timestamp + stringToSign
        val signature = hmacSha256(signPayload, clientSecret)

        val request = Request.Builder()
            .url(BASE_URL + path)
            .post(payload.toRequestBody(JSON_MEDIA_TYPE))
            .addHeader("client_id", clientId)
            .addHeader("access_token", token)
            .addHeader("sign", signature)
            .addHeader("t", timestamp)
            .addHeader("sign_method", "HMAC-SHA256")
            .build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (bodyStr.isNotEmpty()) {
                    val json = JSONObject(bodyStr)
                    val serverT = json.optLong("t", 0L)
                    if (serverT > 0L) {
                        serverTimeOffsetMs = serverT - System.currentTimeMillis()
                    }
                    val code = json.optInt("code", 0)
                    if ((code == 1004 || code == 1010 || code == 1013) && !isRetry) {
                        cachedAccessToken = null
                        return sendDeviceCommands(deviceId, commands, isRetry = true)
                    }
                    json.optBoolean("success", false)
                } else {
                    response.isSuccessful
                }
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun getValidAccessToken(): String? {
        val now = getCalibratedTimestamp()
        val existing = cachedAccessToken
        if (existing != null && now < tokenExpiresAtMs) {
            return existing
        }
        return requestTokenInternal(isRetry = false)
    }

    private fun requestTokenInternal(isRetry: Boolean): String? {
        val path = "/v1.0/token?grant_type=1"
        val timestamp = getCalibratedTimestamp().toString()
        val contentSha256 = sha256Hex("")
        val stringToSign = "GET\n$contentSha256\n\n$path"
        val signPayload = clientId + timestamp + stringToSign
        val signature = hmacSha256(signPayload, clientSecret)

        val request = Request.Builder()
            .url(BASE_URL + path)
            .get()
            .addHeader("client_id", clientId)
            .addHeader("sign", signature)
            .addHeader("t", timestamp)
            .addHeader("sign_method", "HMAC-SHA256")
            .build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (bodyStr.isEmpty()) return null
                val json = JSONObject(bodyStr)
                val serverT = json.optLong("t", 0L)
                if (serverT > 0L) {
                    serverTimeOffsetMs = serverT - System.currentTimeMillis()
                }

                val code = json.optInt("code", 0)
                if ((code == 1004 || code == 1013) && !isRetry) {
                    return requestTokenInternal(isRetry = true)
                }

                if (!json.optBoolean("success", false)) return null
                val result = json.getJSONObject("result")
                val token = result.getString("access_token")
                val expireTimeSec = result.optLong("expire_time", 7200L)
                cachedAccessToken = token
                tokenExpiresAtMs = getCalibratedTimestamp() + (expireTimeSec - 120) * 1000L
                token
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun hmacSha256(data: String, secret: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        val secretKey = SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256")
        mac.init(secretKey)
        val bytes = mac.doFinal(data.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02X".format(it) }
    }
}
