package com.smartconsole.touch.network

import android.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Zero-Lag Tuya OpenAPI v2.0 Controller (https://openapi.tuyaeu.com).
 *
 * Why the strip lagged previously:
 * Sending 3 parallel HTTP requests on every pixel of finger movement flooded the Tuya Cloud API
 * rate limiter (which queues excess requests with a 5-15 second penalty across all devices).
 *
 * Fix:
 * 1. Sends ONE clean atomic request per action (only when finger is released or throttled >= 450ms).
 * 2. Automatically remembers which DP code (`colour_data` vs `colour_data_v2`) the strip accepts.
 */
class TuyaController(
    private val clientId: String = "dvrtg3uh53ty5wfv4dam",
    private val clientSecret: String = "891832be155644d2921fa5921b64ff27",
    val stripDeviceId: String = "bf4adac28e8e4f5b0bsfuq",
    val sconceDeviceId: String = "bf4adac28e8e4f5b0bsfuq_sconce"
) {
    companion object {
        private const val BASE_URL = "https://openapi.tuyaeu.com"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }

    enum class LightPreset(
        val id: String,
        val titleRu: String,
        val hue: Int,
        val satPromille: Int,
        val valPromille: Int,
        val previewHexColor: Int
    ) {
        CYBER("cyber", "Кибер", 184, 1000, 1000, Color.parseColor("#00F0FF")),
        SAPPHIRE("sapphire", "Сапфир", 224, 1000, 1000, Color.parseColor("#1E5BFF")),
        VIOLET("violet", "Фиолет", 271, 850, 1000, Color.parseColor("#8A2BE2")),
        RASPBERRY("raspberry", "Малина", 336, 1000, 1000, Color.parseColor("#FF0066")),
        SUNSET("sunset", "Закат", 20, 1000, 1000, Color.parseColor("#FF5500")),
        WARM("warm", "Тёплый", 34, 280, 1000, Color.parseColor("#FFCF96"))
    }

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .writeTimeout(3, TimeUnit.SECONDS)
        .build()

    @Volatile
    private var cachedAccessToken: String? = null

    @Volatile
    private var tokenExpiresAtMs: Long = 0L

    @Volatile
    private var serverTimeOffsetMs: Long = 0L

    @Volatile
    private var useV2JsonFormat: Boolean = false

    private fun getCalibratedTimestamp(): Long {
        return System.currentTimeMillis() + serverTimeOffsetMs
    }

    suspend fun setPower(deviceId: String, enabled: Boolean): Boolean = withContext(Dispatchers.IO) {
        val commands = JSONArray().apply {
            put(JSONObject().apply {
                put("code", "switch_led")
                put("value", enabled)
            })
        }
        sendDeviceCommands(deviceId, commands)
    }

    suspend fun applyPreset(deviceId: String = stripDeviceId, preset: LightPreset): Boolean {
        return setHsvColor(
            deviceId = deviceId,
            hue = preset.hue,
            satPromille = preset.satPromille,
            valPromille = preset.valPromille
        )
    }

    /**
     * Sends a single non-spamming atomic command to change color & brightness.
     * Primary format: 12-char HEX `colour_data` (`HHHHSSSSVVVV`).
     * Fallback: if the device rejects `colour_data`, automatically switches to `colour_data_v2` JSON.
     */
    suspend fun setHsvColor(
        deviceId: String = stripDeviceId,
        hue: Int,
        satPromille: Int,
        valPromille: Int
    ): Boolean = withContext(Dispatchers.IO) {
        val h = hue.coerceIn(0, 360)
        val s1000 = satPromille.coerceIn(10, 1000)
        val v1000 = valPromille.coerceIn(10, 1000)

        if (!useV2JsonFormat) {
            val hex1000 = String.format("%04x%04x%04x", h, s1000, v1000)
            val hexCommands = JSONArray().apply {
                put(JSONObject().put("code", "switch_led").put("value", true))
                put(JSONObject().put("code", "work_mode").put("value", "colour"))
                put(JSONObject().put("code", "colour_data").put("value", hex1000))
            }
            if (sendDeviceCommands(deviceId, hexCommands)) {
                return@withContext true
            }
            useV2JsonFormat = true
        }

        val hsvJsonObj = JSONObject().apply {
            put("h", h)
            put("s", s1000)
            put("v", v1000)
        }
        val v2Commands = JSONArray().apply {
            put(JSONObject().put("code", "switch_led").put("value", true))
            put(JSONObject().put("code", "work_mode").put("value", "colour"))
            put(JSONObject().put("code", "colour_data_v2").put("value", hsvJsonObj))
        }
        if (sendDeviceCommands(deviceId, v2Commands)) {
            return@withContext true
        }

        useV2JsonFormat = false
        false
    }

    private fun sendDeviceCommands(deviceId: String, commands: JSONArray, isRetry: Boolean = false): Boolean {
        val token = getValidAccessToken() ?: return false
        val path = "/v1.0/iot-03/devices/$deviceId/commands"
        val payload = JSONObject().apply {
            put("commands", commands)
        }.toString()

        val timestamp = getCalibratedTimestamp().toString()
        val contentSha256 = sha256Hex(payload)
        val stringToSign = "POST\n$contentSha256\n\n$path"
        val signPayload = clientId + token + timestamp + stringToSign
        val signature = hmacSha256(signPayload, clientSecret)

        val request = Request.Builder()
            .url(BASE_URL + path)
            .post(payload.toRequestBody(JSON_MEDIA_TYPE))
            .addHeader("client_id", clientId)
            .addHeader("access_token", token)
            .addHeader("sign", signature)
            .addHeader("t", timestamp)
            .addHeader("sign_method", "HMAC-SHA256")
            .build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (bodyStr.isNotEmpty()) {
                    val json = JSONObject(bodyStr)
                    val serverT = json.optLong("t", 0L)
                    if (serverT > 0L) {
                        serverTimeOffsetMs = serverT - System.currentTimeMillis()
                    }
                    val code = json.optInt("code", 0)
                    if ((code == 1004 || code == 1010 || code == 1013) && !isRetry) {
                        cachedAccessToken = null
                        return sendDeviceCommands(deviceId, commands, isRetry = true)
                    }
                    json.optBoolean("success", false)
                } else {
                    response.isSuccessful
                }
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun getValidAccessToken(): String? {
        val now = getCalibratedTimestamp()
        val existing = cachedAccessToken
        if (existing != null && now < tokenExpiresAtMs) {
            return existing
        }
        return requestTokenInternal(isRetry = false)
    }

    private fun requestTokenInternal(isRetry: Boolean): String? {
        val path = "/v1.0/token?grant_type=1"
        val timestamp = getCalibratedTimestamp().toString()
        val contentSha256 = sha256Hex("")
        val stringToSign = "GET\n$contentSha256\n\n$path"
        val signPayload = clientId + timestamp + stringToSign
        val signature = hmacSha256(signPayload, clientSecret)

        val request = Request.Builder()
            .url(BASE_URL + path)
            .get()
            .addHeader("client_id", clientId)
            .addHeader("sign", signature)
            .addHeader("t", timestamp)
            .addHeader("sign_method", "HMAC-SHA256")
            .build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (bodyStr.isEmpty()) return null
                val json = JSONObject(bodyStr)
                val serverT = json.optLong("t", 0L)
                if (serverT > 0L) {
                    serverTimeOffsetMs = serverT - System.currentTimeMillis()
                }

                val code = json.optInt("code", 0)
                if ((code == 1004 || code == 1013) && !isRetry) {
                    return requestTokenInternal(isRetry = true)
                }

                if (!json.optBoolean("success", false)) return null
                val result = json.getJSONObject("result")
                val token = result.getString("access_token")
                val expireTimeSec = result.optLong("expire_time", 7200L)
                cachedAccessToken = token
                tokenExpiresAtMs = getCalibratedTimestamp() + (expireTimeSec - 120) * 1000L
                token
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun hmacSha256(data: String, secret: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        val secretKey = SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256")
        mac.init(secretKey)
        val bytes = mac.doFinal(data.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02X".format(it) }
    }
}
