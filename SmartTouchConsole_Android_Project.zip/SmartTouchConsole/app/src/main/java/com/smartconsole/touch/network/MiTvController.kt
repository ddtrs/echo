package com.smartconsole.touch.network

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * HYBRID TV CONTROLLER:
 *  - ALL remote buttons (D-pad, OK, Back, Home, Play/Pause, Volume, Power) go through the native
 *    Google Android TV Remote v2 protocol (`AtvRemoteClient`, ports 6466 / 6467).
 *  - The custom launcher server on port 8765 is kept for what only it can do: TV control panel,
 *    launching apps by package name and voice queries. It is also a fallback for keys when the
 *    Google Remote link is not paired yet or the TV is unreachable on 6466.
 */
class MiTvController(
    private val context: Context,
    initialIp: String = "192.168.0.3",
    val tvPort: Int = 8765
) {
    private val prefs = context.applicationContext.getSharedPreferences("smart_console_prefs", Context.MODE_PRIVATE)

    val remote = AtvRemoteClient(context)

    /** Called (at most once per 25 s) when a key was pressed but Google Remote is not paired. */
    var onPairingRequired: (() -> Unit)? = null
    private var lastPairingPromptAtMs = 0L

    private fun notifyPairingNeeded() {
        val now = System.currentTimeMillis()
        if (now - lastPairingPromptAtMs > 25_000L) {
            lastPairingPromptAtMs = now
            onPairingRequired?.invoke()
        }
    }

    suspend fun beginPairing(): Boolean = remote.beginPairing(tvIp)
    suspend fun finishPairing(code: String): Boolean = remote.finishPairing(code)

    @Volatile
    var tvIp: String = prefs.getString("saved_tv_ip", initialIp) ?: initialIp
        private set

    private val isScanning = AtomicBoolean(false)
    private var nsdManager: NsdManager? = null
    private var nsdDiscoveryListener: NsdManager.DiscoveryListener? = null

    enum class TvKey(val commandValue: String, val keycodeInt: Int) {
        DPAD_UP("UP", 19),
        DPAD_DOWN("DOWN", 20),
        DPAD_LEFT("LEFT", 21),
        DPAD_RIGHT("RIGHT", 22),
        DPAD_CENTER("OK", 23),
        BACK("BACK", 4),
        HOME("HOME", 3),
        MENU("MENU", 82),
        VOLUME_UP("VOL_UP", 24),
        VOLUME_DOWN("VOL_DOWN", 25),
        PLAY_PAUSE("PLAY_PAUSE", 85),
        POWER("POWER", 26)
    }

    enum class TvApp(val packageName: String, val deepLink: String) {
        YOUTUBE("com.google.android.youtube.tv", "https://www.youtube.com"),
        KICK("com.kick.mobile", "https://kick.com"),
        BROWSER("com.android.chrome", "https://www.google.com")
    }

    data class TvStatus(
        val ip: String,
        val isReachable: Boolean,
        val isInteractive: Boolean
    )

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(320, TimeUnit.MILLISECONDS)
        .readTimeout(320, TimeUnit.MILLISECONDS)
        .writeTimeout(320, TimeUnit.MILLISECONDS)
        .retryOnConnectionFailure(false)
        .build()

    @Volatile
    var lastKnownStatus: TvStatus = TvStatus(ip = tvIp, isReachable = false, isInteractive = false)
        private set

    init {
        startMdnsAutoDiscovery()
    }

    /**
     * Starts official Android NsdManager mDNS discovery for `_androidtvremote2._tcp.`
     * so the phone immediately locks onto the Mi TV Stick IP without slow scanning.
     */
    fun startMdnsAutoDiscovery() {
        try {
            val manager = context.applicationContext.getSystemService(Context.NSD_SERVICE) as? NsdManager ?: return
            nsdManager = manager
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(regType: String?) {}
                override fun onServiceFound(service: NsdServiceInfo?) {
                    if (service == null) return
                    try {
                        manager.resolveService(service, object : NsdManager.ResolveListener {
                            override fun onResolveFailed(serviceInfo: NsdServiceInfo?, errorCode: Int) {}
                            override fun onServiceResolved(resolvedInfo: NsdServiceInfo?) {
                                val hostIp = resolvedInfo?.host?.hostAddress
                                if (!hostIp.isNullOrBlank() && !hostIp.startsWith("127.")) {
                                    saveDiscoveredIp(hostIp)
                                }
                            }
                        })
                    } catch (_: Exception) {
                    }
                }
                override fun onServiceLost(service: NsdServiceInfo?) {}
                override fun onDiscoveryStopped(serviceType: String?) {}
                override fun onStartDiscoveryFailed(serviceType: String?, errorCode: Int) {}
                override fun onStopDiscoveryFailed(serviceType: String?, errorCode: Int) {}
            }
            nsdDiscoveryListener = listener
            manager.discoverServices("_androidtvremote2._tcp.", NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (_: Exception) {
        }
    }

    fun stopMdnsAutoDiscovery() {
        try {
            nsdDiscoveryListener?.let { nsdManager?.stopServiceDiscovery(it) }
        } catch (_: Exception) {
        }
        nsdDiscoveryListener = null
        remote.disconnect()
    }

    fun setManualIp(newIp: String) {
        val cleaned = newIp.trim()
        if (cleaned.isNotEmpty()) {
            tvIp = cleaned
            prefs.edit().putString("saved_tv_ip", cleaned).apply()
        }
    }

    private fun saveDiscoveredIp(foundIp: String) {
        tvIp = foundIp
        prefs.edit().putString("saved_tv_ip", foundIp).apply()
    }

    /**
     * Key dispatch: Google Android TV Remote first. If it is not paired or the TV does not answer
     * on 6466, fall back to the launcher server so the button still does something.
     */
    suspend fun sendKey(key: TvKey): Boolean = withContext(Dispatchers.IO) {
        when (remote.sendKey(key.keycodeInt, tvIp)) {
            AtvRemoteClient.SendResult.OK -> true
            AtvRemoteClient.SendResult.UNPAIRED -> {
                notifyPairingNeeded()
                sendKeyViaLauncherServer(key)
            }
            AtvRemoteClient.SendResult.UNREACHABLE -> sendKeyViaLauncherServer(key)
        }
    }

    private fun sendKeyViaLauncherServer(key: TvKey): Boolean {
        sendUdpFireAndForget(key.commandValue)
        val url = "http://$tvIp:$tvPort/key?k=${key.commandValue}&code=${key.keycodeInt}"
        return executeHttpGet(url)
    }

    /**
     * Opens the custom TV Control Panel (bound to the Wi-Fi | Sliders button).
     * Sends both the custom server command and the MENU / SETTINGS keycode so the launcher opens the panel immediately.
     */
    suspend fun openTvControlPanel(): Boolean = withContext(Dispatchers.IO) {
        sendUdpFireAndForget("MENU")
        val panelOk = executeHttpGet("http://$tvIp:$tvPort/key?k=MENU&code=82")
        executeHttpGet("http://$tvIp:$tvPort/panel")
        panelOk
    }

    /**
     * Toggles TV Power / Sleep state via Hybrid Protocol.
     */
    suspend fun toggleTvPower(): Boolean = sendKey(TvKey.POWER)

    /**
     * Launches a target TV app package via Custom Launcher HTTP Server (`/app?pkg=...`).
     */
    suspend fun launchApp(app: TvApp): Boolean = withContext(Dispatchers.IO) {
        sendUdpFireAndForget("APP:${app.packageName}")
        val ok = executeHttpGet("http://$tvIp:$tvPort/app?pkg=${app.packageName}")
        if (ok) {
            true
        } else {
            // Launcher server is silent -> try the Google Remote deep link instead
            remote.openAppLink(app.deepLink, tvIp) == AtvRemoteClient.SendResult.OK
        }
    }

    /** Opens the Google Remote connection in advance so the first tap is instant. */
    suspend fun warmUpRemote() {
        when (remote.warmUp(tvIp)) {
            AtvRemoteClient.SendResult.UNPAIRED -> notifyPairingNeeded()
            else -> {}
        }
    }

    /**
     * Forwards a spoken voice query to Custom Launcher HTTP Server (`/voice?text=...`).
     */
    suspend fun forwardVoiceCommandToTv(spokenText: String): Boolean = withContext(Dispatchers.IO) {
        val encodedText = try {
            URLEncoder.encode(spokenText, "UTF-8")
        } catch (_: Exception) {
            spokenText
        }
        executeHttpGet("http://$tvIp:$tvPort/voice?text=$encodedText")
    }

    /**
     * Polls current TV IP on port 8765 (or Android TV Remote port 6466).
     * If unreachable, automatically scans the local Wi-Fi subnet.
     */
    suspend fun pollScreenStatus(): TvStatus = withContext(Dispatchers.IO) {
        val launcherOpen = isPortOpen(tvIp, tvPort, 280)
        val googleRemoteOpen = if (!launcherOpen) isPortOpen(tvIp, 6466, 220) else true

        if (launcherOpen || googleRemoteOpen) {
            val status = TvStatus(ip = tvIp, isReachable = true, isInteractive = launcherOpen)
            lastKnownStatus = status
            return@withContext status
        }

        val foundIp = discoverTvInSubnet()
        val status = if (foundIp != null) {
            TvStatus(ip = foundIp, isReachable = true, isInteractive = true)
        } else {
            TvStatus(ip = tvIp, isReachable = false, isInteractive = false)
        }
        lastKnownStatus = status
        status
    }

    suspend fun forceScanSubnet(): String? = withContext(Dispatchers.IO) {
        discoverTvInSubnet()
    }

    private suspend fun discoverTvInSubnet(): String? = coroutineScope {
        if (!isScanning.compareAndSet(false, true)) {
            return@coroutineScope null
        }
        try {
            val subnetPrefix = getLocalSubnetPrefix() ?: "192.168.0"
            val phoneIp = getLocalPhoneIp()

            val priorityHosts = (2..20).map { "$subnetPrefix.$it" } +
                listOf("192.168.0.2", "192.168.0.3", "192.168.0.4", "192.168.1.2", "192.168.1.3")

            val priorityMatch = priorityHosts.distinct()
                .filter { it != phoneIp }
                .map { candidateIp ->
                    async(Dispatchers.IO) {
                        if (isPortOpen(candidateIp, tvPort, 200) || isPortOpen(candidateIp, 6466, 180)) {
                            candidateIp
                        } else null
                    }
                }.awaitAll().firstOrNull { it != null }

            if (priorityMatch != null) {
                saveDiscoveredIp(priorityMatch)
                return@coroutineScope priorityMatch
            }

            for (batchStart in 21..254 step 50) {
                val batchEnd = (batchStart + 49).coerceAtMost(254)
                val foundInBatch = (batchStart..batchEnd)
                    .map { "$subnetPrefix.$it" }
                    .filter { it != phoneIp }
                    .map { candidateIp ->
                        async(Dispatchers.IO) {
                            if (isPortOpen(candidateIp, tvPort, 150)) candidateIp else null
                        }
                    }.awaitAll().firstOrNull { it != null }

                if (foundInBatch != null) {
                    saveDiscoveredIp(foundInBatch)
                    return@coroutineScope foundInBatch
                }
            }
            null
        } finally {
            isScanning.set(false)
        }
    }

    private fun isPortOpen(ip: String, port: Int, timeoutMs: Int): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), timeoutMs)
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun getLocalPhoneIp(): String? {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (!iface.isUp || iface.isLoopback) continue
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress ?: continue
                        if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.")) {
                            return ip
                        }
                    }
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun getLocalSubnetPrefix(): String? {
        val ip = getLocalPhoneIp() ?: return null
        val lastDot = ip.lastIndexOf('.')
        return if (lastDot > 0) ip.substring(0, lastDot) else null
    }

    private fun executeHttpGet(url: String): Boolean {
        val request = Request.Builder().url(url).get().build()
        return try {
            httpClient.newCall(request).execute().use { response ->
                response.code in 200..499
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun sendUdpFireAndForget(payload: String) {
        try {
            DatagramSocket().use { udpSocket ->
                udpSocket.soTimeout = 100
                val bytes = payload.toByteArray(Charsets.UTF_8)
                val address = InetAddress.getByName(tvIp)
                val packet = DatagramPacket(bytes, bytes.size, address, tvPort)
                udpSocket.send(packet)
            }
        } catch (_: Exception) {
        }
    }
}
