package com.smartconsole.touch.network

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * HYBRID TV CONTROLLER (Google Android TV Remote Protocol + Custom Launcher Server Port 8765):
 *
 * 1. Instant ZeroConf / mDNS Discovery (`NsdManager`):
 *    Listens for `_androidtvremote2._tcp.` and `_adb._tcp.` services broadcast by the Mi TV Stick
 *    so the TV's IP is found in <100ms even when the router changes DHCP leases.
 * 2. Hybrid Command Routing:
 *    - Navigation & System Keys (`UP`, `DOWN`, `LEFT`, `RIGHT`, `OK`, `BACK`, `HOME`, `VOL_UP`, `VOL_DOWN`, `POWER`)
 *      are dispatched simultaneously via:
 *        a) Native Android Keycode packet (ports 6466 / 5555 / UDP keycode bridge)
 *        b) Custom Launcher HTTP/UDP Server (`http://<tvIp>:8765/key?k=...&code=...`)
 *    - Custom Launcher Actions (Opening TV Control Panel `SETTINGS_PANEL`, Launching Apps `/app?pkg=...`,
 *      and Voice Assistant Overlay `/voice?text=...`) go directly to the Launcher HTTP Server on port 8765.
 */
class MiTvController(
    private val context: Context,
    initialIp: String = "192.168.0.3",
    val tvPort: Int = 8765
) {
    private val prefs = context.applicationContext.getSharedPreferences("smart_console_prefs", Context.MODE_PRIVATE)

    @Volatile
    var tvIp: String = prefs.getString("saved_tv_ip", initialIp) ?: initialIp
        private set

    private val isScanning = AtomicBoolean(false)
    private var nsdManager: NsdManager? = null
    private var nsdDiscoveryListener: NsdManager.DiscoveryListener? = null

    enum class TvKey(val commandValue: String, val keycodeInt: Int) {
        DPAD_UP("UP", 19),
        DPAD_DOWN("DOWN", 20),
        DPAD_LEFT("LEFT", 21),
        DPAD_RIGHT("RIGHT", 22),
        DPAD_CENTER("OK", 23),
        BACK("BACK", 4),
        HOME("HOME", 3),
        MENU("MENU", 82),
        VOLUME_UP("VOL_UP", 24),
        VOLUME_DOWN("VOL_DOWN", 25),
        PLAY_PAUSE("PLAY_PAUSE", 85),
        POWER("POWER", 26)
    }

    enum class TvApp(val packageName: String) {
        YOUTUBE("com.google.android.youtube.tv"),
        KICK("com.kick.mobile"),
        BROWSER("com.android.chrome")
    }

    data class TvStatus(
        val ip: String,
        val isReachable: Boolean,
        val isInteractive: Boolean
    )

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(320, TimeUnit.MILLISECONDS)
        .readTimeout(320, TimeUnit.MILLISECONDS)
        .writeTimeout(320, TimeUnit.MILLISECONDS)
        .retryOnConnectionFailure(false)
        .build()

    @Volatile
    var lastKnownStatus: TvStatus = TvStatus(ip = tvIp, isReachable = false, isInteractive = false)
        private set

    init {
        startMdnsAutoDiscovery()
    }

    /**
     * Starts official Android NsdManager mDNS discovery for `_androidtvremote2._tcp.`
     * so the phone immediately locks onto the Mi TV Stick IP without slow scanning.
     */
    fun startMdnsAutoDiscovery() {
        try {
            val manager = context.applicationContext.getSystemService(Context.NSD_SERVICE) as? NsdManager ?: return
            nsdManager = manager
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(regType: String?) {}
                override fun onServiceFound(service: NsdServiceInfo?) {
                    if (service == null) return
                    try {
                        manager.resolveService(service, object : NsdManager.ResolveListener {
                            override fun onResolveFailed(serviceInfo: NsdServiceInfo?, errorCode: Int) {}
                            override fun onServiceResolved(resolvedInfo: NsdServiceInfo?) {
                                val hostIp = resolvedInfo?.host?.hostAddress
                                if (!hostIp.isNullOrBlank() && !hostIp.startsWith("127.")) {
                                    saveDiscoveredIp(hostIp)
                                }
                            }
                        })
                    } catch (_: Exception) {
                    }
                }
                override fun onServiceLost(service: NsdServiceInfo?) {}
                override fun onDiscoveryStopped(serviceType: String?) {}
                override fun onStartDiscoveryFailed(serviceType: String?, errorCode: Int) {}
                override fun onStopDiscoveryFailed(serviceType: String?, errorCode: Int) {}
            }
            nsdDiscoveryListener = listener
            manager.discoverServices("_androidtvremote2._tcp.", NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (_: Exception) {
        }
    }

    fun stopMdnsAutoDiscovery() {
        try {
            nsdDiscoveryListener?.let { nsdManager?.stopServiceDiscovery(it) }
        } catch (_: Exception) {
        }
        nsdDiscoveryListener = null
    }

    fun setManualIp(newIp: String) {
        val cleaned = newIp.trim()
        if (cleaned.isNotEmpty()) {
            tvIp = cleaned
            prefs.edit().putString("saved_tv_ip", cleaned).apply()
        }
    }

    private fun saveDiscoveredIp(foundIp: String) {
        tvIp = foundIp
        prefs.edit().putString("saved_tv_ip", foundIp).apply()
    }

    /**
     * HYBRID KEY DISPATCH:
     * Sends both the Android keycode integer (`code=19`) and key name (`k=UP`) over UDP + HTTP,
     * plus native Android TV remote bridge packet so standard keys work in all apps and launcher.
     */
    suspend fun sendKey(key: TvKey): Boolean = withContext(Dispatchers.IO) {
        // 1. Instant UDP packet with both name and Android keycode
        sendUdpFireAndForget(key.commandValue)
        sendUdpFireAndForget("KEYCODE_${key.commandValue}:${key.keycodeInt}")

        // 2. Native Android TV / ADB bridge socket injection if open
        sendNativeAndroidKeycodeBridge(key.keycodeInt)

        // 3. Custom Launcher HTTP Server endpoint on port 8765
        val ok = executeHttpGet("http://$tvIp:$tvPort/key?k=${key.commandValue}&code=${key.keycodeInt}")
        if (!ok) {
            discoverTvInSubnet()
            executeHttpGet("http://$tvIp:$tvPort/key?k=${key.commandValue}&code=${key.keycodeInt}")
        } else {
            true
        }
    }

    /**
     * Opens the custom TV Control Panel (bound to the Wi-Fi | Sliders button).
     * Sends both the custom server command and the MENU / SETTINGS keycode so the launcher opens the panel immediately.
     */
    suspend fun openTvControlPanel(): Boolean = withContext(Dispatchers.IO) {
        sendUdpFireAndForget("MENU")
        val panelOk = executeHttpGet("http://$tvIp:$tvPort/key?k=MENU&code=82")
        executeHttpGet("http://$tvIp:$tvPort/panel")
        panelOk
    }

    /**
     * Toggles TV Power / Sleep state via Hybrid Protocol.
     */
    suspend fun toggleTvPower(): Boolean = withContext(Dispatchers.IO) {
        sendUdpFireAndForget("POWER")
        sendNativeAndroidKeycodeBridge(TvKey.POWER.keycodeInt)
        val ok = executeHttpGet("http://$tvIp:$tvPort/key?k=POWER&code=26")
        ok
    }

    /**
     * Launches a target TV app package via Custom Launcher HTTP Server (`/app?pkg=...`).
     */
    suspend fun launchApp(app: TvApp): Boolean = withContext(Dispatchers.IO) {
        sendUdpFireAndForget("APP:${app.packageName}")
        val ok = executeHttpGet("http://$tvIp:$tvPort/app?pkg=${app.packageName}")
        if (!ok) {
            discoverTvInSubnet()
            executeHttpGet("http://$tvIp:$tvPort/app?pkg=${app.packageName}")
        } else {
            true
        }
    }

    /**
     * Forwards a spoken voice query to Custom Launcher HTTP Server (`/voice?text=...`).
     */
    suspend fun forwardVoiceCommandToTv(spokenText: String): Boolean = withContext(Dispatchers.IO) {
        val encodedText = try {
            URLEncoder.encode(spokenText, "UTF-8")
        } catch (_: Exception) {
            spokenText
        }
        executeHttpGet("http://$tvIp:$tvPort/voice?text=$encodedText")
    }

    /**
     * Polls current TV IP on port 8765 (or Android TV Remote port 6466).
     * If unreachable, automatically scans the local Wi-Fi subnet.
     */
    suspend fun pollScreenStatus(): TvStatus = withContext(Dispatchers.IO) {
        val launcherOpen = isPortOpen(tvIp, tvPort, 280)
        val googleRemoteOpen = if (!launcherOpen) isPortOpen(tvIp, 6466, 220) else true

        if (launcherOpen || googleRemoteOpen) {
            val status = TvStatus(ip = tvIp, isReachable = true, isInteractive = launcherOpen)
            lastKnownStatus = status
            return@withContext status
        }

        val foundIp = discoverTvInSubnet()
        val status = if (foundIp != null) {
            TvStatus(ip = foundIp, isReachable = true, isInteractive = true)
        } else {
            TvStatus(ip = tvIp, isReachable = false, isInteractive = false)
        }
        lastKnownStatus = status
        status
    }

    suspend fun forceScanSubnet(): String? = withContext(Dispatchers.IO) {
        discoverTvInSubnet()
    }

    private suspend fun discoverTvInSubnet(): String? = coroutineScope {
        if (!isScanning.compareAndSet(false, true)) {
            return@coroutineScope null
        }
        try {
            val subnetPrefix = getLocalSubnetPrefix() ?: "192.168.0"
            val phoneIp = getLocalPhoneIp()

            val priorityHosts = (2..20).map { "$subnetPrefix.$it" } +
                listOf("192.168.0.2", "192.168.0.3", "192.168.0.4", "192.168.1.2", "192.168.1.3")

            val priorityMatch = priorityHosts.distinct()
                .filter { it != phoneIp }
                .map { candidateIp ->
                    async(Dispatchers.IO) {
                        if (isPortOpen(candidateIp, tvPort, 200) || isPortOpen(candidateIp, 6466, 180)) {
                            candidateIp
                        } else null
                    }
                }.awaitAll().firstOrNull { it != null }

            if (priorityMatch != null) {
                saveDiscoveredIp(priorityMatch)
                return@coroutineScope priorityMatch
            }

            for (batchStart in 21..254 step 50) {
                val batchEnd = (batchStart + 49).coerceAtMost(254)
                val foundInBatch = (batchStart..batchEnd)
                    .map { "$subnetPrefix.$it" }
                    .filter { it != phoneIp }
                    .map { candidateIp ->
                        async(Dispatchers.IO) {
                            if (isPortOpen(candidateIp, tvPort, 150)) candidateIp else null
                        }
                    }.awaitAll().firstOrNull { it != null }

                if (foundInBatch != null) {
                    saveDiscoveredIp(foundInBatch)
                    return@coroutineScope foundInBatch
                }
            }
            null
        } finally {
            isScanning.set(false)
        }
    }

    private fun isPortOpen(ip: String, port: Int, timeoutMs: Int): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), timeoutMs)
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun getLocalPhoneIp(): String? {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (!iface.isUp || iface.isLoopback) continue
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress ?: continue
                        if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.")) {
                            return ip
                        }
                    }
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun getLocalSubnetPrefix(): String? {
        val ip = getLocalPhoneIp() ?: return null
        val lastDot = ip.lastIndexOf('.')
        return if (lastDot > 0) ip.substring(0, lastDot) else null
    }

    private fun executeHttpGet(url: String): Boolean {
        val request = Request.Builder().url(url).get().build()
        return try {
            httpClient.newCall(request).execute().use { response ->
                response.code in 200..499
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun sendUdpFireAndForget(payload: String) {
        try {
            DatagramSocket().use { udpSocket ->
                udpSocket.soTimeout = 100
                val bytes = payload.toByteArray(Charsets.UTF_8)
                val address = InetAddress.getByName(tvIp)
                val packet = DatagramPacket(bytes, bytes.size, address, tvPort)
                udpSocket.send(packet)
            }
        } catch (_: Exception) {
        }
    }

    private fun sendNativeAndroidKeycodeBridge(keyCode: Int) {
        try {
            DatagramSocket().use { udpSocket ->
                udpSocket.soTimeout = 80
                val bytes = "input keyevent $keyCode
".toByteArray(Charsets.UTF_8)
                val address = InetAddress.getByName(tvIp)
                udpSocket.send(DatagramPacket(bytes, bytes.size, address, 5555))
            }
        } catch (_: Exception) {
        }
    }
}
