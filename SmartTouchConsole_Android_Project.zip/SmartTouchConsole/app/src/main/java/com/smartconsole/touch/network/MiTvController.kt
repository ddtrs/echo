package com.smartconsole.touch.network

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Smart Auto-Discovery & Dual-Protocol (HTTP GET + UDP) Controller for Mi TV Stick on port 8765.
 */
class MiTvController(
    context: Context,
    initialIp: String = "192.168.0.3",
    val tvPort: Int = 8765
) {
    private val prefs = context.applicationContext.getSharedPreferences("smart_console_prefs", Context.MODE_PRIVATE)

    @Volatile
    var tvIp: String = prefs.getString("saved_tv_ip", initialIp) ?: initialIp
        private set

    private val isScanning = AtomicBoolean(false)

    enum class TvKey(val commandValue: String) {
        DPAD_UP("UP"),
        DPAD_DOWN("DOWN"),
        DPAD_LEFT("LEFT"),
        DPAD_RIGHT("RIGHT"),
        DPAD_CENTER("OK"),
        BACK("BACK"),
        HOME("HOME"),
        MENU("MENU"),
        VOLUME_UP("VOL_UP"),
        VOLUME_DOWN("VOL_DOWN"),
        PLAY_PAUSE("PLAY_PAUSE")
    }

    enum class TvApp(val packageName: String) {
        YOUTUBE("com.google.android.youtube.tv"),
        KICK("com.kick.mobile"),
        BROWSER("com.android.chrome")
    }

    data class TvStatus(
        val ip: String,
        val isReachable: Boolean,
        val isInteractive: Boolean
    )

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(320, TimeUnit.MILLISECONDS)
        .readTimeout(320, TimeUnit.MILLISECONDS)
        .writeTimeout(320, TimeUnit.MILLISECONDS)
        .retryOnConnectionFailure(false)
        .build()

    @Volatile
    var lastKnownStatus: TvStatus = TvStatus(ip = tvIp, isReachable = false, isInteractive = false)
        private set

    fun setManualIp(newIp: String) {
        val cleaned = newIp.trim()
        if (cleaned.isNotEmpty()) {
            tvIp = cleaned
            prefs.edit().putString("saved_tv_ip", cleaned).apply()
        }
    }

    private fun saveDiscoveredIp(foundIp: String) {
        tvIp = foundIp
        prefs.edit().putString("saved_tv_ip", foundIp).apply()
    }

    /**
     * Sends a navigation key to `http://<tvIp>:8765/key?k=<KEY>` and UDP simultaneously.
     */
    suspend fun sendKey(key: TvKey): Boolean = withContext(Dispatchers.IO) {
        sendUdpFireAndForget(key.commandValue)
        val ok = executeHttpGet("http://$tvIp:$tvPort/key?k=${key.commandValue}")
        if (!ok) {
            discoverTvInSubnet()
            executeHttpGet("http://$tvIp:$tvPort/key?k=${key.commandValue}")
        } else {
            true
        }
    }

    /**
     * Launches a target TV app package via `http://<tvIp>:8765/app?pkg=...`
     */
    suspend fun launchApp(app: TvApp): Boolean = withContext(Dispatchers.IO) {
        val ok = executeHttpGet("http://$tvIp:$tvPort/app?pkg=${app.packageName}")
        if (!ok) {
            discoverTvInSubnet()
            executeHttpGet("http://$tvIp:$tvPort/app?pkg=${app.packageName}")
        } else {
            true
        }
    }

    /**
     * Forwards a spoken voice query to `http://<tvIp>:8765/voice?text=...`
     */
    suspend fun forwardVoiceCommandToTv(spokenText: String): Boolean = withContext(Dispatchers.IO) {
        val encodedText = try {
            URLEncoder.encode(spokenText, "UTF-8")
        } catch (_: Exception) {
            spokenText
        }
        executeHttpGet("http://$tvIp:$tvPort/voice?text=$encodedText")
    }

    /**
     * Polls current TV IP on port 8765. If unreachable, automatically scans the local Wi-Fi subnet.
     */
    suspend fun pollScreenStatus(): TvStatus = withContext(Dispatchers.IO) {
        if (isPortOpen(tvIp, tvPort, 300)) {
            val status = TvStatus(ip = tvIp, isReachable = true, isInteractive = true)
            lastKnownStatus = status
            return@withContext status
        }

        val foundIp = discoverTvInSubnet()
        val status = if (foundIp != null) {
            TvStatus(ip = foundIp, isReachable = true, isInteractive = true)
        } else {
            TvStatus(ip = tvIp, isReachable = false, isInteractive = false)
        }
        lastKnownStatus = status
        status
    }

    suspend fun forceScanSubnet(): String? = withContext(Dispatchers.IO) {
        discoverTvInSubnet()
    }

    private suspend fun discoverTvInSubnet(): String? = coroutineScope {
        if (!isScanning.compareAndSet(false, true)) {
            return@coroutineScope null
        }
        try {
            val subnetPrefix = getLocalSubnetPrefix() ?: "192.168.0"
            val phoneIp = getLocalPhoneIp()

            val priorityHosts = (2..20).map { "$subnetPrefix.$it" } +
                listOf("192.168.0.2", "192.168.0.3", "192.168.0.4", "192.168.1.2", "192.168.1.3")

            val priorityMatch = priorityHosts.distinct()
                .filter { it != phoneIp }
                .map { candidateIp ->
                    async(Dispatchers.IO) {
                        if (isPortOpen(candidateIp, tvPort, 220)) candidateIp else null
                    }
                }.awaitAll().firstOrNull { it != null }

            if (priorityMatch != null) {
                saveDiscoveredIp(priorityMatch)
                return@coroutineScope priorityMatch
            }

            for (batchStart in 21..254 step 50) {
                val batchEnd = (batchStart + 49).coerceAtMost(254)
                val foundInBatch = (batchStart..batchEnd)
                    .map { "$subnetPrefix.$it" }
                    .filter { it != phoneIp }
                    .map { candidateIp ->
                        async(Dispatchers.IO) {
                            if (isPortOpen(candidateIp, tvPort, 160)) candidateIp else null
                        }
                    }.awaitAll().firstOrNull { it != null }

                if (foundInBatch != null) {
                    saveDiscoveredIp(foundInBatch)
                    return@coroutineScope foundInBatch
                }
            }
            null
        } finally {
            isScanning.set(false)
        }
    }

    private fun isPortOpen(ip: String, port: Int, timeoutMs: Int): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), timeoutMs)
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun getLocalPhoneIp(): String? {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (!iface.isUp || iface.isLoopback) continue
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress ?: continue
                        if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.")) {
                            return ip
                        }
                    }
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun getLocalSubnetPrefix(): String? {
        val ip = getLocalPhoneIp() ?: return null
        val lastDot = ip.lastIndexOf('.')
        return if (lastDot > 0) ip.substring(0, lastDot) else null
    }

    private fun executeHttpGet(url: String): Boolean {
        val request = Request.Builder().url(url).get().build()
        return try {
            httpClient.newCall(request).execute().use { response ->
                response.code in 200..499
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun sendUdpFireAndForget(payload: String) {
        try {
            DatagramSocket().use { udpSocket ->
                udpSocket.soTimeout = 120
                val bytes = payload.toByteArray(Charsets.UTF_8)
                val address = InetAddress.getByName(tvIp)
                val packet = DatagramPacket(bytes, bytes.size, address, tvPort)
                udpSocket.send(packet)
            }
        } catch (_: Exception) {
        }
    }
}
