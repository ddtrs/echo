package com.smartconsole.touch.network

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Smart Auto-Discovery & Dual-Protocol (HTTP GET + UDP) Controller for Mi TV Stick on port 8765.
 *
 * Features:
 * 1. Automatic Subnet Discovery: If current IP (e.g., 192.168.0.2) stops responding because DHCP
 *    reassigned the TV to 192.168.0.3 (or any other IP in the subnet), it scans the local Wi-Fi
 *    subnet in parallel for open port 8765 and updates the IP automatically.
 * 2. Persistent IP Cache: Saves the last working IP in SharedPreferences.
 * 3. Dual-Protocol Delivery: Sends both HTTP GET (`http://<ip>:8765/key?k=...`) AND raw UDP packets
 *    so that whichever protocol the TV listener uses, commands arrive instantaneously.
 */
class MiTvController(
    context: Context,
    initialIp: String = "192.168.0.3",
    val tvPort: Int = 8765
) {
    private val prefs = context.applicationContext.getSharedPreferences("smart_console_prefs", Context.MODE_PRIVATE)

    @Volatile
    var tvIp: String = prefs.getString("saved_tv_ip", initialIp) ?: initialIp
        private set

    private val isScanning = AtomicBoolean(false)

    enum class TvKey(val commandValue: String, val androidKeycode: String) {
        DPAD_UP("DPAD_UP", "KEYCODE_DPAD_UP"),
        DPAD_DOWN("DPAD_DOWN", "KEYCODE_DPAD_DOWN"),
        DPAD_LEFT("DPAD_LEFT", "KEYCODE_DPAD_LEFT"),
        DPAD_RIGHT("DPAD_RIGHT", "KEYCODE_DPAD_RIGHT"),
        DPAD_CENTER("DPAD_CENTER", "KEYCODE_DPAD_CENTER"),
        BACK("BACK", "KEYCODE_BACK"),
        HOME("HOME", "KEYCODE_HOME"),
        VOLUME_UP("VOL_UP", "KEYCODE_VOLUME_UP"),
        VOLUME_DOWN("VOL_DOWN", "KEYCODE_VOLUME_DOWN"),
        PLAY_PAUSE("PLAY_PAUSE", "KEYCODE_MEDIA_PLAY_PAUSE")
    }

    enum class TvApp(val packageName: String) {
        YOUTUBE("com.google.android.youtube.tv"),
        KICK("com.kick.mobile"),
        BROWSER("com.android.chrome")
    }

    data class TvStatus(
        val ip: String,
        val isReachable: Boolean,
        val isInteractive: Boolean,
        val isScanning: Boolean = false
    )

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(350, TimeUnit.MILLISECONDS)
        .readTimeout(350, TimeUnit.MILLISECONDS)
        .writeTimeout(350, TimeUnit.MILLISECONDS)
        .retryOnConnectionFailure(false)
        .build()

    @Volatile
    var lastKnownStatus: TvStatus = TvStatus(ip = tvIp, isReachable = false, isInteractive = false)
        private set

    fun setManualIp(newIp: String) {
        val cleaned = newIp.trim()
        if (cleaned.isNotEmpty()) {
            tvIp = cleaned
            prefs.edit().putString("saved_tv_ip", cleaned).apply()
        }
    }

    private fun saveDiscoveredIp(foundIp: String) {
        tvIp = foundIp
        prefs.edit().putString("saved_tv_ip", foundIp).apply()
    }

    /**
     * Sends a navigation key via HTTP GET and UDP packet simultaneously.
     * If connection fails, triggers a fast background subnet scan.
     */
    suspend fun sendKey(key: TvKey): Boolean = withContext(Dispatchers.IO) {
        sendUdpFireAndForget("KEY:${key.commandValue}")
        val ok = executeHttpGet("http://$tvIp:$tvPort/key?k=${key.commandValue}")
        if (!ok) {
            // Try fallback query param name or keycode just in case custom launcher expects it
            val okAlt = executeHttpGet("http://$tvIp:$tvPort/key?code=${key.androidKeycode}")
            if (!okAlt) {
                discoverTvInSubnet()
                executeHttpGet("http://$tvIp:$tvPort/key?k=${key.commandValue}")
            } else true
        } else {
            true
        }
    }

    /**
     * Launches a target TV app package via HTTP GET and UDP.
     */
    suspend fun launchApp(app: TvApp): Boolean = withContext(Dispatchers.IO) {
        sendUdpFireAndForget("APP:${app.packageName}")
        val ok = executeHttpGet("http://$tvIp:$tvPort/app?pkg=${app.packageName}")
        if (!ok) {
            discoverTvInSubnet()
            executeHttpGet("http://$tvIp:$tvPort/app?pkg=${app.packageName}")
        } else {
            true
        }
    }

    /**
     * Forwards a spoken voice query to the TV launcher overlay.
     */
    suspend fun forwardVoiceCommandToTv(spokenText: String): Boolean = withContext(Dispatchers.IO) {
        sendUdpFireAndForget("VOICE:$spokenText")
        val encodedText = try {
            URLEncoder.encode(spokenText, "UTF-8")
        } catch (_: Exception) {
            spokenText
        }
        executeHttpGet("http://$tvIp:$tvPort/voice?text=$encodedText")
    }

    /**
     * Polls current TV IP on port 8765. If unreachable, automatically scans the local Wi-Fi subnet
     * (prioritizing .2, .3, .4, .5... and the phone's own /24 subnet) to find the new TV IP.
     */
    suspend fun pollScreenStatus(): TvStatus = withContext(Dispatchers.IO) {
        if (isPortOpen(tvIp, tvPort, 300)) {
            val status = TvStatus(ip = tvIp, isReachable = true, isInteractive = true, isScanning = false)
            lastKnownStatus = status
            return@withContext status
        }

        // Current IP did not answer -> run auto-discovery across local subnet
        val foundIp = discoverTvInSubnet()
        val status = if (foundIp != null) {
            TvStatus(ip = foundIp, isReachable = true, isInteractive = true, isScanning = false)
        } else {
            TvStatus(ip = tvIp, isReachable = false, isInteractive = false, isScanning = isScanning.get())
        }
        lastKnownStatus = status
        status
    }

    /**
     * Forces an immediate scan of the local Wi-Fi subnet for port 8765.
     */
    suspend fun forceScanSubnet(): String? = withContext(Dispatchers.IO) {
        discoverTvInSubnet()
    }

    private suspend fun discoverTvInSubnet(): String? = coroutineScope {
        if (!isScanning.compareAndSet(false, true)) {
            return@coroutineScope null
        }
        try {
            val subnetPrefix = getLocalSubnetPrefix() ?: "192.168.0"
            val phoneIp = getLocalPhoneIp()

            // First check the most likely home router DHCP addresses (.2 to .20) with a generous 250ms timeout
            val priorityHosts = (2..20).map { "$subnetPrefix.$it" } +
                listOf("192.168.0.2", "192.168.0.3", "192.168.0.4", "192.168.1.2", "192.168.1.3")

            val priorityMatch = priorityHosts.distinct()
                .filter { it != phoneIp }
                .map { candidateIp ->
                    async(Dispatchers.IO) {
                        if (isPortOpen(candidateIp, tvPort, 220)) candidateIp else null
                    }
                }.awaitAll().firstOrNull { it != null }

            if (priorityMatch != null) {
                saveDiscoveredIp(priorityMatch)
                return@coroutineScope priorityMatch
            }

            // Full /24 subnet scan in parallel batches of 50 IPs
            for (batchStart in 21..254 step 50) {
                val batchEnd = (batchStart + 49).coerceAtMost(254)
                val foundInBatch = (batchStart..batchEnd)
                    .map { "$subnetPrefix.$it" }
                    .filter { it != phoneIp }
                    .map { candidateIp ->
                        async(Dispatchers.IO) {
                            if (isPortOpen(candidateIp, tvPort, 160)) candidateIp else null
                        }
                    }.awaitAll().firstOrNull { it != null }

                if (foundInBatch != null) {
                    saveDiscoveredIp(foundInBatch)
                    return@coroutineScope foundInBatch
                }
            }
            null
        } finally {
            isScanning.set(false)
        }
    }

    private fun isPortOpen(ip: String, port: Int, timeoutMs: Int): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), timeoutMs)
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun getLocalPhoneIp(): String? {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (!iface.isUp || iface.isLoopback) continue
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress ?: continue
                        if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.")) {
                            return ip
                        }
                    }
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun getLocalSubnetPrefix(): String? {
        val ip = getLocalPhoneIp() ?: return null
        val lastDot = ip.lastIndexOf('.')
        return if (lastDot > 0) ip.substring(0, lastDot) else null
    }

    private fun executeHttpGet(url: String): Boolean {
        val request = Request.Builder().url(url).get().build()
        return try {
            httpClient.newCall(request).execute().use { response ->
                response.code in 200..499
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun sendUdpFireAndForget(payload: String) {
        try {
            DatagramSocket().use { udpSocket ->
                udpSocket.soTimeout = 150
                val bytes = payload.toByteArray(Charsets.UTF_8)
                val address = InetAddress.getByName(tvIp)
                val packet = DatagramPacket(bytes, bytes.size, address, tvPort)
                udpSocket.send(packet)
            }
        } catch (_: Exception) {
        }
    }
}
