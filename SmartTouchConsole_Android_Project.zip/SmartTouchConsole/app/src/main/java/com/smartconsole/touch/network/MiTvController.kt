package com.smartconsole.touch.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Ultra-lightweight network controller for Mi TV Stick custom launcher on port 8765.
 * Replaces ProcessBuilder ADB commands with fast HTTP GET / socket requests (300 ms timeout),
 * running fully asynchronously on Dispatchers.IO.
 */
class MiTvController(
    val tvIp: String = "192.168.0.2",
    val tvPort: Int = 8765
) {
    enum class TvKey(val commandValue: String) {
        DPAD_UP("DPAD_UP"),
        DPAD_DOWN("DPAD_DOWN"),
        DPAD_LEFT("DPAD_LEFT"),
        DPAD_RIGHT("DPAD_RIGHT"),
        DPAD_CENTER("DPAD_CENTER"),
        BACK("BACK"),
        HOME("HOME"),
        VOLUME_UP("VOL_UP"),
        VOLUME_DOWN("VOL_DOWN"),
        PLAY_PAUSE("PLAY_PAUSE")
    }

    enum class TvApp(val packageName: String) {
        YOUTUBE("com.google.android.youtube.tv"),
        KICK("com.kick.mobile"),
        BROWSER("com.android.chrome")
    }

    data class TvStatus(
        val isReachable: Boolean,
        val isInteractive: Boolean
    )

    private val baseUrl = "http://$tvIp:$tvPort"

    // Fast OkHttpClient with 300 ms timeout as specified in requirements
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(300, TimeUnit.MILLISECONDS)
        .readTimeout(300, TimeUnit.MILLISECONDS)
        .writeTimeout(300, TimeUnit.MILLISECONDS)
        .retryOnConnectionFailure(false)
        .build()

    @Volatile
    var lastKnownStatus: TvStatus = TvStatus(isReachable = false, isInteractive = false)
        private set

    /**
     * Sends a remote navigation key to the TV launcher:
     * GET http://192.168.0.2:8765/key?k=DPAD_UP
     */
    suspend fun sendKey(key: TvKey): Boolean = withContext(Dispatchers.IO) {
        executeHttpGet("$baseUrl/key?k=${key.commandValue}")
    }

    /**
     * Launches a target TV package via launcher endpoint:
     * GET http://192.168.0.2:8765/app?pkg=com.google.android.youtube.tv
     */
    suspend fun launchApp(app: TvApp): Boolean = withContext(Dispatchers.IO) {
        executeHttpGet("$baseUrl/app?pkg=${app.packageName}")
    }

    /**
     * Forwards a voice command directly to the TV launcher overlay:
     * GET http://192.168.0.2:8765/voice?text=...
     */
    suspend fun forwardVoiceCommandToTv(spokenText: String): Boolean = withContext(Dispatchers.IO) {
        val encodedText = try {
            URLEncoder.encode(spokenText, "UTF-8")
        } catch (_: Exception) {
            spokenText
        }
        executeHttpGet("$baseUrl/voice?text=$encodedText")
    }

    /**
     * Fast check of socket/HTTP availability on 192.168.0.2:8765.
     * If responds -> "Экран: ВКЛ" (isInteractive = true).
     * If timeout or error -> "Экран: СПИТ" (isInteractive = false).
     */
    suspend fun pollScreenStatus(): TvStatus = withContext(Dispatchers.IO) {
        val reachable = try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(tvIp, tvPort), 300)
                true
            }
        } catch (_: Exception) {
            false
        }

        val status = if (reachable) {
            TvStatus(isReachable = true, isInteractive = true)
        } else {
            TvStatus(isReachable = false, isInteractive = false)
        }

        lastKnownStatus = status
        status
    }

    private fun executeHttpGet(url: String): Boolean {
        val request = Request.Builder().url(url).get().build()
        return try {
            httpClient.newCall(request).execute().use { response ->
                response.isSuccessful
            }
        } catch (_: Exception) {
            false
        }
    }
}
