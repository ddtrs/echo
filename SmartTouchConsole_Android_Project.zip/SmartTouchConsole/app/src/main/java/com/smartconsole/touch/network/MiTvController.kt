package com.smartconsole.touch.network

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * HYBRID TV CONTROLLER (Google Android TV Remote Protocol v2 + Custom TV Launcher Server Port 8765):
 *
 * 1. Navigation & System Keys (`UP`, `DOWN`, `LEFT`, `RIGHT`, `OK`, `BACK`, `HOME`, `VOL_UP`, `VOL_DOWN`, `POWER`)
 *    go through `AtvRemoteClient` (Google Remote TLS port 6466) AND fall back to the Launcher server (`:8765/key`).
 * 2. TV Control Center (`openTvControlPanel`):
 *    Sends `GET http://<tvIp>:8765/key?k=MENU` (plus `k=CONTROL_CENTER` and `k=PATCHWALL`) to open the
 *    custom control dashboard on the TV screen.
 * 3. Bidirectional Smart Light Sync (`syncLightToTv` & `pollScreenStatus`):
 *    - When phone changes light power, preset, hue, or brightness, immediately notifies
 *      `GET http://<tvIp>:8765/light?power=...&preset=...&bright=...` so the TV dashboard updates in real time.
 *    - `pollScreenStatus()` calls `GET http://<tvIp>:8765/status`, reading `ledOn`, `ledMode`, `ledBright`,
 *      and `volume` so the phone's color wheel and sliders stay 100% synchronized when changed from the TV!
 */
class MiTvController(
    private val context: Context,
    initialIp: String = "192.168.0.3",
    val tvPort: Int = 8765
) {
    private val prefs = context.applicationContext.getSharedPreferences("smart_console_prefs", Context.MODE_PRIVATE)

    val remote = AtvRemoteClient(context)

    var onPairingRequired: (() -> Unit)? = null
    private var lastPairingPromptAtMs = 0L

    private fun notifyPairingNeeded() {
        val now = System.currentTimeMillis()
        if (now - lastPairingPromptAtMs > 25_000L) {
            lastPairingPromptAtMs = now
            onPairingRequired?.invoke()
        }
    }

    suspend fun beginPairing(): Boolean = remote.beginPairing(tvIp)
    suspend fun finishPairing(code: String): Boolean = remote.finishPairing(code)

    @Volatile
    var tvIp: String = prefs.getString("saved_tv_ip", initialIp) ?: initialIp
        private set

    private val isScanning = AtomicBoolean(false)
    private var nsdManager: NsdManager? = null
    private var nsdDiscoveryListener: NsdManager.DiscoveryListener? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    /** Timestamp of last phone-initiated light action so polling doesn't overwrite in-flight changes. */
    @Volatile
    var lastLocalLightChangeMs: Long = 0L

    enum class TvKey(val commandValue: String, val keycodeInt: Int) {
        DPAD_UP("UP", 19),
        DPAD_DOWN("DOWN", 20),
        DPAD_LEFT("LEFT", 21),
        DPAD_RIGHT("RIGHT", 22),
        DPAD_CENTER("OK", 23),
        BACK("BACK", 4),
        HOME("HOME", 3),
        MENU("MENU", 82),
        VOLUME_UP("VOL_UP", 24),
        VOLUME_DOWN("VOL_DOWN", 25),
        PLAY_PAUSE("PLAY_PAUSE", 85),
        POWER("POWER", 26)
    }

    enum class TvApp(val packageName: String, val deepLink: String) {
        YOUTUBE("com.google.android.youtube.tv", "https://www.youtube.com"),
        KICK("com.kick.mobile", "https://kick.com"),
        BROWSER("com.android.chrome", "https://www.google.com")
    }

    data class TvStatus(
        val ip: String,
        val isReachable: Boolean,
        val isInteractive: Boolean,
        val ledOn: Boolean? = null,
        val ledMode: String? = null,
        val ledBright: Int? = null,
        val volumePercent: Int? = null
    )

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(320, TimeUnit.MILLISECONDS)
        .readTimeout(350, TimeUnit.MILLISECONDS)
        .writeTimeout(320, TimeUnit.MILLISECONDS)
        .retryOnConnectionFailure(false)
        .build()

    @Volatile
    var lastKnownStatus: TvStatus = TvStatus(ip = tvIp, isReachable = false, isInteractive = false)
        private set

    @Volatile
    private var statusPolledOnce = false
    private val reconnecting = AtomicBoolean(false)
    @Volatile
    private var lastAutoReconnectAtMs = 0L

    init {
        startMdnsAutoDiscovery()
    }

    /**
     * Acquires WifiManager.MulticastLock (critical on Huawei EMUI so mDNS packets aren't dropped)
     * and starts official Android NsdManager discovery for `_androidtvremote2._tcp.`.
     */
    fun startMdnsAutoDiscovery() {
        try {
            val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            if (multicastLock == null && wifi != null) {
                multicastLock = wifi.createMulticastLock("smart_console_mdns").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }
        } catch (_: Exception) {
        }

        try {
            val manager = context.applicationContext.getSystemService(Context.NSD_SERVICE) as? NsdManager ?: return
            nsdManager = manager
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(regType: String?) {}
                override fun onServiceFound(service: NsdServiceInfo?) {
                    if (service == null) return
                    try {
                        manager.resolveService(service, object : NsdManager.ResolveListener {
                            override fun onResolveFailed(serviceInfo: NsdServiceInfo?, errorCode: Int) {}
                            override fun onServiceResolved(resolvedInfo: NsdServiceInfo?) {
                                val hostIp = resolvedInfo?.host?.hostAddress
                                if (!hostIp.isNullOrBlank() && !hostIp.startsWith("127.")) {
                                    considerDiscoveredIp(hostIp)
                                }
                            }
                        })
                    } catch (_: Exception) {
                    }
                }
                override fun onServiceLost(service: NsdServiceInfo?) {}
                override fun onDiscoveryStopped(serviceType: String?) {}
                override fun onStartDiscoveryFailed(serviceType: String?, errorCode: Int) {}
                override fun onStopDiscoveryFailed(serviceType: String?, errorCode: Int) {}
            }
            nsdDiscoveryListener = listener
            manager.discoverServices("_androidtvremote2._tcp.", NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (_: Exception) {
        }
    }

    fun stopMdnsAutoDiscovery() {
        try {
            nsdDiscoveryListener?.let { nsdManager?.stopServiceDiscovery(it) }
        } catch (_: Exception) {
        }
        nsdDiscoveryListener = null
        try {
            if (multicastLock?.isHeld == true) multicastLock?.release()
        } catch (_: Exception) {
        }
        remote.disconnect()
    }

    fun setManualIp(newIp: String) {
        val cleaned = newIp.trim()
        if (cleaned.isNotEmpty()) {
            tvIp = cleaned
            prefs.edit().putString("saved_tv_ip", cleaned).apply()
        }
    }

    private fun saveDiscoveredIp(foundIp: String) {
        tvIp = foundIp
        prefs.edit().putString("saved_tv_ip", foundIp).apply()
    }

    /**
     * mDNS finds ANY `_androidtvremote2` device (Chromecast, another Android TV...). Accept the address only
     * if it is the one we already use, or if the saved address does not answer at all.
     */
    private fun considerDiscoveredIp(foundIp: String) {
        if (foundIp == tvIp) return
        Thread {
            val current = tvIp
            val savedAlive = isPortOpen(current, tvPort, 600) || isPortOpen(current, 6466, 600)
            if (!savedAlive && foundIp != current) saveDiscoveredIp(foundIp)
        }.apply { isDaemon = true; name = "mdns-ip-check" }.start()
    }

    /**
     * Key dispatch: Google Android TV Remote first + Launcher server on 8765.
     */
    /** True once the first status poll has finished and it said the TV does not answer. */
    private fun tvKnownDown(): Boolean = statusPolledOnce && !lastKnownStatus.isReachable && !remote.isConnected

    suspend fun sendKey(key: TvKey): Boolean = withContext(Dispatchers.IO) {
        if (tvKnownDown()) return@withContext sendKeyViaLauncherServer(key)
        when (remote.sendKey(key.keycodeInt, tvIp)) {
            AtvRemoteClient.SendResult.OK -> true
            AtvRemoteClient.SendResult.UNPAIRED -> {
                notifyPairingNeeded()
                sendKeyViaLauncherServer(key)
            }
            AtvRemoteClient.SendResult.UNREACHABLE -> sendKeyViaLauncherServer(key)
        }
    }

    private fun sendKeyViaLauncherServer(key: TvKey): Boolean {
        sendUdpFireAndForget(key.commandValue)
        val url = "http://$tvIp:$tvPort/key?k=${key.commandValue}&code=${key.keycodeInt}"
        return executeHttpGet(url)
    }

    /**
     * Opens / closes the custom TV Control Center on the TV screen:
     * Sends `GET http://<tvIp>:8765/key?k=MENU` (and `k=CONTROL_CENTER`) directly to the TV launcher server!
     */
    suspend fun openTvControlPanel(): Boolean = withContext(Dispatchers.IO) {
        sendUdpFireAndForget("MENU")
        val menuOk = executeHttpGet("http://$tvIp:$tvPort/key?k=MENU")
        if (!menuOk) {
            val ccOk = executeHttpGet("http://$tvIp:$tvPort/key?k=CONTROL_CENTER")
            if (!ccOk) {
                discoverTvInSubnet()
                executeHttpGet("http://$tvIp:$tvPort/key?k=MENU")
            } else true
        } else {
            true
        }
    }

    /**
     * Synchronizes light state from Phone -> TV Launcher (`GET /light?...`) so the TV's
     * on-screen studio dashboard immediately reflects power, preset/hue, and brightness.
     */
    /**
     * Synchronizes light state to TV launcher server with exact degrees (h=0..360), saturation (s=0..100),
     * brightness, and human name so TV displays exact "Спектр: 125° · Лайм" without snapping back!
     */
    suspend fun syncLightToTv(
        power: Boolean? = null,
        presetId: String? = null,
        hue: Int? = null,
        satPercent: Int? = null,
        brightPercent: Int? = null,
        colorName: String? = null
    ): Boolean = withContext(Dispatchers.IO) {
        lastLocalLightChangeMs = System.currentTimeMillis()
        val params = mutableListOf<String>()
        if (power != null) params.add("power=$power")
        if (!presetId.isNullOrBlank()) {
            val encoded = try { URLEncoder.encode(presetId, "UTF-8") } catch (_: Exception) { presetId }
            params.add("preset=$encoded")
        }
        if (hue != null) params.add("h=$hue")
        if (satPercent != null) params.add("s=${satPercent.coerceIn(5, 100)}")
        if (brightPercent != null) params.add("bright=${brightPercent.coerceIn(5, 100)}")
        if (!colorName.isNullOrBlank()) {
            val encName = try { URLEncoder.encode(colorName, "UTF-8") } catch (_: Exception) { colorName }
            params.add("name=$encName")
        }
        if (params.isEmpty()) return@withContext false

        val query = params.joinToString("&")
        executeHttpGet("http://$tvIp:$tvPort/light?$query")
    }

    /**
     * Maps arbitrary hue (0..360) and saturation (0..100) to the closest preset name understood by the TV server.
     */
    fun getFriendlyColorName(hue: Int, satPercent: Int): String {
        if (satPercent <= 30) return "Тёплый белый"
        val h = ((hue % 360) + 360) % 360
        return when (h) {
            in 0..15 -> "Красный"
            in 16..30 -> "Закат"
            in 31..55 -> "Янтарь"
            in 56..80 -> "Жёлтый"
            in 81..110 -> "Лайм"
            in 111..150 -> "Зелёный"
            in 151..190 -> "Изумруд / Океан"
            in 191..220 -> "Кибер / Голубой"
            in 221..255 -> "Сапфир"
            in 256..285 -> "Фиолет"
            in 286..325 -> "Малина / Фуксия"
            else -> "Красный"
        }
    }
    fun mapHueToTvPresetId(hue: Int, satPercent: Int): String {
        if (satPercent <= 35 && hue in 15..55) return "warm"
        val h = ((hue % 360) + 360) % 360
        return when (h) {
            in 0..26 -> "sunset"
            in 27..52 -> if (satPercent <= 45) "warm" else "sunset"
            in 53..199 -> "cyber"
            in 200..248 -> "sapphire"
            in 249..305 -> "violet"
            else -> "raspberry"
        }
    }

    suspend fun toggleTvPower(): Boolean = sendKey(TvKey.POWER)

    suspend fun launchApp(app: TvApp): Boolean = withContext(Dispatchers.IO) {
        sendUdpFireAndForget("APP:${app.packageName}")
        val ok = executeHttpGet("http://$tvIp:$tvPort/app?pkg=${app.packageName}")
        if (ok) {
            true
        } else if (tvKnownDown()) {
            false
        } else {
            remote.openAppLink(app.deepLink, tvIp) == AtvRemoteClient.SendResult.OK
        }
    }

    /**
     * Called after every status poll. Keeps the Google Remote channel alive without waiting for a button press:
     * reconnects (with a pause between attempts) whenever the TV answers but the channel is not connected,
     * and drops the dead channel as soon as the TV stops answering.
     */
    suspend fun maintainRemoteConnection(status: TvStatus) = withContext(Dispatchers.IO) {
        if (!status.isReachable) {
            if (remote.hasSocket) remote.disconnect()
            return@withContext
        }
        if (remote.isConnected || !remote.isPaired) return@withContext
        val now = System.currentTimeMillis()
        if (now - lastAutoReconnectAtMs < 4000L) return@withContext
        if (!reconnecting.compareAndSet(false, true)) return@withContext
        try {
            lastAutoReconnectAtMs = now
            remote.warmUp(tvIp)
        } finally {
            lastAutoReconnectAtMs = System.currentTimeMillis()
            reconnecting.set(false)
        }
    }

    suspend fun warmUpRemote() {
        when (remote.warmUp(tvIp)) {
            AtvRemoteClient.SendResult.UNPAIRED -> notifyPairingNeeded()
            else -> {}
        }
    }

    suspend fun forwardVoiceCommandToTv(spokenText: String): Boolean = withContext(Dispatchers.IO) {
        val encodedText = try {
            URLEncoder.encode(spokenText, "UTF-8")
        } catch (_: Exception) {
            spokenText
        }
        executeHttpGet("http://$tvIp:$tvPort/voice?text=$encodedText")
    }

    /**
     * Polls `GET http://<tvIp>:8765/status` (or `/ping`) to read both TV screen status AND
     * live LED strip state (`ledOn`, `ledMode`, `ledBright`) so the phone UI stays 100% in sync with the TV!
     */
    suspend fun pollScreenStatus(): TvStatus = withContext(Dispatchers.IO) {
        val statusJsonStr = executeHttpGetWithBody("http://$tvIp:$tvPort/status")
            ?: executeHttpGetWithBody("http://$tvIp:$tvPort/ping")

        if (statusJsonStr != null) {
            try {
                val json = JSONObject(statusJsonStr)
                val screenState = json.optString("screenState", "ON")
                val interactive = if (json.has("isInteractive")) {
                    json.optBoolean("isInteractive", true)
                } else {
                    !screenState.equals("OFF", ignoreCase = true) && !screenState.equals("SLEEP", ignoreCase = true)
                }
                val ledOn = if (json.has("ledOn")) json.optBoolean("ledOn") else null
                val ledMode = if (json.has("ledMode")) json.optString("ledMode").takeIf { it.isNotBlank() } else null
                val ledBright = if (json.has("ledBright")) json.optInt("ledBright", -1).takeIf { it in 1..100 } else null
                val volPct = when {
                    json.has("volumePercent") -> json.optInt("volumePercent", -1).takeIf { it in 0..100 }
                    json.has("volume") -> json.optInt("volume", -1).takeIf { it in 0..100 }
                    else -> null
                }

                val status = TvStatus(
                    ip = tvIp,
                    isReachable = true,
                    isInteractive = interactive,
                    ledOn = ledOn,
                    ledMode = ledMode,
                    ledBright = ledBright,
                    volumePercent = volPct
                )
                lastKnownStatus = status
                statusPolledOnce = true
                return@withContext status
            } catch (_: Exception) {
            }
        }

        val launcherOpen = isPortOpen(tvIp, tvPort, 260)
        val googleRemoteOpen = if (!launcherOpen) isPortOpen(tvIp, 6466, 220) else true

        if (launcherOpen || googleRemoteOpen) {
            val status = TvStatus(ip = tvIp, isReachable = true, isInteractive = true)
            lastKnownStatus = status
                statusPolledOnce = true
            return@withContext status
        }

        // The TV has a reserved IP (192.168.0.3): no subnet scan here, it only loaded the phone and network.
        val status = TvStatus(ip = tvIp, isReachable = false, isInteractive = false)
        lastKnownStatus = status
        statusPolledOnce = true
        status
    }

    suspend fun forceScanSubnet(): String? = withContext(Dispatchers.IO) {
        discoverTvInSubnet()
    }

    private suspend fun discoverTvInSubnet(): String? = coroutineScope {
        if (!isScanning.compareAndSet(false, true)) {
            return@coroutineScope null
        }
        try {
            val subnetPrefix = getLocalSubnetPrefix() ?: "192.168.0"
            val phoneIp = getLocalPhoneIp()

            val priorityHosts = (2..20).map { "$subnetPrefix.$it" } +
                listOf("192.168.0.2", "192.168.0.3", "192.168.0.4", "192.168.1.2", "192.168.1.3")

            val priorityMatch = priorityHosts.distinct()
                .filter { it != phoneIp }
                .map { candidateIp ->
                    async(Dispatchers.IO) {
                        if (isPortOpen(candidateIp, tvPort, 200) || isPortOpen(candidateIp, 6466, 180)) {
                            candidateIp
                        } else null
                    }
                }.awaitAll().firstOrNull { it != null }

            if (priorityMatch != null) {
                saveDiscoveredIp(priorityMatch)
                return@coroutineScope priorityMatch
            }

            for (batchStart in 21..254 step 50) {
                val batchEnd = (batchStart + 49).coerceAtMost(254)
                val foundInBatch = (batchStart..batchEnd)
                    .map { "$subnetPrefix.$it" }
                    .filter { it != phoneIp }
                    .map { candidateIp ->
                        async(Dispatchers.IO) {
                            if (isPortOpen(candidateIp, tvPort, 150)) candidateIp else null
                        }
                    }.awaitAll().firstOrNull { it != null }

                if (foundInBatch != null) {
                    saveDiscoveredIp(foundInBatch)
                    return@coroutineScope foundInBatch
                }
            }
            null
        } finally {
            isScanning.set(false)
        }
    }

    private fun isPortOpen(ip: String, port: Int, timeoutMs: Int): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), timeoutMs)
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun getLocalPhoneIp(): String? {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (!iface.isUp || iface.isLoopback) continue
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress ?: continue
                        if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.")) {
                            return ip
                        }
                    }
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun getLocalSubnetPrefix(): String? {
        val ip = getLocalPhoneIp() ?: return null
        val lastDot = ip.lastIndexOf('.')
        return if (lastDot > 0) ip.substring(0, lastDot) else null
    }

    private fun executeHttpGet(url: String): Boolean {
        val request = Request.Builder().url(url).get().build()
        return try {
            httpClient.newCall(request).execute().use { response ->
                response.code in 200..499
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun executeHttpGetWithBody(url: String): String? {
        val request = Request.Builder().url(url).get().build()
        return try {
            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) response.body?.string() else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun sendUdpFireAndForget(payload: String) {
        try {
            DatagramSocket().use { udpSocket ->
                udpSocket.soTimeout = 100
                val bytes = payload.toByteArray(Charsets.UTF_8)
                val address = InetAddress.getByName(tvIp)
                val packet = DatagramPacket(bytes, bytes.size, address, tvPort)
                udpSocket.send(packet)
            }
        } catch (_: Exception) {
        }
    }
}
