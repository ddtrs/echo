package com.smartconsole.touch

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognizerIntent
import android.text.InputFilter
import android.text.InputType
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.smartconsole.touch.databinding.ActivityMainBinding
import com.smartconsole.touch.network.MiTvController
import com.smartconsole.touch.network.TuyaController
import com.smartconsole.touch.ui.PressEffect
import com.smartconsole.touch.ui.TouchClickpadView
import com.smartconsole.touch.voice.VoiceAssistantEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    enum class ConsoleMode {
        TV_REMOTE,
        LIGHT_STRIP,
        LIGHT_SCONCE,
        LIGHT_SYNC
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var miTvController: MiTvController
    private val tuyaController = TuyaController()
    private var voiceEngine: VoiceAssistantEngine? = null

    private var clockAndStatusJob: Job? = null
    private var tvLightSyncJob: Job? = null
    private var neonPulseAnimator: ObjectAnimator? = null

    private var currentMode: ConsoleMode = ConsoleMode.TV_REMOTE
    private var isHubOpen: Boolean = false

    // Tuya & TV synchronized light state
    private var isStripOn: Boolean = true
    private var isSconceOn: Boolean = false
    private var currentHue: Float = 271f
    private var currentSatPercent: Int = 95
    private var currentBrightPercent: Int = 100
    private var activePreset: TuyaController.LightPreset? = TuyaController.LightPreset.VIOLET
    private var isBulbWhiteMode: Boolean = false
    private var currentWhiteTempPromille: Int = 500
    private var activeWhiteTempSwatch: Int? = 500
    private val whiteTempPresets = listOf(0, 200, 400, 600, 800, 1000)

    // Real TV Volume % (synchronized from AtvRemoteClient / TV status)
    private var tvVolumePercent: Int = 45

    private val timeFormat = SimpleDateFormat("HH:mm", Locale("ru", "RU"))
    private val dateFormat = SimpleDateFormat("EE · d MMM", Locale("ru", "RU"))

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) {
                val pct = (level * 100) / scale
                updateBatteryAmbientUi(pct)
            }
        }
    }

    private val speechDialogLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = matches?.firstOrNull()?.trim().orEmpty()
            if (spokenText.isNotEmpty()) {
                animateTopNeonVoiceLine(true)
                voiceEngine?.handleRecognizedCommand(spokenText, fromDirectTap = true)
                binding.root.postDelayed({ animateTopNeonVoiceLine(false) }, 800L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Disable Huawei speakerphone noise-suppression filter for far-field voice recognition
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            am?.setParameters("noise_suppression=off;ec_supported=off")
        } catch (_: Exception) {
        }

        miTvController = MiTvController(context = this, initialIp = "192.168.0.3", tvPort = 8765)

        lockImmersiveFullscreen()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        setupTopPowerAndPairingActions()
        setupTvClickpadAndButtons()
        setupLightColorWheelAndSliders()
        setupBottomSwipeHubDrawer()
        setupVoiceIslandFallback()
        setupPressEffects()
        setupBackendCallbacks()
        startClockAndTvPolling()
        checkAudioPermissionAndStartVoiceEngine()
    }

    private fun setupPressEffects() {
        PressEffect.attachAll(
            binding.btnBack, binding.btnHome, binding.btnPlayPause,
            binding.btnQuickTvSettings, binding.btnQuickYoutube, binding.btnQuickKick, binding.btnQuickBrowser,
            binding.btnTvPowerToggle,
            binding.cardHubTv, binding.cardHubSync, binding.cardHubStrip, binding.cardHubSconce,
            binding.tabBulbColor, binding.tabBulbWhite
        )
    }

    private var lastErrorToastAtMs = 0L
    private var pairingDialogShowing = false

    private fun setupBackendCallbacks() {
        tuyaController.onError = { message ->
            runOnUiThread {
                val now = System.currentTimeMillis()
                if (now - lastErrorToastAtMs > 5000L) {
                    lastErrorToastAtMs = now
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                }
            }
        }
        miTvController.onPairingRequired = { runOnUiThread { showPairingFlow() } }

        // Listen for real-time volume updates directly from the Android TV Remote protocol (field 50)
        miTvController.remote.onVolumeUpdated = { realPct ->
            runOnUiThread {
                tvVolumePercent = realPct.coerceIn(0, 100)
                binding.touchClickpad.volumePercent = tvVolumePercent
            }
        }

        lifecycleScope.launch { tuyaController.warmUp(); pollTuyaPower() }
        lifecycleScope.launch { miTvController.warmUpRemote() }
    }

    private fun showPairingFlow() {
        if (pairingDialogShowing || isFinishing || isDestroyed) return
        pairingDialogShowing = true
        AlertDialog.Builder(this)
            .setTitle("Сопряжение с ТВ")
            .setMessage("Кнопки работают через Google Remote. Один раз нужно сопрячься: на экране ТВ появится код из 6 символов.")
            .setPositiveButton("Показать код на ТВ") { _, _ -> startPairingOnTv() }
            .setNegativeButton("Позже") { _, _ -> pairingDialogShowing = false }
            .setOnCancelListener { pairingDialogShowing = false }
            .show()
    }

    private fun startPairingOnTv() {
        lifecycleScope.launch {
            val started = miTvController.beginPairing()
            if (!started) {
                pairingDialogShowing = false
                Toast.makeText(
                    this@MainActivity,
                    "ТВ не отвечает на сопряжение. Он включён и в той же Wi-Fi сети?",
                    Toast.LENGTH_LONG
                ).show()
                return@launch
            }
            val input = EditText(this@MainActivity).apply {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                filters = arrayOf(InputFilter.LengthFilter(6))
                hint = "Код с экрана ТВ"
            }
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Введите код с экрана ТВ")
                .setView(input)
                .setCancelable(false)
                .setPositiveButton("Подтвердить") { _, _ ->
                    lifecycleScope.launch {
                        val ok = miTvController.finishPairing(input.text.toString())
                        pairingDialogShowing = false
                        Toast.makeText(
                            this@MainActivity,
                            if (ok) "ТВ сопряжён" else "Неверный код. Попробуйте снова через долгое нажатие на кнопку ТВ.",
                            Toast.LENGTH_LONG
                        ).show()
                        if (ok) miTvController.warmUpRemote()
                    }
                }
                .setNegativeButton("Отмена") { _, _ ->
                    miTvController.remote.closePairing()
                    pairingDialogShowing = false
                }
                .show()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            lockImmersiveFullscreen()
        }
    }

    private fun lockImmersiveFullscreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                )
        }
    }

    private fun updateBatteryAmbientUi(percent: Int) {
        val clamped = percent.coerceIn(1, 100)
        binding.tvBatterySubtle.text = "$clamped%"
        binding.batteryAmbientBarTrack.post {
            val totalWidth = binding.batteryAmbientBarTrack.width
            if (totalWidth > 0) {
                val params = binding.batteryAmbientBarFill.layoutParams
                params.width = (totalWidth * clamped) / 100
                binding.batteryAmbientBarFill.layoutParams = params
            }
        }
    }

    private fun setupTopPowerAndPairingActions() {
        binding.btnTvPowerToggle.setOnClickListener { view ->
            performLightHaptic(view)
            lifecycleScope.launch {
                miTvController.toggleTvPower()
                delay(400L)
                val status = miTvController.pollScreenStatus()
                updatePowerPillUi(status.isReachable && status.isInteractive)
            }
        }

        binding.btnTvPowerToggle.setOnLongClickListener { view ->
            performLightHaptic(view)
            showManualIpDialog()
            true
        }
    }

    private fun showManualIpDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_PHONE
            setText(miTvController.tvIp)
            setSelection(text.length)
        }
        AlertDialog.Builder(this)
            .setTitle("Пульт и Система (${miTvController.tvIp})")
            .setMessage("Укажите IP телевизора, запустите сопряжение или проверьте обновление APK на GitHub:")
            .setView(input)
            .setPositiveButton("Сохранить IP") { _, _ ->
                val entered = input.text.toString().trim()
                if (entered.isNotEmpty()) {
                    miTvController.setManualIp(entered)
                    lifecycleScope.launch { miTvController.warmUpRemote() }
                }
            }
            .setNeutralButton("Обновить пульт") { _, _ ->
                showUpdateChoiceDialog()
            }
            .setNegativeButton("Сопряжение ТВ") { _, _ ->
                pairingDialogShowing = false
                showPairingFlow()
            }
            .show()
    }

    private fun setupVoiceIslandFallback() {
        binding.neonVoiceContainer.setOnClickListener { view ->
            performLightHaptic(view)
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                    putExtra(
                        "android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES",
                        arrayOf("uk-UA", "en-US", "ru-RU")
                    )
                    putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.voice_dialog_prompt))
                }
                speechDialogLauncher.launch(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "Голосовой ввод недоступен", Toast.LENGTH_SHORT).show()
            }
        }

        binding.neonVoiceContainer.setOnLongClickListener { view ->
            performLightHaptic(view)
            showVoiceSelfLearningDialog()
            true
        }
    }

    private fun showVoiceSelfLearningDialog() {
        val engine = voiceEngine ?: return
        val posCount = engine.neuralSpotter.learnedPositiveCount
        val negCount = engine.neuralSpotter.learnedNegativeCount
        AlertDialog.Builder(this)
            .setTitle("Самообучение голосу «Эхо»")
            .setMessage(
                "Нейросеть адаптируется под ваш голос и акустику комнаты:\n\n" +
                    "• Выучено ваших голосовых слепков: $posCount\n" +
                    "• Отсечено ложных шумов ТВ: $negCount\n\n" +
                    "Нажмите «Калибровка», отойдите на диван и скажите «Эй, Эхо» 3 раза."
            )
            .setPositiveButton("Калибровка (3 раза)") { _, _ ->
                animateTopNeonVoiceLine(true)
                engine.startVoiceCalibration(3) { remaining, total ->
                    if (remaining > 0) {
                        val doneSteps = total - remaining
                        val msg = if (doneSteps == 0) {
                            "Скажите «Эй, Эхо» (1 из $total)..."
                        } else {
                            "Записано ($doneSteps/$total)! Скажите «Эй, Эхо» ещё раз с дивана..."
                        }
                        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                    } else {
                        animateTopNeonVoiceLine(false)
                        Toast.makeText(this, "Готово! Пульт обучен вашему голосу", Toast.LENGTH_LONG).show()
                    }
                }
            }
            .setNeutralButton("Сбросить память") { _, _ ->
                engine.neuralSpotter.clearLearnedMemory()
                Toast.makeText(this, "Голосовая память очищена", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun setupTvClickpadAndButtons() {
        binding.touchClickpad.volumePercent = tvVolumePercent

        binding.touchClickpad.onZonePressedHaptic = {
            performLightHaptic(binding.touchClickpad)
        }

        // Directional taps + Center OK
        binding.touchClickpad.onZoneClicked = { zone ->
            lifecycleScope.launch {
                when (zone) {
                    TouchClickpadView.Zone.UP -> miTvController.sendKey(MiTvController.TvKey.DPAD_UP)
                    TouchClickpadView.Zone.DOWN -> miTvController.sendKey(MiTvController.TvKey.DPAD_DOWN)
                    TouchClickpadView.Zone.LEFT -> miTvController.sendKey(MiTvController.TvKey.DPAD_LEFT)
                    TouchClickpadView.Zone.RIGHT -> miTvController.sendKey(MiTvController.TvKey.DPAD_RIGHT)
                    TouchClickpadView.Zone.CENTER -> miTvController.sendKey(MiTvController.TvKey.DPAD_CENTER)
                    TouchClickpadView.Zone.NONE -> {}
                }
            }
        }

        // Rotary Jog Dial Volume (+1 = Clockwise Vol Up, -1 = Counter-Clockwise Vol Down)
        // Follows exact 15-step / 25-step Android TV volume scale so phone percentage matches TV 1:1!
        binding.touchClickpad.onVolumeRotaryStep = { direction ->
            val maxSteps = miTvController.remote.tvVolumeMax.coerceIn(15, 30)
            val stepPct = Math.round(100f / maxSteps)
            tvVolumePercent = (tvVolumePercent + direction * stepPct).coerceIn(0, 100)
            binding.touchClickpad.volumePercent = tvVolumePercent

            lifecycleScope.launch {
                if (direction > 0) {
                    miTvController.sendKey(MiTvController.TvKey.VOLUME_UP)
                } else {
                    miTvController.sendKey(MiTvController.TvKey.VOLUME_DOWN)
                }
            }
        }

        // Row under disc: 1. TV Control Center (`GET /key?k=MENU`), 2. YouTube, 3. Kick, 4. Browser
        bindRemoteAction(binding.btnQuickTvSettings) {
            miTvController.openTvControlPanel()
        }
        bindRemoteAction(binding.btnQuickYoutube) {
            miTvController.launchApp(MiTvController.TvApp.YOUTUBE)
        }
        bindRemoteAction(binding.btnQuickKick) {
            miTvController.launchApp(MiTvController.TvApp.KICK)
        }
        bindRemoteAction(binding.btnQuickBrowser) {
            miTvController.launchApp(MiTvController.TvApp.BROWSER)
        }

        // 3 Lifted Matte Capsules: Back, Home, Play/Pause
        bindRemoteAction(binding.btnBack) { miTvController.sendKey(MiTvController.TvKey.BACK) }
        bindRemoteAction(binding.btnHome) { miTvController.sendKey(MiTvController.TvKey.HOME) }
        bindRemoteAction(binding.btnPlayPause) { miTvController.sendKey(MiTvController.TvKey.PLAY_PAUSE) }
    }

    private fun bindRemoteAction(target: View, action: suspend () -> Unit) {
        target.setOnClickListener { view ->
            performLightHaptic(view)
            lifecycleScope.launch {
                action()
            }
        }
    }

    /**
     * Mode B: Tuya Color Wheel + Brightness & Saturation SeekBars + Bidirectional TV Sync.
     */
    private fun isWhiteModeActive(): Boolean {
        return (currentMode == ConsoleMode.LIGHT_SCONCE || currentMode == ConsoleMode.LIGHT_SYNC) && isBulbWhiteMode
    }

    private fun setBulbModeTabsUi(whiteMode: Boolean) {
        isBulbWhiteMode = whiteMode
        val activeWhite = isWhiteModeActive()
        binding.tuyaColorWheel.isWhiteMode = activeWhite
        binding.tuyaColorWheel.whiteTempPromille = currentWhiteTempPromille

        if (whiteMode) {
            binding.tabBulbWhite.setBackgroundResource(R.drawable.bg_chip)
            binding.tabBulbWhite.setTextColor(ContextCompat.getColor(this, R.color.text_primary))
            binding.tabBulbColor.background = null
            binding.tabBulbColor.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
        } else {
            binding.tabBulbColor.setBackgroundResource(R.drawable.bg_chip)
            binding.tabBulbColor.setTextColor(ContextCompat.getColor(this, R.color.text_primary))
            binding.tabBulbWhite.background = null
            binding.tabBulbWhite.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
        }

        // Saturation row is hidden for LED Bulb and in White mode
        binding.layoutSaturationRow.visibility = if (currentMode == ConsoleMode.LIGHT_STRIP || (currentMode == ConsoleMode.LIGHT_SYNC && !whiteMode)) {
            View.VISIBLE
        } else {
            View.GONE
        }

        renderColorPresetSwatches()
    }

    private fun setupLightColorWheelAndSliders() {
        renderColorPresetSwatches()

        binding.tuyaColorWheel.hue = currentHue
        binding.tuyaColorWheel.saturation = currentSatPercent / 100f
        binding.tuyaColorWheel.brightness = currentBrightPercent / 100f
        binding.tuyaColorWheel.whiteTempPromille = currentWhiteTempPromille

        binding.tuyaColorWheel.onHapticTick = {
            performLightHaptic(binding.tuyaColorWheel)
        }

        binding.tabBulbColor.setOnClickListener { view ->
            performLightHaptic(view)
            setBulbModeTabsUi(whiteMode = false)
            dispatchLightHsvUpdate(isFinal = true)
        }

        binding.tabBulbWhite.setOnClickListener { view ->
            performLightHaptic(view)
            setBulbModeTabsUi(whiteMode = true)
            dispatchLightWhiteUpdate(isFinal = true)
        }

        binding.tuyaColorWheel.onCenterPowerToggle = {
            when (currentMode) {
                ConsoleMode.LIGHT_SCONCE -> {
                    isSconceOn = !isSconceOn
                    binding.tuyaColorWheel.isLightOn = isSconceOn
                    updateHubCardsUi()
                    tuyaController.requestPower(lifecycleScope, tuyaController.sconceDeviceId, isSconceOn)
                }
                ConsoleMode.LIGHT_SYNC -> {
                    val targetOn = !(isStripOn && isSconceOn)
                    isStripOn = targetOn
                    isSconceOn = targetOn
                    binding.tuyaColorWheel.isLightOn = targetOn
                    updateHubCardsUi()
                    tuyaController.requestPower(lifecycleScope, tuyaController.stripDeviceId, targetOn)
                    tuyaController.requestPower(lifecycleScope, tuyaController.sconceDeviceId, targetOn)
                    lifecycleScope.launch { miTvController.syncLightToTv(power = targetOn) }
                }
                else -> {
                    isStripOn = !isStripOn
                    binding.tuyaColorWheel.isLightOn = isStripOn
                    updateHubCardsUi()
                    tuyaController.requestPower(lifecycleScope, tuyaController.stripDeviceId, isStripOn)
                    lifecycleScope.launch { miTvController.syncLightToTv(power = isStripOn) }
                }
            }
        }

        binding.tuyaColorWheel.onHueChanged = { newHue, isFinal ->
            currentHue = newHue
            activePreset = null
            renderColorPresetSwatches()
            when (currentMode) {
                ConsoleMode.LIGHT_SCONCE -> isSconceOn = true
                ConsoleMode.LIGHT_SYNC -> { isStripOn = true; isSconceOn = true }
                else -> isStripOn = true
            }
            updateHubCardsUi()
            dispatchLightHsvUpdate(isFinal = isFinal)
        }

        binding.tuyaColorWheel.onWhiteTempChanged = { newTemp, isFinal ->
            currentWhiteTempPromille = newTemp
            activeWhiteTempSwatch = null
            renderColorPresetSwatches()
            if (currentMode == ConsoleMode.LIGHT_SYNC) {
                isStripOn = true
                isSconceOn = true
            } else {
                isSconceOn = true
            }
            updateHubCardsUi()
            dispatchLightWhiteUpdate(isFinal = isFinal)
        }

        binding.seekLightBrightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val clamped = progress.coerceAtLeast(1)
                currentBrightPercent = clamped
                binding.tvBrightnessPercent.text = "$clamped%"
                binding.tuyaColorWheel.brightness = clamped / 100f
                if (fromUser) {
                    if (isWhiteModeActive()) dispatchLightWhiteUpdate(isFinal = false)
                    else dispatchLightHsvUpdate(isFinal = false)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                performLightHaptic(binding.seekLightBrightness)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (isWhiteModeActive()) dispatchLightWhiteUpdate(isFinal = true)
                else dispatchLightHsvUpdate(isFinal = true)
            }
        })

        binding.seekLightSaturation.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val clamped = progress.coerceAtLeast(5)
                currentSatPercent = clamped
                binding.tvSaturationPercent.text = "$clamped%"
                binding.tuyaColorWheel.saturation = clamped / 100f
                if (fromUser) dispatchLightHsvUpdate(isFinal = false)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                performLightHaptic(binding.seekLightSaturation)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                dispatchLightHsvUpdate(isFinal = true)
            }
        })

        val presetContainers = listOf(
            binding.presetCyber,
            binding.presetSapphire,
            binding.presetViolet,
            binding.presetRaspberry,
            binding.presetSunset,
            binding.presetWarm
        )
        val colorPresets = listOf(
            TuyaController.LightPreset.CYBER,
            TuyaController.LightPreset.SAPPHIRE,
            TuyaController.LightPreset.VIOLET,
            TuyaController.LightPreset.RASPBERRY,
            TuyaController.LightPreset.SUNSET,
            TuyaController.LightPreset.WARM
        )

        presetContainers.forEachIndexed { index, container ->
            container.setOnClickListener { view ->
                performLightHaptic(view)
                if (isWhiteModeActive()) {
                    val tempVal = whiteTempPresets[index]
                    activeWhiteTempSwatch = tempVal
                    currentWhiteTempPromille = tempVal
                    binding.tuyaColorWheel.whiteTempPromille = tempVal
                    binding.tuyaColorWheel.isLightOn = true
                    if (currentMode == ConsoleMode.LIGHT_SYNC) {
                        isStripOn = true
                        isSconceOn = true
                    } else {
                        isSconceOn = true
                    }
                    updateHubCardsUi()
                    renderColorPresetSwatches()
                    dispatchLightWhiteUpdate(isFinal = true)
                } else {
                    applyPresetToUiAndDevice(colorPresets[index])
                }
            }
        }
    }

    private fun applyPresetToUiAndDevice(preset: TuyaController.LightPreset) {
        activePreset = preset
        currentHue = preset.hue.toFloat()
        currentSatPercent = (preset.satPromille / 10).coerceIn(5, 100)
        currentBrightPercent = (preset.valPromille / 10).coerceIn(1, 100)

        binding.tuyaColorWheel.hue = currentHue
        binding.tuyaColorWheel.saturation = currentSatPercent / 100f
        binding.tuyaColorWheel.brightness = currentBrightPercent / 100f
        binding.tuyaColorWheel.isLightOn = true

        binding.seekLightBrightness.progress = currentBrightPercent
        binding.tvBrightnessPercent.text = "$currentBrightPercent%"
        binding.seekLightSaturation.progress = currentSatPercent
        binding.tvSaturationPercent.text = "$currentSatPercent%"

        when (currentMode) {
            ConsoleMode.LIGHT_SCONCE -> {
                isSconceOn = true
                // In Color mode on LED Bulb, saturation is 1000 unless WARM preset is selected
                val bulbSat = if (preset == TuyaController.LightPreset.WARM) preset.satPromille else 1000
                tuyaController.requestHsv(lifecycleScope, tuyaController.sconceDeviceId, preset.hue, bulbSat, preset.valPromille)
            }
            ConsoleMode.LIGHT_SYNC -> {
                isStripOn = true
                isSconceOn = true
                tuyaController.requestPreset(lifecycleScope, tuyaController.stripDeviceId, preset)
                val bulbSat = if (preset == TuyaController.LightPreset.WARM) preset.satPromille else 1000
                tuyaController.requestHsv(lifecycleScope, tuyaController.sconceDeviceId, preset.hue, bulbSat, preset.valPromille)
            }
            else -> {
                isStripOn = true
                tuyaController.requestPreset(lifecycleScope, tuyaController.stripDeviceId, preset)
            }
        }

        updateHubCardsUi()
        renderColorPresetSwatches()

        if (currentMode != ConsoleMode.LIGHT_SCONCE) {
            lifecycleScope.launch {
                miTvController.syncLightToTv(
                    power = true,
                    presetId = preset.id,
                    hue = preset.hue,
                    satPercent = currentSatPercent,
                    brightPercent = currentBrightPercent,
                    colorName = preset.titleRu
                )
            }
        }
    }

    private fun dispatchLightWhiteUpdate(isFinal: Boolean) {
        val vPromille = (currentBrightPercent * 10).coerceIn(10, 1000)
        val tempPromille = currentWhiteTempPromille.coerceIn(0, 1000)
        tuyaController.requestWhite(lifecycleScope, tuyaController.sconceDeviceId, vPromille, tempPromille)

        if (currentMode == ConsoleMode.LIGHT_SYNC) {
            // Map white temperature (0=Warm 2700K .. 1000=Cool 6500K) to matching strip HSV
            val stripHue = if (tempPromille <= 500) 34 else 205
            val stripSat = if (tempPromille <= 500) (280 - (tempPromille * 200 / 500)).coerceAtLeast(50) else ((tempPromille - 500) * 220 / 500).coerceAtLeast(50)
            tuyaController.requestHsv(lifecycleScope, tuyaController.stripDeviceId, stripHue, stripSat, vPromille)
            if (isFinal) {
                lifecycleScope.launch {
                    miTvController.syncLightToTv(
                        power = true,
                        presetId = "warm",
                        hue = stripHue,
                        satPercent = stripSat / 10,
                        brightPercent = currentBrightPercent,
                        colorName = "Белый"
                    )
                }
            }
        }
    }

    /**
     * Sends color/brightness to Tuya via the conflated sender AND syncs to the TV dashboard (`/light?...`).
     */
    private fun dispatchLightHsvUpdate(isFinal: Boolean) {
        val sPromille = (currentSatPercent * 10).coerceIn(10, 1000)
        val vPromille = (currentBrightPercent * 10).coerceIn(10, 1000)
        when (currentMode) {
            ConsoleMode.LIGHT_SCONCE -> {
                // LED Bulb Color mode has no saturation slider -> always full 1000 saturation
                tuyaController.requestHsv(lifecycleScope, tuyaController.sconceDeviceId, currentHue.toInt(), 1000, vPromille)
            }
            ConsoleMode.LIGHT_SYNC -> {
                tuyaController.requestHsv(lifecycleScope, tuyaController.stripDeviceId, currentHue.toInt(), sPromille, vPromille)
                tuyaController.requestHsv(lifecycleScope, tuyaController.sconceDeviceId, currentHue.toInt(), 1000, vPromille)
            }
            else -> {
                tuyaController.requestHsv(lifecycleScope, tuyaController.stripDeviceId, currentHue.toInt(), sPromille, vPromille)
            }
        }

        if (currentMode != ConsoleMode.LIGHT_SCONCE) {
            miTvController.lastLocalLightChangeMs = System.currentTimeMillis()
            if (isFinal) {
                tvLightSyncJob?.cancel()
                val h = currentHue.toInt()
                val colorName = miTvController.getFriendlyColorName(h, currentSatPercent)
                tvLightSyncJob = lifecycleScope.launch {
                    miTvController.syncLightToTv(
                        power = true,
                        presetId = activePreset?.id,
                        hue = h,
                        satPercent = currentSatPercent,
                        brightPercent = currentBrightPercent,
                        colorName = colorName
                    )
                }
            }
        }
    }

    private fun applyHsvToUi(hue: Int, satPercent: Int, brightPercent: Int) {
        currentHue = hue.toFloat()
        currentSatPercent = satPercent.coerceIn(5, 100)
        currentBrightPercent = brightPercent.coerceIn(1, 100)
        activePreset = null
        isStripOn = true
        binding.tuyaColorWheel.hue = currentHue
        binding.tuyaColorWheel.saturation = currentSatPercent / 100f
        binding.tuyaColorWheel.brightness = currentBrightPercent / 100f
        if (currentMode == ConsoleMode.LIGHT_STRIP || currentMode == ConsoleMode.LIGHT_SYNC) {
            binding.tuyaColorWheel.isLightOn = true
        }
        binding.seekLightBrightness.progress = currentBrightPercent
        binding.tvBrightnessPercent.text = "$currentBrightPercent%"
        binding.seekLightSaturation.progress = currentSatPercent
        binding.tvSaturationPercent.text = "$currentSatPercent%"
        renderColorPresetSwatches()
        updateHubCardsUi()
    }

    private fun syncUiFromTvLightState(ledOn: Boolean?, ledMode: String?, ledBright: Int?) {
        if (System.currentTimeMillis() - miTvController.lastLocalLightChangeMs < 2500L) {
            return
        }

        var changed = false
        if (ledBright != null && ledBright in 5..100 && ledBright != currentBrightPercent) {
            currentBrightPercent = ledBright
            binding.seekLightBrightness.progress = currentBrightPercent
            binding.tvBrightnessPercent.text = "$currentBrightPercent%"
            binding.tuyaColorWheel.brightness = currentBrightPercent / 100f
            changed = true
        }

        if (!ledMode.isNullOrBlank()) {
            val m = ledMode.trim().lowercase(Locale("ru", "RU"))
            val matchedPreset = when {
                m.contains("кибер") || m.contains("cyber") -> TuyaController.LightPreset.CYBER
                m.contains("сапфир") || m.contains("sapphire") || m.contains("индиго") -> TuyaController.LightPreset.SAPPHIRE
                m.contains("фиолет") || m.contains("violet") || m.contains("фукси") -> TuyaController.LightPreset.VIOLET
                m.contains("малин") || m.contains("raspberry") -> TuyaController.LightPreset.RASPBERRY
                m.contains("закат") || m.contains("sunset") || m.contains("янтар") -> TuyaController.LightPreset.SUNSET
                m.contains("тёпл") || m.contains("тепл") || m.contains("warm") -> TuyaController.LightPreset.WARM
                else -> null
            }

            if (matchedPreset != null && activePreset != null && matchedPreset != activePreset) {
                activePreset = matchedPreset
                currentHue = matchedPreset.hue.toFloat()
                currentSatPercent = (matchedPreset.satPromille / 10).coerceIn(5, 100)
                binding.tuyaColorWheel.hue = currentHue
                binding.tuyaColorWheel.saturation = currentSatPercent / 100f
                binding.seekLightSaturation.progress = currentSatPercent
                binding.tvSaturationPercent.text = "$currentSatPercent%"
                changed = true
            } else if (matchedPreset == null) {
                val customHue = when {
                    m.contains("лайм") -> 100f
                    m.contains("зелен") -> 125f
                    m.contains("изумр") -> 160f
                    m.contains("океан") -> 175f
                    m.contains("янтар") -> 45f
                    else -> null
                }
                if (customHue != null && kotlin.math.abs(currentHue - customHue) > 5f) {
                    activePreset = null
                    currentHue = customHue
                    binding.tuyaColorWheel.hue = currentHue
                    changed = true
                }
            }
        }

        if (changed) {
            renderColorPresetSwatches()
            updateHubCardsUi()
        }
    }

    private fun setupBottomSwipeHubDrawer() {
        val gestureDetector = GestureDetector(
            this,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onSingleTapUp(e: MotionEvent): Boolean {
                    openHubDrawer()
                    return true
                }

                override fun onFling(
                    e1: MotionEvent?,
                    e2: MotionEvent,
                    velocityX: Float,
                    velocityY: Float
                ): Boolean {
                    if (velocityY < -150f) {
                        openHubDrawer()
                        return true
                    }
                    return false
                }
            }
        )

        binding.bottomSwipeHandleArea.setOnTouchListener { view, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                performLightHaptic(view)
            }
            gestureDetector.onTouchEvent(event)
            true
        }

        binding.hubScrimOverlay.setOnClickListener {
            closeHubDrawer()
        }

        binding.sheetTopDragPill.setOnClickListener {
            closeHubDrawer()
        }

        binding.cardHubTv.setOnClickListener { view ->
            performLightHaptic(view)
            switchConsoleMode(ConsoleMode.TV_REMOTE)
            closeHubDrawer()
        }

        binding.cardHubSync.setOnClickListener { view ->
            performLightHaptic(view)
            val targetOn = !(isStripOn && isSconceOn)
            isStripOn = targetOn
            isSconceOn = targetOn
            if (currentMode != ConsoleMode.TV_REMOTE) {
                binding.tuyaColorWheel.isLightOn = targetOn
            }
            updateHubCardsUi()
            tuyaController.requestPower(lifecycleScope, tuyaController.stripDeviceId, targetOn)
            tuyaController.requestPower(lifecycleScope, tuyaController.sconceDeviceId, targetOn)
            lifecycleScope.launch { miTvController.syncLightToTv(power = targetOn) }
        }

        binding.cardHubSync.setOnLongClickListener { view ->
            performLightHaptic(view)
            isStripOn = true
            isSconceOn = true
            switchConsoleMode(ConsoleMode.LIGHT_SYNC)
            closeHubDrawer()
            true
        }

        binding.cardHubStrip.setOnClickListener { view ->
            performLightHaptic(view)
            isStripOn = !isStripOn
            if (currentMode == ConsoleMode.LIGHT_STRIP) {
                binding.tuyaColorWheel.isLightOn = isStripOn
            }
            updateHubCardsUi()
            tuyaController.requestPower(lifecycleScope, tuyaController.stripDeviceId, isStripOn)
            lifecycleScope.launch { miTvController.syncLightToTv(power = isStripOn) }
        }

        binding.cardHubStrip.setOnLongClickListener { view ->
            performLightHaptic(view)
            isStripOn = true
            switchConsoleMode(ConsoleMode.LIGHT_STRIP)
            closeHubDrawer()
            true
        }

        binding.cardHubSconce.setOnClickListener { view ->
            performLightHaptic(view)
            isSconceOn = !isSconceOn
            if (currentMode == ConsoleMode.LIGHT_SCONCE) {
                binding.tuyaColorWheel.isLightOn = isSconceOn
            }
            updateHubCardsUi()
            tuyaController.requestPower(lifecycleScope, tuyaController.sconceDeviceId, isSconceOn)
        }

        binding.cardHubSconce.setOnLongClickListener { view ->
            performLightHaptic(view)
            isSconceOn = true
            switchConsoleMode(ConsoleMode.LIGHT_SCONCE)
            closeHubDrawer()
            true
        }

        updateHubCardsUi()
    }

    private fun switchConsoleMode(newMode: ConsoleMode) {
        currentMode = newMode
        when (newMode) {
            ConsoleMode.TV_REMOTE -> {
                binding.lightControlModeContainer.visibility = View.GONE
                binding.tvRemoteModeContainer.visibility = View.VISIBLE
            }
            ConsoleMode.LIGHT_STRIP -> {
                binding.tvRemoteModeContainer.visibility = View.GONE
                binding.lightControlModeContainer.visibility = View.VISIBLE
                binding.tvActiveLightTitle.text = "LED STRIP"
                binding.bulbModeTabsContainer.visibility = View.GONE
                binding.layoutSaturationRow.visibility = View.VISIBLE
                binding.tuyaColorWheel.isWhiteMode = false
                binding.tuyaColorWheel.isLightOn = isStripOn
                renderColorPresetSwatches()
            }
            ConsoleMode.LIGHT_SCONCE -> {
                binding.tvRemoteModeContainer.visibility = View.GONE
                binding.lightControlModeContainer.visibility = View.VISIBLE
                binding.tvActiveLightTitle.text = "LED BULB"
                binding.bulbModeTabsContainer.visibility = View.VISIBLE
                binding.layoutSaturationRow.visibility = View.GONE
                binding.tuyaColorWheel.isLightOn = isSconceOn
                setBulbModeTabsUi(whiteMode = isBulbWhiteMode)
            }
            ConsoleMode.LIGHT_SYNC -> {
                binding.tvRemoteModeContainer.visibility = View.GONE
                binding.lightControlModeContainer.visibility = View.VISIBLE
                binding.tvActiveLightTitle.text = "SYNC · STRIP + BULB"
                binding.bulbModeTabsContainer.visibility = View.VISIBLE
                binding.tuyaColorWheel.isLightOn = (isStripOn || isSconceOn)
                setBulbModeTabsUi(whiteMode = isBulbWhiteMode)
            }
        }
        updateHubCardsUi()
    }

    private fun openHubDrawer() {
        if (isHubOpen) return
        isHubOpen = true
        updateHubCardsUi()
        binding.hubScrimOverlay.visibility = View.VISIBLE
        binding.hubBottomSheet.visibility = View.VISIBLE

        binding.hubScrimOverlay.animate()
            .alpha(1f)
            .setDuration(200L)
            .start()

        binding.hubBottomSheet.animate()
            .translationY(0f)
            .setDuration(240L)
            .start()
    }

    private fun closeHubDrawer() {
        if (!isHubOpen) return
        isHubOpen = false

        binding.hubScrimOverlay.animate()
            .alpha(0f)
            .setDuration(180L)
            .withEndAction {
                binding.hubScrimOverlay.visibility = View.GONE
            }
            .start()

        binding.hubBottomSheet.animate()
            .translationY(520f)
            .setDuration(220L)
            .withEndAction {
                binding.hubBottomSheet.visibility = View.GONE
            }
            .start()
    }

    private fun updateHubCardsUi() {
        binding.cardHubTv.isSelected = (currentMode == ConsoleMode.TV_REMOTE)
        binding.cardHubSync.isSelected = (currentMode == ConsoleMode.LIGHT_SYNC)
        binding.cardHubStrip.isSelected = (currentMode == ConsoleMode.LIGHT_STRIP)
        binding.cardHubSconce.isSelected = (currentMode == ConsoleMode.LIGHT_SCONCE)

        binding.tvHubTvSub.text = if (currentMode == ConsoleMode.TV_REMOTE) "Active" else "Select"
        binding.tvHubTvSub.setTextColor(
            ContextCompat.getColor(
                this,
                if (currentMode == ConsoleMode.TV_REMOTE) R.color.preset_cyber else R.color.text_secondary
            )
        )

        val bothOn = isStripOn && isSconceOn
        binding.tvHubSyncSub.text = if (bothOn) "ON · Hold" else "OFF · Hold"
        binding.tvHubSyncSub.setTextColor(
            ContextCompat.getColor(
                this,
                if (bothOn) R.color.status_online else R.color.text_secondary
            )
        )

        binding.tvHubStripSub.text = if (isStripOn) "ON · Hold" else "OFF · Hold"
        binding.tvHubStripSub.setTextColor(
            ContextCompat.getColor(
                this,
                if (isStripOn) R.color.status_online else R.color.text_secondary
            )
        )

        binding.tvHubSconceSub.text = if (isSconceOn) "ON · Hold" else "OFF · Hold"
        binding.tvHubSconceSub.setTextColor(
            ContextCompat.getColor(
                this,
                if (isSconceOn) R.color.status_online else R.color.text_secondary
            )
        )
    }

    private fun renderColorPresetSwatches() {
        val swatchViews = listOf(
            binding.swatchCyber,
            binding.swatchSapphire,
            binding.swatchViolet,
            binding.swatchRaspberry,
            binding.swatchSunset,
            binding.swatchWarm
        )
        val colorPresets = listOf(
            TuyaController.LightPreset.CYBER,
            TuyaController.LightPreset.SAPPHIRE,
            TuyaController.LightPreset.VIOLET,
            TuyaController.LightPreset.RASPBERRY,
            TuyaController.LightPreset.SUNSET,
            TuyaController.LightPreset.WARM
        )

        val density = resources.displayMetrics.density
        val whiteActive = isWhiteModeActive()
        swatchViews.forEachIndexed { index, view ->
            val isSelected = if (whiteActive) {
                activeWhiteTempSwatch == whiteTempPresets[index]
            } else {
                colorPresets[index] == activePreset
            }
            val swatchColor = if (whiteActive) {
                com.smartconsole.touch.ui.TuyaColorWheelView.tempPromilleToColor(whiteTempPresets[index])
            } else {
                colorPresets[index].previewHexColor
            }
            val drawable = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(swatchColor)
                if (isSelected) {
                    setStroke((2.5f * density).toInt(), Color.WHITE)
                } else {
                    setStroke((1f * density).toInt(), Color.parseColor("#33FFFFFF"))
                }
            }
            view.background = drawable
            view.scaleX = if (isSelected) 1.15f else 1.0f
            view.scaleY = if (isSelected) 1.15f else 1.0f
        }
    }

    private fun updatePowerPillUi(isOnline: Boolean) {
        val colorRes = if (isOnline) R.color.status_online else R.color.status_sleeping
        val resolvedColor = ContextCompat.getColor(this, colorRes)
        (binding.statusDotView.background as? GradientDrawable)?.setColor(resolvedColor)
        binding.tvPowerStatusLabel.text = getString(
            if (isOnline) R.string.tv_power_on else R.string.tv_power_sleep
        )
    }

    private fun startClockAndTvPolling() {
        clockAndStatusJob?.cancel()
        clockAndStatusJob = lifecycleScope.launch {
            var tick = 0
            while (isActive) {
                val now = Date()
                binding.tvClock.text = timeFormat.format(now)
                binding.tvDate.text = dateFormat.format(now).uppercase(Locale("ru", "RU"))

                val status = miTvController.pollScreenStatus()
                updatePowerPillUi(status.isReachable && status.isInteractive)
                lifecycleScope.launch { miTvController.maintainRemoteConnection(status) }
                tick++
                if (tick % 5 == 0 && System.currentTimeMillis() - miTvController.lastLocalLightChangeMs > 4000L) {
                    lifecycleScope.launch { pollTuyaPower() }
                }

                // Bidirectional sync: update phone light controls & volume if changed on TV
                syncUiFromTvLightState(status.ledOn, status.ledMode, status.ledBright)
                if (status.volumePercent != null) {
                    tvVolumePercent = status.volumePercent
                    binding.touchClickpad.volumePercent = tvVolumePercent
                }

                delay(if (status.isReachable) 2200L else 5000L)
            }
        }
    }

    private suspend fun pollTuyaPower() {
        if (System.currentTimeMillis() - miTvController.lastLocalLightChangeMs < 4000L) return
        val stripOn = tuyaController.fetchPower(tuyaController.stripDeviceId)
        val bulbOn = tuyaController.fetchPower(tuyaController.sconceDeviceId)
        var changed = false
        if (stripOn != null && stripOn != isStripOn) {
            isStripOn = stripOn
            if (currentMode == ConsoleMode.LIGHT_STRIP) binding.tuyaColorWheel.isLightOn = stripOn
            changed = true
        }
        if (bulbOn != null && bulbOn != isSconceOn) {
            isSconceOn = bulbOn
            if (currentMode == ConsoleMode.LIGHT_SCONCE) binding.tuyaColorWheel.isLightOn = bulbOn
            changed = true
        }
        if (changed) updateHubCardsUi()
    }

    private fun animateTopNeonVoiceLine(active: Boolean) {
        runOnUiThread {
            if (active) {
                if (neonPulseAnimator == null) {
                    val alphaHolder = PropertyValuesHolder.ofFloat(View.ALPHA, 0.35f, 1.0f)
                    val scaleXHolder = PropertyValuesHolder.ofFloat(View.SCALE_X, 0.7f, 1.35f)
                    neonPulseAnimator = ObjectAnimator.ofPropertyValuesHolder(
                        binding.neonVoiceLine,
                        alphaHolder,
                        scaleXHolder
                    ).apply {
                        duration = 480L
                        repeatCount = ObjectAnimator.INFINITE
                        repeatMode = ObjectAnimator.REVERSE
                    }
                }
                if (neonPulseAnimator?.isRunning != true) {
                    neonPulseAnimator?.start()
                }
            } else {
                neonPulseAnimator?.cancel()
                binding.neonVoiceLine.animate()
                    .alpha(0.28f)
                    .scaleX(1.0f)
                    .setDuration(220L)
                    .start()
            }
        }
    }

    private fun checkAudioPermissionAndStartVoiceEngine() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED
        ) {
            initVoiceEngine()
            startVoiceKeepAlive()
        } else {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
            ActivityCompat.requestPermissions(this, perms.toTypedArray(), 1001)
        }
    }

    /** Foreground service + battery whitelist: keeps "Эхо" listening with screen off / app in background. */
    private fun startVoiceKeepAlive() {
        try {
            ContextCompat.startForegroundService(
                this,
                Intent(this, com.smartconsole.touch.voice.VoiceKeepAliveService::class.java)
            )
        } catch (_: Exception) {
        }
        try {
            val pm = getSystemService(android.os.PowerManager::class.java)
            if (pm != null && !pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(
                    Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:$packageName"))
                )
            }
        } catch (_: Exception) {
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            initVoiceEngine()
            startVoiceKeepAlive()
        }
    }

    private fun initVoiceEngine() {
        voiceEngine?.stop()
        voiceEngine = VoiceAssistantEngine(
            context = this,
            scope = lifecycleScope,
            miTvController = miTvController,
            tuyaController = tuyaController,
            onVoiceActivityChanged = { active -> animateTopNeonVoiceLine(active) },
            onWakeWordTriggeredHaptic = {
                runOnUiThread { performLightHaptic(binding.neonVoiceContainer) }
            },
            onLocalPresetChanged = { preset ->
                runOnUiThread {
                    applyPresetToUiAndDevice(preset)
                }
            },
            onLocalStripPowerChanged = { enabled ->
                runOnUiThread {
                    isStripOn = enabled
                    binding.tuyaColorWheel.isLightOn = enabled
                    updateHubCardsUi()
                }
            },
            getLightState = { intArrayOf(currentHue.toInt(), currentSatPercent, currentBrightPercent) },
            onLocalColorChanged = { h, sat, bright ->
                runOnUiThread { applyHsvToUi(h, sat, bright) }
            },
            onLocalBulbPowerChanged = { enabled ->
                runOnUiThread {
                    isSconceOn = enabled
                    if (currentMode == ConsoleMode.LIGHT_SCONCE) {
                        binding.tuyaColorWheel.isLightOn = enabled
                    }
                    updateHubCardsUi()
                }
            },
            onLocalBulbWhiteChanged = { brightPct, tempPromille ->
                runOnUiThread {
                    isSconceOn = true
                    currentBrightPercent = brightPct.coerceIn(1, 100)
                    currentWhiteTempPromille = tempPromille.coerceIn(0, 1000)
                    binding.seekLightBrightness.progress = currentBrightPercent
                    binding.tvBrightnessPercent.text = "$currentBrightPercent%"
                    binding.tuyaColorWheel.brightness = currentBrightPercent / 100f
                    binding.tuyaColorWheel.whiteTempPromille = currentWhiteTempPromille
                    if (currentMode == ConsoleMode.LIGHT_SCONCE || currentMode == ConsoleMode.LIGHT_SYNC) {
                        setBulbModeTabsUi(whiteMode = true)
                        binding.tuyaColorWheel.isLightOn = true
                    }
                    updateHubCardsUi()
                }
            }
        ).also { it.start() }
    }

    private fun performLightHaptic(view: View) {
        view.performHapticFeedback(
            HapticFeedbackConstants.KEYBOARD_TAP,
            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
        )
        try {
            val vibrator = getSystemService(Vibrator::class.java)
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(14L, 90))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(14L)
                }
            }
        } catch (_: Exception) {
        }
    }

    /**
     * In-App OTA Update: Downloads APK directly in the background and opens the native installer,
     * so you never leave the console and never get stuck in a browser without navigation buttons.
     */
    /**
     * In-App OTA Update with permanent signature (`console-signing-key.jks`):
     * Downloads the signed APK directly in the background and launches the system package installer
     * on top of the console, without ever opening an external browser!
     */
    private fun showUpdateChoiceDialog() {
        val prefs = getSharedPreferences("smart_console_prefs", Context.MODE_PRIVATE)
        val defaultUrl = prefs.getString(
            "ota_apk_url",
            "https://github.com/ddtrs/echo/releases/download/latest-ota/app-debug.apk"
        ) ?: "https://github.com/ddtrs/echo/releases/download/latest-ota/app-debug.apk"

        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(defaultUrl)
            setSelection(text.length)
        }
        AlertDialog.Builder(this)
            .setTitle("Обновление пульта (OTA)")
            .setMessage("APK подписан единым ключом и ставится поверх как обновление без потери настроек:")
            .setView(input)
            .setPositiveButton("Скачать и установить") { _, _ ->
                val url = input.text.toString().trim().ifEmpty { defaultUrl }
                prefs.edit().putString("ota_apk_url", url).apply()
                downloadAndInstallOtaApk(url)
            }
            .setNeutralButton("С локального ТВ") { _, _ ->
                val tvUrl = "http://${miTvController.tvIp}:${miTvController.tvPort}/update.apk"
                downloadAndInstallOtaApk(tvUrl)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun downloadAndInstallOtaApk(primaryUrl: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            try {
                val permIntent = Intent(
                    android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:$packageName")
                )
                startActivity(permIntent)
                Toast.makeText(this, "Разрешите установку обновлений и нажмите снова", Toast.LENGTH_LONG).show()
                return
            } catch (_: Exception) {
            }
        }

        Toast.makeText(this, "Скачивание обновления...", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val candidateUrls = listOf(
                primaryUrl,
                "https://github.com/ddtrs/echo/releases/download/latest-ota/app-debug.apk",
                "https://github.com/ddtrs/echo/releases/latest/download/app-debug.apk",
                "https://raw.githubusercontent.com/ddtrs/echo/main/app-debug.apk"
            ).distinct()

            val destFile = java.io.File(externalCacheDir ?: cacheDir, "update.apk")
            val partFile = java.io.File(externalCacheDir ?: cacheDir, "update.apk.part")
            val client = okhttp3.OkHttpClient.Builder()
                .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(45, java.util.concurrent.TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .build()

            var downloadedOk = false
            var lastErr = "Файл не найден в релизах GitHub"

            for (url in candidateUrls) {
                try {
                    val req = okhttp3.Request.Builder().url(url).build()
                    client.newCall(req).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val body = resp.body
                            if (body != null) {
                                if (partFile.exists()) partFile.delete()
                                val expected = body.contentLength()
                                body.byteStream().use { inp ->
                                    partFile.outputStream().use { out ->
                                        inp.copyTo(out)
                                    }
                                }
                                val problem = validateDownloadedApk(partFile, expected)
                                if (problem == null) {
                                    if (destFile.exists()) destFile.delete()
                                    if (partFile.renameTo(destFile)) {
                                        downloadedOk = true
                                    } else {
                                        lastErr = "Не удалось сохранить файл"
                                    }
                                } else {
                                    partFile.delete()
                                    lastErr = problem
                                }
                            }
                        } else {
                            lastErr = "HTTP ${resp.code}"
                        }
                    }
                } catch (e: Exception) {
                    lastErr = e.javaClass.simpleName
                }
                if (downloadedOk) break
            }

            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                if (downloadedOk) {
                    promptInstallDownloadedApk(destFile)
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        "Не удалось скачать APK ($lastErr). Проверьте, что сборка на GitHub завершилась.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    /** Returns null if the file is a complete APK for this app signed with our key, otherwise a short reason. */
    @Suppress("DEPRECATION")
    private fun validateDownloadedApk(file: java.io.File, expectedLength: Long): String? {
        if (!file.exists() || file.length() < 50_000L) return "Файл слишком мал (${file.length()} байт)"
        if (expectedLength > 0 && file.length() != expectedLength) return "Файл скачан не полностью"
        try {
            val head = ByteArray(2)
            file.inputStream().use { it.read(head) }
            if (head[0] != 'P'.code.toByte() || head[1] != 'K'.code.toByte()) return "Скачан не APK (а веб-страница)"
        } catch (_: Exception) {
            return "Не удалось прочитать файл"
        }
        return try {
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
                android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES
            else
                android.content.pm.PackageManager.GET_SIGNATURES

            val archive = packageManager.getPackageArchiveInfo(file.absolutePath, flags)
                ?: return "APK повреждён"
            if (archive.packageName != packageName) return "Это APK другого приложения"

            fun sigs(info: android.content.pm.PackageInfo): Set<String> {
                val raw: List<android.content.pm.Signature>? =
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        info.signingInfo?.apkContentsSigners?.toList()
                    } else {
                        info.signatures?.toList()
                    }
                return (raw ?: emptyList()).map { it.toCharsString() }.toSet()
            }
            val newSigs = sigs(archive)
            val curSigs = sigs(packageManager.getPackageInfo(packageName, flags))
            if (newSigs.isNotEmpty() && curSigs.isNotEmpty() && newSigs != curSigs) {
                "Подпись APK отличается от установленной: удалите старую версию один раз и поставьте новую"
            } else null
        } catch (_: Exception) {
            null // cannot verify on this device: let the system installer decide
        }
    }

    private fun promptInstallDownloadedApk(apkFile: java.io.File) {
        try {
            val contentUri = androidx.core.content.FileProvider.getUriForFile(
                this,
                "com.smartconsole.touch.fileprovider",
                apkFile
            )
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            startActivity(installIntent)
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка запуска установщика: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(batteryReceiver)
        } catch (_: Exception) {
        }
        clockAndStatusJob?.cancel()
        tvLightSyncJob?.cancel()
        miTvController.stopMdnsAutoDiscovery()
        voiceEngine?.stop()
        try {
            stopService(Intent(this, com.smartconsole.touch.voice.VoiceKeepAliveService::class.java))
        } catch (_: Exception) {
        }
        super.onDestroy()
    }
}
