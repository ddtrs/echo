package com.smartconsole.touch

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.smartconsole.touch.databinding.ActivityMainBinding
import com.smartconsole.touch.network.MiTvController
import com.smartconsole.touch.network.TuyaController
import com.smartconsole.touch.voice.VoiceAssistantEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var miTvController: MiTvController
    private val tuyaController = TuyaController()
    private var voiceEngine: VoiceAssistantEngine? = null

    private var clockAndStatusJob: Job? = null
    private var neonPulseAnimator: ObjectAnimator? = null

    private var isStripOn: Boolean = true
    private var isSconceOn: Boolean = false
    private var activePreset: TuyaController.LightPreset = TuyaController.LightPreset.WARM

    private val timeFormat = SimpleDateFormat("HH:mm", Locale("ru", "RU"))
    private val dateFormat = SimpleDateFormat("EE, d MMMM", Locale("ru", "RU"))

    private val speechDialogLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = matches?.firstOrNull()?.trim().orEmpty()
            if (spokenText.isNotEmpty()) {
                animateTopNeonVoiceLine(true)
                voiceEngine?.handleRecognizedCommand(spokenText)
                binding.root.postDelayed({ animateTopNeonVoiceLine(false) }, 800L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Default initial IP set to 192.168.0.3, with automatic subnet discovery enabled
        miTvController = MiTvController(context = this, initialIp = "192.168.0.3", tvPort = 8765)

        lockImmersiveFullscreen()
        setupStatusBadgeIpActions()
        setupClickpadAndButtons()
        setupTuyaSmartLightPanel()
        setupVoiceIslandFallback()
        startClockAndTvPolling()
        checkAudioPermissionAndStartVoiceEngine()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            lockImmersiveFullscreen()
        }
    }

    private fun lockImmersiveFullscreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                )
        }
    }

    /**
     * Tapping the top-right TV IP badge triggers an immediate Wi-Fi subnet scan.
     * Long-pressing the badge opens a quick manual IP input dialog.
     */
    private fun setupStatusBadgeIpActions() {
        binding.statusBadgeContainer.setOnClickListener { view ->
            performLightHaptic(view)
            binding.tvScreenState.text = "[Поиск ТВ в сети...]"
            lifecycleScope.launch {
                val foundIp = miTvController.forceScanSubnet()
                if (foundIp != null) {
                    binding.tvStickIpBadge.text = "● Mi TV Stick: $foundIp"
                    binding.tvStickIpBadge.setTextColor(
                        ContextCompat.getColor(this@MainActivity, R.color.status_online)
                    )
                    binding.tvScreenState.text = getString(R.string.tv_screen_on)
                    Toast.makeText(this@MainActivity, "Найден ТВ: $foundIp", Toast.LENGTH_SHORT).show()
                } else {
                    showManualIpDialog()
                }
            }
        }

        binding.statusBadgeContainer.setOnLongClickListener { view ->
            performLightHaptic(view)
            showManualIpDialog()
            true
        }
    }

    private fun showManualIpDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_PHONE
            setText(miTvController.tvIp)
            setSelection(text.length)
        }
        AlertDialog.Builder(this)
            .setTitle("IP-адрес Mi TV Stick (порт 8765)")
            .setMessage("Автопоиск сканирует всю сеть Wi-Fi. Вы также можете указать IP вручную:")
            .setView(input)
            .setPositiveButton("Сохранить") { _, _ ->
                val entered = input.text.toString().trim()
                if (entered.isNotEmpty()) {
                    miTvController.setManualIp(entered)
                    binding.tvStickIpBadge.text = "● Mi TV Stick: ${miTvController.tvIp}"
                }
            }
            .setNeutralButton("Автопоиск") { _, _ ->
                lifecycleScope.launch {
                    val found = miTvController.forceScanSubnet()
                    if (found != null) {
                        binding.tvStickIpBadge.text = "● Mi TV Stick: $found"
                        Toast.makeText(this@MainActivity, "Найден ТВ: $found", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun setupVoiceIslandFallback() {
        binding.neonVoiceContainer.setOnClickListener { view ->
            performLightHaptic(view)
            launchSpeechRecognizerDialog()
        }
    }

    private fun launchSpeechRecognizerDialog() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.voice_dialog_prompt))
            }
            speechDialogLauncher.launch(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Голосовой ввод не поддерживается на устройстве", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupClickpadAndButtons() {
        bindRemoteAction(binding.btnDpadUp) { miTvController.sendKey(MiTvController.TvKey.DPAD_UP) }
        bindRemoteAction(binding.btnDpadDown) { miTvController.sendKey(MiTvController.TvKey.DPAD_DOWN) }
        bindRemoteAction(binding.btnDpadLeft) { miTvController.sendKey(MiTvController.TvKey.DPAD_LEFT) }
        bindRemoteAction(binding.btnDpadRight) { miTvController.sendKey(MiTvController.TvKey.DPAD_RIGHT) }

        binding.btnDpadOk.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    performLightHaptic(view)
                    view.animate()
                        .scaleX(0.88f)
                        .scaleY(0.88f)
                        .setDuration(90L)
                        .start()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .setInterpolator(OvershootInterpolator(2.6f))
                        .setDuration(220L)
                        .start()
                    if (event.actionMasked == MotionEvent.ACTION_UP) {
                        lifecycleScope.launch {
                            miTvController.sendKey(MiTvController.TvKey.DPAD_CENTER)
                        }
                    }
                    true
                }
                else -> false
            }
        }

        bindRemoteAction(binding.btnBack) { miTvController.sendKey(MiTvController.TvKey.BACK) }
        bindRemoteAction(binding.btnHome) { miTvController.sendKey(MiTvController.TvKey.HOME) }
        bindRemoteAction(binding.btnPlayPause) { miTvController.sendKey(MiTvController.TvKey.PLAY_PAUSE) }
        bindRemoteAction(binding.btnVolUp) { miTvController.sendKey(MiTvController.TvKey.VOLUME_UP) }
        bindRemoteAction(binding.btnVolDown) { miTvController.sendKey(MiTvController.TvKey.VOLUME_DOWN) }

        bindRemoteAction(binding.btnQuickYoutube) {
            miTvController.launchApp(MiTvController.TvApp.YOUTUBE)
        }
        bindRemoteAction(binding.btnQuickKick) {
            miTvController.launchApp(MiTvController.TvApp.KICK)
        }
        bindRemoteAction(binding.btnQuickBrowser) {
            miTvController.launchApp(MiTvController.TvApp.BROWSER)
        }
    }

    private fun bindRemoteAction(target: View, action: suspend () -> Unit) {
        target.setOnClickListener { view ->
            performLightHaptic(view)
            lifecycleScope.launch {
                action()
                binding.tvStickIpBadge.text = "● Mi TV Stick: ${miTvController.tvIp}"
            }
        }
    }

    private fun setupTuyaSmartLightPanel() {
        updateTuyaToggleUi()
        renderColorPresetSwatches()

        binding.btnToggleStrip.setOnClickListener { view ->
            performLightHaptic(view)
            isStripOn = !isStripOn
            updateTuyaToggleUi()
            lifecycleScope.launch {
                tuyaController.setPower(tuyaController.stripDeviceId, isStripOn)
            }
        }

        binding.btnToggleSconce.setOnClickListener { view ->
            performLightHaptic(view)
            isSconceOn = !isSconceOn
            updateTuyaToggleUi()
            lifecycleScope.launch {
                tuyaController.setPower(tuyaController.sconceDeviceId, isSconceOn)
            }
        }

        val presetMap = listOf(
            binding.presetCyber to TuyaController.LightPreset.CYBER,
            binding.presetSapphire to TuyaController.LightPreset.SAPPHIRE,
            binding.presetViolet to TuyaController.LightPreset.VIOLET,
            binding.presetRaspberry to TuyaController.LightPreset.RASPBERRY,
            binding.presetSunset to TuyaController.LightPreset.SUNSET,
            binding.presetWarm to TuyaController.LightPreset.WARM
        )

        presetMap.forEach { (container, preset) ->
            container.setOnClickListener { view ->
                performLightHaptic(view)
                activePreset = preset
                isStripOn = true
                updateTuyaToggleUi()
                renderColorPresetSwatches()
                lifecycleScope.launch {
                    tuyaController.applyPreset(tuyaController.stripDeviceId, preset)
                }
            }
        }
    }

    private fun updateTuyaToggleUi() {
        binding.btnToggleStrip.isSelected = isStripOn
        binding.btnToggleStrip.text = if (isStripOn) "💡 Лента: ВКЛ" else "💡 Лента: ВЫКЛ"
        binding.btnToggleStrip.setTextColor(
            ContextCompat.getColor(
                this,
                if (isStripOn) R.color.text_primary else R.color.text_secondary
            )
        )

        binding.btnToggleSconce.isSelected = isSconceOn
        binding.btnToggleSconce.text = if (isSconceOn) "🕯 Бра: ВКЛ" else "🕯 Бра: ВЫКЛ"
        binding.btnToggleSconce.setTextColor(
            ContextCompat.getColor(
                this,
                if (isSconceOn) R.color.text_primary else R.color.text_secondary
            )
        )
    }

    private fun renderColorPresetSwatches() {
        val swatches = listOf(
            binding.swatchCyber to TuyaController.LightPreset.CYBER,
            binding.swatchSapphire to TuyaController.LightPreset.SAPPHIRE,
            binding.swatchViolet to TuyaController.LightPreset.VIOLET,
            binding.swatchRaspberry to TuyaController.LightPreset.RASPBERRY,
            binding.swatchSunset to TuyaController.LightPreset.SUNSET,
            binding.swatchWarm to TuyaController.LightPreset.WARM
        )

        val density = resources.displayMetrics.density
        swatches.forEach { (view, preset) ->
            val isSelected = (preset == activePreset)
            val drawable = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(preset.previewHexColor)
                if (isSelected) {
                    setStroke((2.5f * density).toInt(), Color.WHITE)
                } else {
                    setStroke((1f * density).toInt(), Color.parseColor("#33FFFFFF"))
                }
            }
            view.background = drawable
            view.scaleX = if (isSelected) 1.12f else 1.0f
            view.scaleY = if (isSelected) 1.12f else 1.0f
        }
    }

    private fun startClockAndTvPolling() {
        clockAndStatusJob?.cancel()
        clockAndStatusJob = lifecycleScope.launch {
            while (isActive) {
                val now = Date()
                binding.tvClock.text = timeFormat.format(now)
                binding.tvDate.text = dateFormat.format(now).uppercase(Locale("ru", "RU"))

                val status = miTvController.pollScreenStatus()
                binding.tvStickIpBadge.text = "● Mi TV Stick: ${status.ip}"
                if (status.isReachable && status.isInteractive) {
                    binding.tvStickIpBadge.setTextColor(
                        ContextCompat.getColor(this@MainActivity, R.color.status_online)
                    )
                    binding.tvScreenState.text = getString(R.string.tv_screen_on)
                } else {
                    binding.tvStickIpBadge.setTextColor(
                        ContextCompat.getColor(this@MainActivity, R.color.status_sleeping)
                    )
                    binding.tvScreenState.text = getString(R.string.tv_screen_sleep)
                }

                delay(3000L)
            }
        }
    }

    private fun animateTopNeonVoiceLine(active: Boolean) {
        runOnUiThread {
            if (active) {
                if (neonPulseAnimator == null) {
                    val alphaHolder = PropertyValuesHolder.ofFloat(View.ALPHA, 0.35f, 1.0f)
                    val scaleXHolder = PropertyValuesHolder.ofFloat(View.SCALE_X, 0.7f, 1.35f)
                    neonPulseAnimator = ObjectAnimator.ofPropertyValuesHolder(
                        binding.neonVoiceLine,
                        alphaHolder,
                        scaleXHolder
                    ).apply {
                        duration = 480L
                        repeatCount = ObjectAnimator.INFINITE
                        repeatMode = ObjectAnimator.REVERSE
                    }
                }
                if (neonPulseAnimator?.isRunning != true) {
                    neonPulseAnimator?.start()
                }
            } else {
                neonPulseAnimator?.cancel()
                binding.neonVoiceLine.animate()
                    .alpha(0.25f)
                    .scaleX(1.0f)
                    .setDuration(220L)
                    .start()
            }
        }
    }

    private fun checkAudioPermissionAndStartVoiceEngine() {
        initVoiceEngine()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                1001
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            initVoiceEngine()
        }
    }

    private fun initVoiceEngine() {
        voiceEngine?.stop()
        voiceEngine = VoiceAssistantEngine(
            context = this,
            scope = lifecycleScope,
            miTvController = miTvController,
            tuyaController = tuyaController,
            onVoiceActivityChanged = { active -> animateTopNeonVoiceLine(active) },
            onLocalPresetChanged = { preset ->
                runOnUiThread {
                    activePreset = preset
                    isStripOn = true
                    updateTuyaToggleUi()
                    renderColorPresetSwatches()
                }
            },
            onLocalStripPowerChanged = { enabled ->
                runOnUiThread {
                    isStripOn = enabled
                    updateTuyaToggleUi()
                }
            }
        ).also { it.start() }
    }

    private fun performLightHaptic(view: View) {
        view.performHapticFeedback(
            HapticFeedbackConstants.KEYBOARD_TAP,
            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
        )
        try {
            val vibrator = getSystemService(Vibrator::class.java)
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(14L, 90))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(14L)
                }
            }
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        clockAndStatusJob?.cancel()
        voiceEngine?.stop()
        super.onDestroy()
    }
}
