package com.smartconsole.touch

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.smartconsole.touch.databinding.ActivityMainBinding
import com.smartconsole.touch.network.MiTvController
import com.smartconsole.touch.network.TuyaController
import com.smartconsole.touch.ui.TouchClickpadView
import com.smartconsole.touch.voice.VoiceAssistantEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    enum class ConsoleMode {
        TV_REMOTE,
        LIGHT_STRIP,
        LIGHT_SCONCE
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var miTvController: MiTvController
    private val tuyaController = TuyaController()
    private var voiceEngine: VoiceAssistantEngine? = null

    private var clockAndStatusJob: Job? = null
    private var colorSendDebounceJob: Job? = null
    private var neonPulseAnimator: ObjectAnimator? = null

    private var currentMode: ConsoleMode = ConsoleMode.TV_REMOTE
    private var isHubOpen: Boolean = false

    // Tuya state
    private var isStripOn: Boolean = true
    private var isSconceOn: Boolean = false
    private var currentHue: Float = 271f
    private var currentSatPercent: Int = 95
    private var currentBrightPercent: Int = 100
    private var activePreset: TuyaController.LightPreset? = TuyaController.LightPreset.VIOLET

    private val timeFormat = SimpleDateFormat("HH:mm", Locale("ru", "RU"))
    private val dateFormat = SimpleDateFormat("EE, d MMMM", Locale("ru", "RU"))

    private val speechDialogLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = matches?.firstOrNull()?.trim().orEmpty()
            if (spokenText.isNotEmpty()) {
                animateTopNeonVoiceLine(true)
                voiceEngine?.handleRecognizedCommand(spokenText)
                binding.root.postDelayed({ animateTopNeonVoiceLine(false) }, 800L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        miTvController = MiTvController(context = this, initialIp = "192.168.0.3", tvPort = 8765)

        lockImmersiveFullscreen()
        setupStatusBadgeIpActions()
        setupTvClickpadAndButtons()
        setupLightColorWheelAndSliders()
        setupBottomSwipeHubDrawer()
        setupVoiceIslandFallback()
        startClockAndTvPolling()
        checkAudioPermissionAndStartVoiceEngine()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            lockImmersiveFullscreen()
        }
    }

    private fun lockImmersiveFullscreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                )
        }
    }

    private fun setupStatusBadgeIpActions() {
        binding.statusBadgeContainer.setOnClickListener { view ->
            performLightHaptic(view)
            binding.tvScreenState.text = "[Поиск ТВ...]"
            lifecycleScope.launch {
                val foundIp = miTvController.forceScanSubnet()
                if (foundIp != null) {
                    updateStatusBadgeUi(foundIp, true)
                    Toast.makeText(this@MainActivity, "Найден ТВ: $foundIp", Toast.LENGTH_SHORT).show()
                } else {
                    showManualIpDialog()
                }
            }
        }

        binding.statusBadgeContainer.setOnLongClickListener { view ->
            performLightHaptic(view)
            showManualIpDialog()
            true
        }
    }

    private fun showManualIpDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_PHONE
            setText(miTvController.tvIp)
            setSelection(text.length)
        }
        AlertDialog.Builder(this)
            .setTitle("IP-адрес Mi TV Stick (порт 8765)")
            .setMessage("Автопоиск сканирует всю сеть Wi-Fi. Вы также можете ввести IP вручную:")
            .setView(input)
            .setPositiveButton("Сохранить") { _, _ ->
                val entered = input.text.toString().trim()
                if (entered.isNotEmpty()) {
                    miTvController.setManualIp(entered)
                    binding.tvStickIpBadge.text = "Mi TV Stick: ${miTvController.tvIp}"
                }
            }
            .setNeutralButton("Автопоиск") { _, _ ->
                lifecycleScope.launch {
                    val found = miTvController.forceScanSubnet()
                    if (found != null) {
                        updateStatusBadgeUi(found, true)
                    }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun setupVoiceIslandFallback() {
        binding.neonVoiceContainer.setOnClickListener { view ->
            performLightHaptic(view)
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.voice_dialog_prompt))
                }
                speechDialogLauncher.launch(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "Голосовой ввод не поддерживается", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Sets up the ergonomic 216dp TouchClickpadView and buttons.
     */
    private fun setupTvClickpadAndButtons() {
        binding.touchClickpad.onZonePressedHaptic = {
            performLightHaptic(binding.touchClickpad)
        }

        binding.touchClickpad.onZoneClicked = { zone ->
            lifecycleScope.launch {
                when (zone) {
                    TouchClickpadView.Zone.UP -> miTvController.sendKey(MiTvController.TvKey.DPAD_UP)
                    TouchClickpadView.Zone.DOWN -> miTvController.sendKey(MiTvController.TvKey.DPAD_DOWN)
                    TouchClickpadView.Zone.LEFT -> miTvController.sendKey(MiTvController.TvKey.DPAD_LEFT)
                    TouchClickpadView.Zone.RIGHT -> miTvController.sendKey(MiTvController.TvKey.DPAD_RIGHT)
                    TouchClickpadView.Zone.CENTER -> miTvController.sendKey(MiTvController.TvKey.DPAD_CENTER)
                    TouchClickpadView.Zone.NONE -> {}
                }
                binding.tvStickIpBadge.text = "Mi TV Stick: ${miTvController.tvIp}"
            }
        }

        // Circular Quick-Launch Row right below the disc: PatchWall (Menu), YouTube, Kick, Browser
        bindRemoteAction(binding.btnQuickPatchwall) {
            miTvController.sendKey(MiTvController.TvKey.MENU)
        }
        bindRemoteAction(binding.btnQuickYoutube) {
            miTvController.launchApp(MiTvController.TvApp.YOUTUBE)
        }
        bindRemoteAction(binding.btnQuickKick) {
            miTvController.launchApp(MiTvController.TvApp.KICK)
        }
        bindRemoteAction(binding.btnQuickBrowser) {
            miTvController.launchApp(MiTvController.TvApp.BROWSER)
        }

        // 4 Bottom Matte Capsules
        bindRemoteAction(binding.btnBack) { miTvController.sendKey(MiTvController.TvKey.BACK) }
        bindRemoteAction(binding.btnHome) { miTvController.sendKey(MiTvController.TvKey.HOME) }
        bindRemoteAction(binding.btnPlayPause) { miTvController.sendKey(MiTvController.TvKey.PLAY_PAUSE) }
        bindRemoteAction(binding.btnVolUp) { miTvController.sendKey(MiTvController.TvKey.VOLUME_UP) }
        bindRemoteAction(binding.btnVolDown) { miTvController.sendKey(MiTvController.TvKey.VOLUME_DOWN) }
    }

    private fun bindRemoteAction(target: View, action: suspend () -> Unit) {
        target.setOnClickListener { view ->
            performLightHaptic(view)
            lifecycleScope.launch {
                action()
                binding.tvStickIpBadge.text = "Mi TV Stick: ${miTvController.tvIp}"
            }
        }
    }

    /**
     * Sets up Mode B: Tuya Color Wheel + Brightness & Saturation SeekBars + 6 Quick Presets.
     */
    private fun setupLightColorWheelAndSliders() {
        renderColorPresetSwatches()

        binding.tuyaColorWheel.hue = currentHue
        binding.tuyaColorWheel.saturation = currentSatPercent / 100f
        binding.tuyaColorWheel.brightness = currentBrightPercent / 100f

        binding.tuyaColorWheel.onHapticTick = {
            performLightHaptic(binding.tuyaColorWheel)
        }

        binding.tuyaColorWheel.onCenterPowerToggle = {
            val targetDevice = activeLightDeviceId()
            if (currentMode == ConsoleMode.LIGHT_SCONCE) {
                isSconceOn = !isSconceOn
                binding.tuyaColorWheel.isLightOn = isSconceOn
                updateHubCardsUi()
                lifecycleScope.launch { tuyaController.setPower(targetDevice, isSconceOn) }
            } else {
                isStripOn = !isStripOn
                binding.tuyaColorWheel.isLightOn = isStripOn
                updateHubCardsUi()
                lifecycleScope.launch { tuyaController.setPower(targetDevice, isStripOn) }
            }
        }

        binding.tuyaColorWheel.onHueChanged = { newHue, isFinal ->
            currentHue = newHue
            activePreset = null
            renderColorPresetSwatches()
            if (currentMode == ConsoleMode.LIGHT_SCONCE) isSconceOn = true else isStripOn = true
            updateHubCardsUi()
            dispatchLightHsvUpdate(immediate = isFinal)
        }

        binding.seekLightBrightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val clamped = progress.coerceAtLeast(1)
                currentBrightPercent = clamped
                binding.tvBrightnessPercent.text = "$clamped%"
                binding.tuyaColorWheel.brightness = clamped / 100f
                if (fromUser) dispatchLightHsvUpdate(immediate = false)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                performLightHaptic( binding.seekLightBrightness)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                dispatchLightHsvUpdate(immediate = true)
            }
        })

        binding.seekLightSaturation.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val clamped = progress.coerceAtLeast(5)
                currentSatPercent = clamped
                binding.tvSaturationPercent.text = "$clamped%"
                binding.tuyaColorWheel.saturation = clamped / 100f
                if (fromUser) dispatchLightHsvUpdate(immediate = false)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                performLightHaptic(binding.seekLightSaturation)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                dispatchLightHsvUpdate(immediate = true)
            }
        })

        val presetMap = listOf(
            binding.presetCyber to TuyaController.LightPreset.CYBER,
            binding.presetSapphire to TuyaController.LightPreset.SAPPHIRE,
            binding.presetViolet to TuyaController.LightPreset.VIOLET,
            binding.presetRaspberry to TuyaController.LightPreset.RASPBERRY,
            binding.presetSunset to TuyaController.LightPreset.SUNSET,
            binding.presetWarm to TuyaController.LightPreset.WARM
        )

        presetMap.forEach { (container, preset) ->
            container.setOnClickListener { view ->
                performLightHaptic(view)
                applyPresetToUiAndDevice(preset)
            }
        }
    }

    private fun applyPresetToUiAndDevice(preset: TuyaController.LightPreset) {
        activePreset = preset
        currentHue = preset.hue.toFloat()
        currentSatPercent = (preset.satPromille / 10).coerceIn(5, 100)
        currentBrightPercent = (preset.valPromille / 10).coerceIn(1, 100)

        binding.tuyaColorWheel.hue = currentHue
        binding.tuyaColorWheel.saturation = currentSatPercent / 100f
        binding.tuyaColorWheel.brightness = currentBrightPercent / 100f
        binding.tuyaColorWheel.isLightOn = true

        binding.seekLightBrightness.progress = currentBrightPercent
        binding.tvBrightnessPercent.text = "$currentBrightPercent%"
        binding.seekLightSaturation.progress = currentSatPercent
        binding.tvSaturationPercent.text = "$currentSatPercent%"

        if (currentMode == ConsoleMode.LIGHT_SCONCE) isSconceOn = true else isStripOn = true
        updateHubCardsUi()
        renderColorPresetSwatches()

        val targetDevice = activeLightDeviceId()
        lifecycleScope.launch {
            tuyaController.applyPreset(targetDevice, preset)
        }
    }

    private fun dispatchLightHsvUpdate(immediate: Boolean) {
        colorSendDebounceJob?.cancel()
        val targetDevice = activeLightDeviceId()
        val h = currentHue.toInt()
        val sPromille = (currentSatPercent * 10).coerceIn(10, 1000)
        val vPromille = (currentBrightPercent * 10).coerceIn(10, 1000)

        colorSendDebounceJob = lifecycleScope.launch {
            if (!immediate) {
                delay(140L)
            }
            tuyaController.setHsvColor(
                deviceId = targetDevice,
                hue = h,
                satPromille = sPromille,
                valPromille = vPromille
            )
        }
    }

    private fun activeLightDeviceId(): String {
        return if (currentMode == ConsoleMode.LIGHT_SCONCE) {
            tuyaController.sconceDeviceId
        } else {
            tuyaController.stripDeviceId
        }
    }

    /**
     * Slide-Up Smart Home & Remote Selector Hub Drawer:
     * - Swipe up from bottom handle (or tap handle) -> opens Hub Sheet.
     * - Card 1 (TV Remote): Tap -> switches screen to TV Remote mode.
     * - Card 2 (RGB Strip): Short tap -> toggles Strip ON/OFF; Long press -> opens Color Wheel for Strip.
     * - Card 3 (Sconce/Lamp): Short tap -> toggles Sconce ON/OFF; Long press -> opens Color Wheel for Sconce.
     */
    private fun setupBottomSwipeHubDrawer() {
        val gestureDetector = GestureDetector(
            this,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onSingleTapUp(e: MotionEvent): Boolean {
                    openHubDrawer()
                    return true
                }

                override fun onFling(
                    e1: MotionEvent?,
                    e2: MotionEvent,
                    velocityX: Float,
                    velocityY: Float
                ): Boolean {
                    if (velocityY < -180f) {
                        openHubDrawer()
                        return true
                    }
                    return false
                }
            }
        )

        binding.bottomSwipeHandleArea.setOnTouchListener { view, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                performLightHaptic(view)
            }
            gestureDetector.onTouchEvent(event)
            true
        }

        binding.hubScrimOverlay.setOnClickListener {
            closeHubDrawer()
        }

        binding.sheetTopDragPill.setOnClickListener {
            closeHubDrawer()
        }

        // Card 1: Switch to TV Remote Mode
        binding.cardHubTv.setOnClickListener { view ->
            performLightHaptic(view)
            switchConsoleMode(ConsoleMode.TV_REMOTE)
            closeHubDrawer()
        }

        // Card 2: RGB Strip (Short tap = toggle power; Long press = open Strip Color Wheel)
        binding.cardHubStrip.setOnClickListener { view ->
            performLightHaptic(view)
            isStripOn = !isStripOn
            if (currentMode == ConsoleMode.LIGHT_STRIP) {
                binding.tuyaColorWheel.isLightOn = isStripOn
            }
            updateHubCardsUi()
            lifecycleScope.launch {
                tuyaController.setPower(tuyaController.stripDeviceId, isStripOn)
            }
        }

        binding.cardHubStrip.setOnLongClickListener { view ->
            performLightHaptic(view)
            isStripOn = true
            switchConsoleMode(ConsoleMode.LIGHT_STRIP)
            closeHubDrawer()
            true
        }

        // Card 3: Sconce / Lamp (Short tap = toggle power; Long press = open Sconce Color Wheel)
        binding.cardHubSconce.setOnClickListener { view ->
            performLightHaptic(view)
            isSconceOn = !isSconceOn
            if (currentMode == ConsoleMode.LIGHT_SCONCE) {
                binding.tuyaColorWheel.isLightOn = isSconceOn
            }
            updateHubCardsUi()
            lifecycleScope.launch {
                tuyaController.setPower(tuyaController.sconceDeviceId, isSconceOn)
            }
        }

        binding.cardHubSconce.setOnLongClickListener { view ->
            performLightHaptic(view)
            isSconceOn = true
            switchConsoleMode(ConsoleMode.LIGHT_SCONCE)
            closeHubDrawer()
            true
        }

        updateHubCardsUi()
    }

    private fun switchConsoleMode(newMode: ConsoleMode) {
        currentMode = newMode
        when (newMode) {
            ConsoleMode.TV_REMOTE -> {
                binding.lightControlModeContainer.visibility = View.GONE
                binding.tvRemoteModeContainer.visibility = View.VISIBLE
            }
            ConsoleMode.LIGHT_STRIP -> {
                binding.tvRemoteModeContainer.visibility = View.GONE
                binding.lightControlModeContainer.visibility = View.VISIBLE
                binding.tvActiveLightTitle.text = "SMART LED STRIP"
                binding.tuyaColorWheel.isLightOn = isStripOn
            }
            ConsoleMode.LIGHT_SCONCE -> {
                binding.tvRemoteModeContainer.visibility = View.GONE
                binding.lightControlModeContainer.visibility = View.VISIBLE
                binding.tvActiveLightTitle.text = "SMART LAMP / БРА"
                binding.tuyaColorWheel.isLightOn = isSconceOn
            }
        }
        updateHubCardsUi()
    }

    private fun openHubDrawer() {
        if (isHubOpen) return
        isHubOpen = true
        updateHubCardsUi()
        binding.hubScrimOverlay.visibility = View.VISIBLE
        binding.hubBottomSheet.visibility = View.VISIBLE

        binding.hubScrimOverlay.animate()
            .alpha(1f)
            .setDuration(200L)
            .start()

        binding.hubBottomSheet.animate()
            .translationY(0f)
            .setDuration(240L)
            .start()
    }

    private fun closeHubDrawer() {
        if (!isHubOpen) return
        isHubOpen = false

        binding.hubScrimOverlay.animate()
            .alpha(0f)
            .setDuration(180L)
            .withEndAction {
                binding.hubScrimOverlay.visibility = View.GONE
            }
            .start()

        binding.hubBottomSheet.animate()
            .translationY(420f)
            .setDuration(220L)
            .withEndAction {
                binding.hubBottomSheet.visibility = View.GONE
            }
            .start()
    }

    private fun updateHubCardsUi() {
        binding.cardHubTv.isSelected = (currentMode == ConsoleMode.TV_REMOTE)
        binding.cardHubStrip.isSelected = (currentMode == ConsoleMode.LIGHT_STRIP)
        binding.cardHubSconce.isSelected = (currentMode == ConsoleMode.LIGHT_SCONCE)

        binding.tvHubTvSub.text = if (currentMode == ConsoleMode.TV_REMOTE) "На экране" else "Выбрать"
        binding.tvHubTvSub.setTextColor(
            ContextCompat.getColor(
                this,
                if (currentMode == ConsoleMode.TV_REMOTE) R.color.preset_cyber else R.color.text_secondary
            )
        )

        binding.tvHubStripSub.text = if (isStripOn) "ВКЛ · Зажми" else "ВЫКЛ · Зажми"
        binding.tvHubStripSub.setTextColor(
            ContextCompat.getColor(
                this,
                if (isStripOn) R.color.status_online else R.color.text_secondary
            )
        )

        binding.tvHubSconceSub.text = if (isSconceOn) "ВКЛ · Зажми" else "ВЫКЛ · Зажми"
        binding.tvHubSconceSub.setTextColor(
            ContextCompat.getColor(
                this,
                if (isSconceOn) R.color.status_online else R.color.text_secondary
            )
        )
    }

    private fun renderColorPresetSwatches() {
        val swatches = listOf(
            binding.swatchCyber to TuyaController.LightPreset.CYBER,
            binding.swatchSapphire to TuyaController.LightPreset.SAPPHIRE,
            binding.swatchViolet to TuyaController.LightPreset.VIOLET,
            binding.swatchRaspberry to TuyaController.LightPreset.RASPBERRY,
            binding.swatchSunset to TuyaController.LightPreset.SUNSET,
            binding.swatchWarm to TuyaController.LightPreset.WARM
        )

        val density = resources.displayMetrics.density
        swatches.forEach { (view, preset) ->
            val isSelected = (preset == activePreset)
            val drawable = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(preset.previewHexColor)
                if (isSelected) {
                    setStroke((2.5f * density).toInt(), Color.WHITE)
                } else {
                    setStroke((1f * density).toInt(), Color.parseColor("#33FFFFFF"))
                }
            }
            view.background = drawable
            view.scaleX = if (isSelected) 1.15f else 1.0f
            view.scaleY = if (isSelected) 1.15f else 1.0f
        }
    }

    private fun updateStatusBadgeUi(ip: String, isOnline: Boolean) {
        binding.tvStickIpBadge.text = "Mi TV Stick: $ip"
        val colorRes = if (isOnline) R.color.status_online else R.color.status_sleeping
        val resolvedColor = ContextCompat.getColor(this, colorRes)
        binding.tvStickIpBadge.setTextColor(resolvedColor)
        (binding.statusDotView.background as? GradientDrawable)?.setColor(resolvedColor)
        binding.tvScreenState.text = getString(
            if (isOnline) R.string.tv_screen_on else R.string.tv_screen_sleep
        )
    }

    private fun startClockAndTvPolling() {
        clockAndStatusJob?.cancel()
        clockAndStatusJob = lifecycleScope.launch {
            while (isActive) {
                val now = Date()
                binding.tvClock.text = timeFormat.format(now)
                binding.tvDate.text = dateFormat.format(now).uppercase(Locale("ru", "RU"))

                val status = miTvController.pollScreenStatus()
                updateStatusBadgeUi(status.ip, status.isReachable && status.isInteractive)

                delay(3000L)
            }
        }
    }

    private fun animateTopNeonVoiceLine(active: Boolean) {
        runOnUiThread {
            if (active) {
                if (neonPulseAnimator == null) {
                    val alphaHolder = PropertyValuesHolder.ofFloat(View.ALPHA, 0.35f, 1.0f)
                    val scaleXHolder = PropertyValuesHolder.ofFloat(View.SCALE_X, 0.7f, 1.35f)
                    neonPulseAnimator = ObjectAnimator.ofPropertyValuesHolder(
                        binding.neonVoiceLine,
                        alphaHolder,
                        scaleXHolder
                    ).apply {
                        duration = 480L
                        repeatCount = ObjectAnimator.INFINITE
                        repeatMode = ObjectAnimator.REVERSE
                    }
                }
                if (neonPulseAnimator?.isRunning != true) {
                    neonPulseAnimator?.start()
                }
            } else {
                neonPulseAnimator?.cancel()
                binding.neonVoiceLine.animate()
                    .alpha(0.25f)
                    .scaleX(1.0f)
                    .setDuration(220L)
                    .start()
            }
        }
    }

    private fun checkAudioPermissionAndStartVoiceEngine() {
        initVoiceEngine()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                1001
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            initVoiceEngine()
        }
    }

    private fun initVoiceEngine() {
        voiceEngine?.stop()
        voiceEngine = VoiceAssistantEngine(
            context = this,
            scope = lifecycleScope,
            miTvController = miTvController,
            tuyaController = tuyaController,
            onVoiceActivityChanged = { active -> animateTopNeonVoiceLine(active) },
            onLocalPresetChanged = { preset ->
                runOnUiThread {
                    applyPresetToUiAndDevice(preset)
                }
            },
            onLocalStripPowerChanged = { enabled ->
                runOnUiThread {
                    isStripOn = enabled
                    binding.tuyaColorWheel.isLightOn = enabled
                    updateHubCardsUi()
                }
            }
        ).also { it.start() }
    }

    private fun performLightHaptic(view: View) {
        view.performHapticFeedback(
            HapticFeedbackConstants.KEYBOARD_TAP,
            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
        )
        try {
            val vibrator = getSystemService(Vibrator::class.java)
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(14L, 90))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(14L)
                }
            }
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        clockAndStatusJob?.cancel()
        colorSendDebounceJob?.cancel()
        voiceEngine?.stop()
        super.onDestroy()
    }
}
