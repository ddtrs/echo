package com.smartconsole.touch.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import androidx.core.graphics.ColorUtils
import java.util.Calendar
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Маскот «Эхо» (Echo) — круглое дружелюбное существо в наушниках.
 * Рисуется нативно на Canvas без растровых картинок и аллокаций в onDraw (60 FPS на Huawei Y5 DRA-L21).
 * Виртуальная система координат: 380x250, центр корпуса (190, 126).
 * Цвет строго системный (#00F0FF, и #FF5A5F при ошибке/тряске) — не меняется от цвета ленты.
 */
class EchoView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr), Choreographer.FrameCallback {

    enum class Mood {
        IDLE,
        LISTENING,
        THINKING,
        SPEAKING,
        HAPPY,
        ERROR
    }

    companion object {
        private var thinkingCallCounter = 0

        fun listeningPhrase(isFollowUp: Boolean = false): String {
            if (isFollowUp) return "Жду твой ответ…"
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            return when (hour) {
                in 5..11 -> "Доброе утро! Слушаю…"
                in 12..17 -> "Я тут, говори…"
                in 18..22 -> "На связи, слушаю…"
                else -> "Я тут, слушаю…"
            }
        }

        fun thinkingPhrase(rawHint: String = ""): String {
            val h = rawHint.lowercase(Locale.ROOT)
            if (h.isNotBlank()) {
                when {
                    h.contains("spotify") || h.contains("песн") || h.contains("трек") ||
                        h.contains("музык") || h.contains("альбом") -> return "Ищу трек…"
                    h.contains("yt:") || h.contains("ютуб") || h.contains("youtube") ||
                        h.contains("видео") || h.contains("клип") || h.contains("фильм") ||
                        h.contains("ролик") -> return "Нахожу видео…"
                    h.contains("kick") || h.contains("стрим") -> return "Запускаю стрим…"
                    h.contains("лент") || h.contains("ламп") || h.contains("свет") ||
                        h.contains("подсвет") || h.contains("яркост") -> return "Настраиваю свет…"
                    h.contains("громк") || h.contains("тише") || h.contains("громче") ||
                        h.contains("звук") -> return "Настраиваю звук…"
                    h.contains("открой") || h.contains("запусти") || h.contains("включи") -> return "Выполняю…"
                }
            }
            thinkingCallCounter++
            return when (thinkingCallCounter % 3) {
                0 -> "Секунду, соображаю…"
                1 -> "Так-так, думаю…"
                else -> "Обрабатываю команду…"
            }
        }
    }

    var mood: Mood = Mood.IDLE
        set(value) {
            if (field != value) {
                field = value
                moodStartRealtimeMs = SystemClock.elapsedRealtime()
                if (value != Mood.LISTENING && value != Mood.SPEAKING) {
                    onFrameLevelUpdated?.invoke(0f, false, value == Mood.ERROR)
                }
                updateAnimationRunningState()
                invalidate()
            }
        }

    // Системный неоново-голубой цвет (#00F0FF) по умолчанию
    var accentColor: Int = Color.parseColor("#00F0FF")
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var targetLevel: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
        }

    var level: Float = 0f
        set(value) {
            val clamped = value.coerceIn(0f, 1f)
            field = clamped
            targetLevel = clamped
        }

    var showRings: Boolean = true
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var levelProvider: (() -> Float)? = null

    var onFrameLevelUpdated: ((smoothedLevel: Float, isActiveVoice: Boolean, isError: Boolean) -> Unit)? = null

    // Плавное слежение глаз за пальцем (-1..+1 -> ±8 виртуальных единиц)
    private var targetEyeOffsetX = 0f
    private var targetEyeOffsetY = 0f
    private var currentEyeOffsetX = 0f
    private var currentEyeOffsetY = 0f

    fun lookAtNormalized(nx: Float, ny: Float) {
        val maxShift = 7.5f
        targetEyeOffsetX = (nx * maxShift).coerceIn(-maxShift, maxShift)
        targetEyeOffsetY = (ny * maxShift).coerceIn(-maxShift, maxShift)
        invalidate()
    }

    fun resetLook() {
        targetEyeOffsetX = 0f
        targetEyeOffsetY = 0f
    }

    private val density = resources.displayMetrics.density
    private val bodyFillColor = Color.parseColor("#121214")
    private val errorColor = Color.parseColor("#FF5A5F")

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val bodyRect = RectF(115f, 62f, 265f, 190f)
    private val leftCupRect = RectF(94f, 104f, 116f, 148f)
    private val rightCupRect = RectF(264f, 104f, 286f, 148f)
    private val ringRect = RectF()

    private val headbandPath = Path().apply {
        moveTo(104f, 112f)
        cubicTo(104f, 22f, 276f, 22f, 276f, 112f)
    }
    private val smilePath = Path().apply {
        moveTo(178f, 147f)
        quadTo(190f, 156f, 202f, 147f)
    }
    private val happySmilePath = Path().apply {
        moveTo(175f, 146f)
        quadTo(190f, 160f, 205f, 146f)
    }
    private val thinkingMouthPath = Path().apply {
        moveTo(182f, 150f)
        lineTo(198f, 150f)
    }
    private val errorMouthPath = Path().apply {
        moveTo(172f, 150f)
        quadTo(176f, 144f, 180f, 150f)
        quadTo(184f, 156f, 188f, 150f)
        quadTo(192f, 144f, 196f, 150f)
    }
    private val errorLeftEyePath = Path().apply {
        moveTo(154f, 110f)
        lineTo(170f, 120f)
        lineTo(154f, 130f)
    }
    private val errorRightEyePath = Path().apply {
        moveTo(226f, 110f)
        lineTo(210f, 120f)
        lineTo(226f, 130f)
    }
    private val happyLeftEyePath = Path()
    private val happyRightEyePath = Path()

    private var isLoopRunning = false
    private var moodStartRealtimeMs = SystemClock.elapsedRealtime()
    private var currentTiltDeg = 0f

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        updateAnimationRunningState()
    }

    override fun onDetachedFromWindow() {
        stopAnimationLoop()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        updateAnimationRunningState()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        updateAnimationRunningState()
    }

    private fun updateAnimationRunningState() {
        val shouldRun = isAttachedToWindow && windowVisibility == VISIBLE && isShown
        if (shouldRun && !isLoopRunning) {
            isLoopRunning = true
            Choreographer.getInstance().postFrameCallback(this)
        } else if (!shouldRun && isLoopRunning) {
            stopAnimationLoop()
        }
    }

    private fun stopAnimationLoop() {
        if (isLoopRunning) {
            isLoopRunning = false
            Choreographer.getInstance().removeFrameCallback(this)
        }
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!isLoopRunning || !isShown) {
            isLoopRunning = false
            return
        }

        val activeVoice = (mood == Mood.LISTENING || mood == Mood.SPEAKING)
        val rawTarget = if (activeVoice) {
            (levelProvider?.invoke() ?: targetLevel).coerceIn(0f, 1f)
        } else {
            0f
        }
        level += (rawTarget - level) * 0.30f

        val goalTilt = when (mood) {
            Mood.THINKING -> -5f
            Mood.HAPPY -> 3.5f
            else -> 0f
        }
        currentTiltDeg += (goalTilt - currentTiltDeg) * 0.16f

        currentEyeOffsetX += (targetEyeOffsetX - currentEyeOffsetX) * 0.20f
        currentEyeOffsetY += (targetEyeOffsetY - currentEyeOffsetY) * 0.20f

        onFrameLevelUpdated?.invoke(level, activeVoice, mood == Mood.ERROR)

        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawEchoToCanvas(canvas, width.toFloat(), height.toFloat())
    }

    /**
     * Универсальная отрисовка маскота на любой Canvas (используется и в EchoView, и внутри капли EchoSiriOrbView).
     */
    fun drawEchoToCanvas(canvas: Canvas, vw: Float, vh: Float, extraTopOffsetPx: Float = 0f) {
        if (vw <= 2f || vh <= 2f) return

        val vpLeft = if (showRings) 52f else 84f
        val vpTop = if (showRings) 10f else 14f
        val vpWidth = if (showRings) 276f else 212f
        val vpHeight = if (showRings) 190f else 184f

        val scale = min(vw / vpWidth, vh / vpHeight)
        val offsetX = (vw - vpWidth * scale) * 0.5f - vpLeft * scale
        val offsetY = (vh - vpHeight * scale) * 0.5f - vpTop * scale + extraTopOffsetPx

        val nowMs = SystemClock.elapsedRealtime()
        val elapsedMoodSec = (nowMs - moodStartRealtimeMs) / 1000f
        val totalSec = (nowMs % 3600_000L) / 1000f

        val activeColor = if (mood == Mood.ERROR) errorColor else accentColor
        val mainStrokeUnits = max(4.5f, (2.0f * density) / scale)
        val mouthStrokeUnits = max(3.5f, (1.6f * density) / scale)
        val ringStrokeUnits = max(2.5f, (1.3f * density) / scale)

        canvas.save()
        canvas.translate(offsetX, offsetY)
        canvas.scale(scale, scale)

        // 1. Кольца эха (вокруг центра корпуса 190, 126)
        if (showRings && (mood == Mood.LISTENING || mood == Mood.SPEAKING)) {
            val periodSec = 2.1f
            val delays = floatArrayOf(0f, 0.7f, 1.4f)
            strokePaint.strokeWidth = ringStrokeUnits
            for (d in delays) {
                val t = elapsedMoodSec - d
                if (t < 0f) continue
                val phase = (t % periodSec) / periodSec
                val ringScale: Float
                val ringAlpha: Float
                if (mood == Mood.LISTENING) {
                    val easeIn = phase * phase
                    ringScale = 1.50f - (1.50f - 1.02f) * easeIn
                    ringAlpha = if (phase < 0.35f) {
                        (phase / 0.35f) * 0.50f
                    } else {
                        ((1f - phase) / 0.65f) * 0.50f
                    }
                } else {
                    val easeOut = 1f - (1f - phase) * (1f - phase)
                    ringScale = 1.02f + (1.50f - 1.02f) * easeOut
                    ringAlpha = 0.55f * (1f - easeOut)
                }
                val alphaInt = (ringAlpha * 255f).toInt().coerceIn(0, 255)
                if (alphaInt > 4) {
                    strokePaint.color = ColorUtils.setAlphaComponent(activeColor, alphaInt)
                    canvas.save()
                    canvas.scale(ringScale, ringScale, 190f, 126f)
                    ringRect.set(bodyRect)
                    canvas.drawRoundRect(ringRect, 58f, 58f, strokePaint)
                    canvas.restore()
                }
            }
        }

        // 2. Трансформация корпуса
        var bodyScale = 1.0f
        var shakeDx = 0f

        when (mood) {
            Mood.IDLE, Mood.HAPPY -> {
                val w = (2.0 * PI * (totalSec / 3.4)).toFloat()
                bodyScale = 1.0f + 0.016f * (1f - cos(w))
            }
            Mood.SPEAKING -> {
                bodyScale = 1.0f + 0.06f * level
            }
            Mood.ERROR -> {
                if (elapsedMoodSec < 1.2f) {
                    shakeDx = 5.5f * sin((elapsedMoodSec * 4.5 * PI).toFloat())
                }
            }
            else -> {}
        }

        canvas.save()
        if (shakeDx != 0f) {
            canvas.translate(shakeDx, 0f)
        }
        if (currentTiltDeg != 0f) {
            canvas.rotate(currentTiltDeg, 190f, 126f)
        }
        if (bodyScale != 1.0f) {
            canvas.scale(bodyScale, bodyScale, 190f, 126f)
        }

        // 2.1. Дужка наушников
        strokePaint.color = activeColor
        strokePaint.strokeWidth = mainStrokeUnits
        canvas.drawPath(headbandPath, strokePaint)

        // 2.2. Амбушюры
        val cupScale = if (mood == Mood.LISTENING) (1.0f + 0.40f * level) else 1.0f
        fillPaint.color = bodyFillColor
        strokePaint.color = activeColor
        strokePaint.strokeWidth = mainStrokeUnits

        canvas.save()
        if (cupScale != 1.0f) canvas.scale(cupScale, cupScale, 105f, 126f)
        canvas.drawRoundRect(leftCupRect, 11f, 11f, fillPaint)
        canvas.drawRoundRect(leftCupRect, 11f, 11f, strokePaint)
        canvas.restore()

        canvas.save()
        if (cupScale != 1.0f) canvas.scale(cupScale, cupScale, 275f, 126f)
        canvas.drawRoundRect(rightCupRect, 11f, 11f, fillPaint)
        canvas.drawRoundRect(rightCupRect, 11f, 11f, strokePaint)
        canvas.restore()

        // 2.3. Корпус
        fillPaint.color = bodyFillColor
        canvas.drawRoundRect(bodyRect, 58f, 58f, fillPaint)
        strokePaint.color = activeColor
        strokePaint.strokeWidth = mainStrokeUnits
        canvas.drawRoundRect(bodyRect, 58f, 58f, strokePaint)

        // 2.4. Щёчки
        val cheekAlpha = if (mood == Mood.HAPPY) 96 else 56
        fillPaint.color = ColorUtils.setAlphaComponent(activeColor, cheekAlpha)
        canvas.drawCircle(146f, 142f, 6.2f, fillPaint)
        canvas.drawCircle(234f, 142f, 6.2f, fillPaint)

        // 2.5. Глаза
        val lx = 162f + currentEyeOffsetX
        val rx = 218f + currentEyeOffsetX
        val ey = 120f + currentEyeOffsetY

        when (mood) {
            Mood.ERROR -> {
                strokePaint.color = activeColor
                strokePaint.strokeWidth = max(5.0f, mainStrokeUnits)
                canvas.drawPath(errorLeftEyePath, strokePaint)
                canvas.drawPath(errorRightEyePath, strokePaint)
            }
            Mood.HAPPY -> {
                strokePaint.color = activeColor
                strokePaint.strokeWidth = max(4.5f, mainStrokeUnits)
                happyLeftEyePath.reset()
                happyLeftEyePath.moveTo(lx - 8.5f, ey + 3f)
                happyLeftEyePath.quadTo(lx, ey - 9.5f, lx + 8.5f, ey + 3f)
                happyRightEyePath.reset()
                happyRightEyePath.moveTo(rx - 8.5f, ey + 3f)
                happyRightEyePath.quadTo(rx, ey - 9.5f, rx + 8.5f, ey + 3f)
                canvas.drawPath(happyLeftEyePath, strokePaint)
                canvas.drawPath(happyRightEyePath, strokePaint)
            }
            else -> {
                val blinkCycleMs = (nowMs % 4500L)
                val isBlinking = blinkCycleMs in 4380L..4500L
                val eyeScaleX = if (mood == Mood.LISTENING) 1.18f else 1.0f
                val eyeScaleY = when {
                    isBlinking -> 0.10f
                    mood == Mood.SPEAKING -> 0.85f
                    mood == Mood.LISTENING -> 1.18f
                    else -> 1.0f
                }
                fillPaint.color = activeColor

                canvas.save()
                canvas.scale(eyeScaleX, eyeScaleY, lx, ey)
                canvas.drawCircle(lx, ey, 8.5f, fillPaint)
                canvas.restore()

                canvas.save()
                canvas.scale(eyeScaleX, eyeScaleY, rx, ey)
                canvas.drawCircle(rx, ey, 8.5f, fillPaint)
                canvas.restore()
            }
        }

        // 2.6. Рот
        strokePaint.color = activeColor
        strokePaint.strokeWidth = mouthStrokeUnits
        when (mood) {
            Mood.IDLE, Mood.SPEAKING -> canvas.drawPath(smilePath, strokePaint)
            Mood.HAPPY -> canvas.drawPath(happySmilePath, strokePaint)
            Mood.THINKING -> canvas.drawPath(thinkingMouthPath, strokePaint)
            Mood.ERROR -> canvas.drawPath(errorMouthPath, strokePaint)
            Mood.LISTENING -> {}
        }

        canvas.restore()

        // 3. Три точки размышления над головой
        if (mood == Mood.THINKING) {
            val dotXs = floatArrayOf(172f, 190f, 208f)
            val period = 1.2f
            for (i in 0..2) {
                val localT = ((elapsedMoodSec - i * 0.2f).coerceAtLeast(0f)) % period
                val norm = localT / period
                val wave = 0.5f * (1f - cos((2.0 * PI * norm).toFloat()))
                val alpha = 0.25f + 0.75f * wave
                fillPaint.color = ColorUtils.setAlphaComponent(activeColor, (alpha * 255f).toInt().coerceIn(64, 255))
                canvas.drawCircle(dotXs[i], 16f, 5f, fillPaint)
            }
        }

        canvas.restore()
    }
}
