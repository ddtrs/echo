package com.smartconsole.touch.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import androidx.core.graphics.ColorUtils
import java.util.Calendar
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Маскот «Эхо» (Echo) — круглое дружелюбное существо в наушниках.
 * Рисуется нативно на Canvas без растровых картинок и аллокаций в onDraw (60 FPS на Huawei Y5 DRA-L21).
 * Виртуальная система координат: 380x250, центр корпуса (190, 126).
 * Цвет строго системный (#00F0FF, и #FF5A5F при ошибке/тряске) — не меняется от цвета ленты.
 */
class EchoView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr), Choreographer.FrameCallback {

    enum class Mood {
        IDLE,
        LISTENING,
        THINKING,
        SPEAKING,
        HAPPY,
        ERROR
    }

    companion object {
        private var thinkingCallCounter = 0
        private const val PIF = 3.1415927f
        const val WAKE_FULL_MS = 2500L
        const val WAKE_QUICK_MS = 900L

        fun greetingPhrase(): String {
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            return when (hour) {
                in 5..10 -> "Доброе утро!"
                in 11..17 -> "Привет! Я тут"
                in 18..22 -> "Добрый вечер!"
                else -> "Не спится? Я с тобой"
            }
        }

        fun listeningPhrase(isFollowUp: Boolean = false): String {
            if (isFollowUp) return "Жду твой ответ…"
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            return when (hour) {
                in 5..11 -> "Доброе утро! Слушаю…"
                in 12..17 -> "Я тут, говори…"
                in 18..22 -> "На связи, слушаю…"
                else -> "Я тут, слушаю…"
            }
        }

        fun thinkingPhrase(rawHint: String = ""): String {
            val h = rawHint.lowercase(Locale.ROOT)
            if (h.isNotBlank()) {
                when {
                    h.contains("spotify") || h.contains("песн") || h.contains("трек") ||
                        h.contains("музык") || h.contains("альбом") -> return "Ищу трек…"
                    h.contains("yt:") || h.contains("ютуб") || h.contains("youtube") ||
                        h.contains("видео") || h.contains("клип") || h.contains("фильм") ||
                        h.contains("ролик") -> return "Нахожу видео…"
                    h.contains("kick") || h.contains("стрим") -> return "Запускаю стрим…"
                    h.contains("лент") || h.contains("ламп") || h.contains("свет") ||
                        h.contains("подсвет") || h.contains("яркост") -> return "Настраиваю свет…"
                    h.contains("громк") || h.contains("тише") || h.contains("громче") ||
                        h.contains("звук") -> return "Настраиваю звук…"
                    h.contains("открой") || h.contains("запусти") || h.contains("включи") -> return "Выполняю…"
                }
            }
            thinkingCallCounter++
            return when (thinkingCallCounter % 3) {
                0 -> "Секунду, соображаю…"
                1 -> "Так-так, думаю…"
                else -> "Обрабатываю команду…"
            }
        }
    }

    var mood: Mood = Mood.IDLE
        set(value) {
            if (field != value) {
                field = value
                moodStartRealtimeMs = SystemClock.elapsedRealtime()
                if (value != Mood.LISTENING && value != Mood.SPEAKING) {
                    onFrameLevelUpdated?.invoke(0f, false, value == Mood.ERROR)
                }
                noteInteraction()
                updateAnimationRunningState()
                invalidate()
            }
        }

    // Системный неоново-голубой цвет (#00F0FF) по умолчанию
    var accentColor: Int = Color.parseColor("#00F0FF")
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var targetLevel: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
        }

    var level: Float = 0f
        set(value) {
            val clamped = value.coerceIn(0f, 1f)
            field = clamped
            targetLevel = clamped
        }

    var showRings: Boolean = true
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var levelProvider: (() -> Float)? = null

    var onFrameLevelUpdated: ((smoothedLevel: Float, isActiveVoice: Boolean, isError: Boolean) -> Unit)? = null

    // Слежение глаз за пальцем (-1..+1 -> ±7.5 виртуальных единиц) имеет приоритет над «живым» взглядом
    private var touchLookX = 0f
    private var touchLookY = 0f
    private var manualLookUntilMs = 0L
    private var currentEyeOffsetX = 0f
    private var currentEyeOffsetY = 0f

    fun lookAtNormalized(nx: Float, ny: Float) {
        val maxShift = 7.5f
        touchLookX = (nx * maxShift).coerceIn(-maxShift, maxShift)
        touchLookY = (ny * maxShift).coerceIn(-maxShift, maxShift)
        manualLookUntilMs = SystemClock.elapsedRealtime() + 1500L
        noteInteraction()
        invalidate()
    }

    fun resetLook() {
        touchLookX = 0f
        touchLookY = 0f
        manualLookUntilMs = SystemClock.elapsedRealtime() + 350L
    }

    // ───────────────────────── «ЖИЗНЬ» ЭХО ─────────────────────────
    // Все значения считаются в tick() (без аллокаций), onDraw только читает.
    private var lastTickMs = 0L
    private var lastInteractionMs = SystemClock.elapsedRealtime()
    private var skipToggle = false

    // веки: 0 = открыты, 1 = закрыты
    private var lid = 0f
    private var winkRight = 0f
    private var blinkLid = 0f
    private var blinkStartMs = -1L
    private var blinkDurMs = 160f
    private var blinkQueued = false
    private var blinkIsSecond = false
    private var nextBlinkAtMs = SystemClock.elapsedRealtime() + 2200L

    // «живой» взгляд (саккады)
    private var autoGazeX = 0f
    private var autoGazeY = 0f
    private var nextGazeAtMs = 0L

    // микро-эмоции: 1 = ухмылка, 2 = подмигивание, 3 = любопытный наклон головы
    private var microKind = 0
    private var microStartMs = 0L
    private var microEnv = 0f
    private var microDir = 1f
    private var nextMicroAtMs = SystemClock.elapsedRealtime() + 6000L
    private var smirkAmt = 0f
    private var microTilt = 0f

    // сон: днём только дремлет, глубоко спит ночью / в темноте
    private var sleepAmt = 0f
    private var drowsyAmt = 0f
    private var restAmt = 0f
    private var breathPhase = 0f
    private var isNight = false
    private var nextNightCheckMs = 0L
    private var nightDim = 0f

    // «игры» питомца (в капле выключены — там Эхо виден секунды)
    var lifeActivities: Boolean = true
    private var lastActKind = 0
    private var actDy = 0f
    private var actStretch = 0f
    private var actYawn = 0f
    private var actMouthO = 0f
    private var actLid = 0f
    private var actPop = 1f
    private var actGazeX = 0f
    private var actGazeY = 0f

    // реакции на комнату и пульт
    private var watchingTv = false
    private var tvGlanceUntilMs = 0L
    private var lowBattery = false
    private var charging = false
    private var luxFast = -1f
    private var luxSlow = -1f
    private var lightCooldownMs = 0L
    private var ambientDark = false
    private var reactType = 0   // 1 = ослепил свет, 2 = выключили свет, 3 = подняли телефон, 4 = включили ТВ
    private var reactStartMs = 0L
    private var reactPop = 1f
    private var reactLid = 0f
    private var reactTilt = 0f
    private var reactGazeX = 0f
    private var reactGazeY = 0f
    private var reactMouthO = 0f
    private var pokeStartMs = -1L
    private var pokeCount = 0
    private var lastPokeMs = 0L
    private var pokeLid = 0f
    private var pokeDy = 0f
    private var giggleUntilMs = 0L
    private var faceO = 0f

    // пробуждение («глаза открываются»)
    private var wakeStartMs = -1L
    private var wakeFull = true
    private var wakeLid = 0f
    private var wakePop = 1f
    private var wakeSX = 1f
    private var wakeSY = 1f
    private var wakeDy = 0f
    private var wakeTilt = 0f
    private var wakeCupLift = 0f
    private var wakeYawn = 0f
    private var wakeGazeX = 0f
    private var wakeGazeY = 0f

    val isAsleep: Boolean get() = sleepAmt > 0.5f

    fun wakeDurationMs(full: Boolean): Long = if (full) WAKE_FULL_MS else WAKE_QUICK_MS

    /**
     * Эхо просыпается: full = сонное пробуждение (зевок, потягивание, оглядывается),
     * иначе — быстрое «встрепенулся». delayMs — пауза с закрытыми глазами (пока раскрывается капля).
     */
    fun playWakeUp(full: Boolean = true, delayMs: Long = 0L) {
        val now = SystemClock.elapsedRealtime()
        wakeFull = full
        wakeStartMs = now + delayMs
        lastInteractionMs = now + delayMs
        sleepAmt = 0f
        blinkStartMs = -1L
        blinkQueued = false
        blinkIsSecond = false
        val end = now + delayMs + wakeDurationMs(full)
        nextBlinkAtMs = end + 900L
        nextMicroAtMs = end + 5000L
        microKind = 0
        updateAnimationRunningState()
        invalidate()
    }

    /** Мгновенно «уснуть» (например, при выключении экрана) — следующее playWakeUp начнётся с закрытых глаз. */
    fun fallAsleepNow() {
        sleepAmt = 1f
        wakeStartMs = -1L
        invalidate()
    }

    /** ТВ включён → Эхо «смотрит» вместе с вами; выключили → зевает. */
    fun setWatchingTv(on: Boolean) {
        if (watchingTv == on) return
        watchingTv = on
        if (on) startReact(4) else { startReact(0); startActivity(SystemClock.elapsedRealtime(), 6) }
        invalidate()
    }

    /** Заряд: низкий — грустит и «голодный», поставили на зарядку — радуется. */
    fun setBattery(pct: Int, isCharging: Boolean) {
        lowBattery = pct in 0..15 && !isCharging
        if (isCharging && !charging) {
            giggleUntilMs = SystemClock.elapsedRealtime() + 1400L
            noteInteraction()
        }
        charging = isCharging
    }

    /** Датчик освещённости: резко включили свет — щурится, выключили — «ой!». */
    fun onAmbientLux(lux: Float) {
        val now = SystemClock.elapsedRealtime()
        if (luxFast < 0f) { luxFast = lux; luxSlow = lux }
        luxFast += (lux - luxFast) * 0.5f
        luxSlow += (lux - luxSlow) * 0.03f
        ambientDark = luxSlow < 5f
        if (now < lightCooldownMs) return
        if (luxFast > 40f && luxFast > luxSlow * 3f) {
            startReact(1)
            lightCooldownMs = now + 5000L
            luxSlow = luxFast
        } else if (luxSlow > 25f && luxFast < luxSlow * 0.3f) {
            startReact(2)
            lightCooldownMs = now + 5000L
            luxSlow = luxFast
        }
    }

    /** Телефон подняли со стола — «ого!». */
    fun onPickedUp() {
        val now = SystemClock.elapsedRealtime()
        if (reactType == 3 && now - reactStartMs < 6000L) return
        startReact(3)
    }

    /** Тык в лицо: жмурится; три тыка подряд — хихикает. */
    fun poke() {
        val now = SystemClock.elapsedRealtime()
        noteInteraction()
        pokeCount = if (now - lastPokeMs < 2000L) pokeCount + 1 else 1
        lastPokeMs = now
        pokeStartMs = now
        if (pokeCount >= 3) {
            giggleUntilMs = now + 1500L
            pokeCount = 0
        }
        invalidate()
    }

    private fun startReact(type: Int) {
        val now = SystemClock.elapsedRealtime()
        reactType = type
        reactStartMs = now
        lastInteractionMs = now
        if (sleepAmt > 0.3f && wakeStartMs < 0L) playWakeUp(full = false)
        microKind = 0
        nextMicroAtMs = now + 4000L
        updateAnimationRunningState()
    }

    private fun reactDuration(t: Int): Float = when (t) {
        1 -> 1600f
        2 -> 1800f
        3 -> 1400f
        else -> 1100f
    }

    private fun updateReact(nowMs: Long) {
        reactLid = 0f; reactPop = 1f; reactTilt = 0f; reactGazeX = 0f; reactGazeY = 0f; reactMouthO = 0f
        if (reactType == 0) return
        val t = (nowMs - reactStartMs).toFloat()
        val dur = reactDuration(reactType)
        if (t > dur) { reactType = 0; return }
        val p = t / dur
        when (reactType) {
            1 -> {
                reactLid = 0.8f * (1f - smooth(seg(p, 0.35f, 1f))) * smooth(seg(p, 0f, 0.1f))
                reactTilt = -4f * sin(PIF * p)
            }
            2 -> {
                reactPop = 1f + 0.25f * sin(PIF * seg(p, 0f, 0.35f))
                reactGazeX = 6f * sin(PIF * 3f * p) * (1f - smooth(seg(p, 0.7f, 1f)))
                reactMouthO = sin(PIF * seg(p, 0f, 0.5f))
            }
            3 -> {
                reactPop = 1f + 0.3f * sin(PIF * seg(p, 0f, 0.5f))
                reactGazeY = -4f * sin(PIF * seg(p, 0f, 0.8f))
                reactTilt = 5f * sin(PIF * 2f * p)
                reactMouthO = sin(PIF * seg(p, 0f, 0.7f))
            }
            4 -> {
                reactPop = 1f + 0.25f * sin(PIF * seg(p, 0f, 0.5f))
                reactGazeX = 6f * smooth(seg(p, 0.1f, 0.5f))
                reactGazeY = -2.5f * smooth(seg(p, 0.1f, 0.5f))
                reactMouthO = sin(PIF * seg(p, 0f, 0.6f))
            }
        }
    }

    private fun actDuration(k: Int): Float = when (k) {
        1 -> 1500f
        2 -> 700f
        3 -> 1700f
        4 -> 3200f
        5 -> 3000f
        6 -> 2200f
        else -> 3600f
    }

    private fun startActivity(nowMs: Long, forced: Int = 0) {
        var kind = forced
        if (kind == 0) {
            var tries = 0
            do {
                kind = if (drowsyAmt > 0.5f) (if (Random.nextBoolean()) 3 else 6) else 1 + Random.nextInt(7)
                tries++
            } while (kind == lastActKind && tries < 4)
            if (kind == 5 && Random.nextBoolean()) kind = 4
        }
        lastActKind = kind
        microKind = kind
        microStartMs = nowMs
        microDir = if (Random.nextBoolean()) 1f else -1f
    }

    private fun updateActivity(nowMs: Long) {
        val dur = actDuration(microKind)
        val p = (nowMs - microStartMs) / dur
        if (p >= 1f) {
            microKind = 0
            microEnv = 0f
            val base = if (drowsyAmt > 0.5f) 12_000L + Random.nextInt(13_000) else 5_000L + Random.nextInt(6_000)
            nextMicroAtMs = nowMs + (if (watchingTv) base * 2L else base)
            return
        }
        microEnv = sin(PIF * p)
        val ts = (nowMs - microStartMs) / 1000f
        val env = smooth(seg(p, 0f, 0.15f)) * (1f - smooth(seg(p, 0.85f, 1f)))
        when (microKind) {
            1 -> smirkAmt = microEnv
            2 -> { winkRight = min(1f, microEnv * 1.6f); smirkAmt = microEnv * 0.6f }
            3 -> microTilt = 5f * microDir * microEnv
            4 -> {
                // гоняется глазами за воображаемой мухой, в конце «поймал!»
                val fx = 7f * sin(PIF * 3f * p)
                val fy = 4f * sin(PIF * 4.6f * p + 1f)
                val e2 = smooth(seg(p, 0f, 0.08f)) * (1f - smooth(seg(p, 0.82f, 0.95f)))
                actGazeX = fx * e2
                actGazeY = fy * e2
                microTilt = actGazeX * 0.5f
                actMouthO = sin(PIF * seg(p, 0.85f, 1f))
                actPop = 1f + 0.15f * actMouthO
            }
            5 -> {
                // прятки: уходит вниз, выглядывает, оглядывается и выпрыгивает
                actDy = when {
                    p < 0.15f -> 100f * smooth(seg(p, 0f, 0.15f))
                    p < 0.50f -> 100f
                    p < 0.65f -> 100f - 38f * smooth(seg(p, 0.5f, 0.65f))
                    p < 0.78f -> 62f
                    p < 0.86f -> 62f - 62f * smooth(seg(p, 0.78f, 0.86f))
                    else -> 0f
                }
                val pk = seg(p, 0.5f, 0.78f)
                if (pk > 0f && pk < 1f) actGazeX = 6f * sin(PIF * 2f * pk)
                actPop = 1f + 0.25f * sin(PIF * seg(p, 0.8f, 1f))
                smirkAmt = 0.9f * smooth(seg(p, 0.84f, 0.95f))
            }
            6 -> {
                actYawn = sin(PIF * seg(p, 0.05f, 0.6f))
                actStretch = sin(PIF * seg(p, 0.45f, 0.95f))
                actLid = 0.85f * sin(PIF * seg(p, 0.1f, 0.55f))
            }
            else -> {
                // покачивается под «свою мелодию»
                val w = 2f * PIF * 0.55f * ts
                microTilt = 7f * sin(w) * env
                actDy = -2f * abs(sin(w)) * env
                actLid = 0.35f * env
                smirkAmt = 0.7f * env
            }
        }
    }

    private fun noteInteraction() {
        lastInteractionMs = SystemClock.elapsedRealtime()
        if (sleepAmt > 0.3f && wakeStartMs < 0L) playWakeUp(full = false)
    }

    private fun smooth(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun seg(t: Float, a: Float, b: Float): Float = ((t - a) / (b - a)).coerceIn(0f, 1f)

    private fun clearWakeOutputs() {
        wakeLid = 0f; wakePop = 1f; wakeSX = 1f; wakeSY = 1f; wakeDy = 0f
        wakeTilt = 0f; wakeCupLift = 0f; wakeYawn = 0f; wakeGazeX = 0f; wakeGazeY = 0f
    }

    private fun updateWake(nowMs: Long) {
        if (wakeStartMs < 0L) return
        val t = (nowMs - wakeStartMs).toFloat()
        if (t > wakeDurationMs(wakeFull).toFloat()) {
            wakeStartMs = -1L
            clearWakeOutputs()
            return
        }
        val tt = max(0f, t)
        if (wakeFull) {
            wakeLid = when {
                tt < 350f -> 1f
                tt < 950f -> 1f - 0.45f * smooth(seg(tt, 350f, 950f))
                tt < 1100f -> 0.55f + 0.37f * smooth(seg(tt, 950f, 1100f))
                else -> 0.92f * (1f - smooth(seg(tt, 1100f, 1380f)))
            }
            wakePop = 1f + 0.28f * sin(PIF * seg(tt, 1150f, 1700f))
            val stretch = sin(PIF * seg(tt, 1350f, 1950f))
            wakeSX = 1f - 0.045f * stretch
            wakeSY = 1f + 0.085f * stretch
            wakeCupLift = 4.5f * stretch
            val droop = 1f - smooth(seg(tt, 300f, 1150f))
            wakeDy = 3f * droop - 3.2f * stretch
            wakeTilt = 6f * droop
            wakeYawn = sin(PIF * seg(tt, 450f, 1250f))
            wakeGazeX = when {
                tt < 1500f -> 0f
                tt < 1750f -> -6f * smooth(seg(tt, 1500f, 1650f))
                tt < 2050f -> -6f + 12f * smooth(seg(tt, 1750f, 1900f))
                else -> 6f * (1f - smooth(seg(tt, 2050f, 2250f)))
            }
            wakeGazeY = 3f * droop
        } else {
            val s = sin(PIF * seg(tt, 80f, 440f))
            wakeLid = 0.85f * (1f - smooth(seg(tt, 0f, 180f)))
            wakePop = 1f + 0.22f * sin(PIF * seg(tt, 100f, 480f))
            wakeDy = -3f * s
            wakeSX = 1f - 0.025f * s
            wakeSY = 1f + 0.05f * s
            wakeCupLift = 2.5f * s
            wakeTilt = 0f; wakeYawn = 0f; wakeGazeX = 0f; wakeGazeY = 0f
        }
    }

    /**
     * Один шаг «жизни»: моргание, взгляд, микро-эмоции, сон, пробуждение, дыхание.
     * Вызывается из собственного doFrame (StandBy) и из EchoSiriOrbView (рендерер в капле не прикреплён к окну).
     */
    fun tick(nowMs: Long = SystemClock.elapsedRealtime()) {
        if (nowMs == lastTickMs) return
        val dt = if (lastTickMs == 0L) 0.016f else ((nowMs - lastTickMs) / 1000f).coerceIn(0.001f, 0.05f)
        lastTickMs = nowMs

        updateWake(nowMs)
        val wakeRunning = wakeStartMs >= 0L

        // голосовой уровень
        val activeVoice = (mood == Mood.LISTENING || mood == Mood.SPEAKING)
        val rawTarget = if (activeVoice) (levelProvider?.invoke() ?: targetLevel).coerceIn(0f, 1f) else 0f
        level += (rawTarget - level) * (1f - exp(-dt * 22f))

        // бодрость: днём только дремлет, глубоко спит ночью или в тёмной комнате
        if (nowMs >= nextNightCheckMs) {
            nextNightCheckMs = nowMs + 10_000L
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            isNight = h >= 23 || h < 7
        }
        val idleMs = nowMs - lastInteractionMs
        val dark = isNight || ambientDark
        val quiet = !wakeRunning && mood == Mood.IDLE && !watchingTv && reactType == 0
        val wantDrowsy = quiet && idleMs > (if (dark) 40_000L else 90_000L)
        val wantSleep = quiet && dark && idleMs > 150_000L
        drowsyAmt = if (wantDrowsy) min(1f, drowsyAmt + dt / 3f) else max(0f, drowsyAmt - dt / 0.4f)
        sleepAmt = if (wantSleep) min(1f, sleepAmt + dt / 2.5f) else max(0f, sleepAmt - dt / 0.35f)
        restAmt = max(sleepAmt, 0.6f * drowsyAmt)
        nightDim += ((if (isNight && mood == Mood.IDLE) 1f else 0f) - nightDim) * (1f - exp(-dt * 1.5f))

        // дыхание (фаза накапливается, чтобы не было скачка при засыпании)
        val breathPeriod = 3.4f + 1.8f * restAmt
        breathPhase += dt * (2f * PIF / breathPeriod)
        if (breathPhase > 2f * PIF * 1000f) breathPhase = 0f

        // моргание
        val canBlink = !wakeRunning && sleepAmt < 0.3f && mood != Mood.HAPPY && mood != Mood.ERROR
        if (!canBlink) {
            blinkStartMs = -1L
            blinkLid = 0f
        } else {
            if (blinkStartMs < 0L && nowMs >= nextBlinkAtMs) {
                blinkStartMs = nowMs
                blinkDurMs = (140f + Random.nextInt(50)) * (1f + 1.2f * drowsyAmt)
                if (!blinkIsSecond) blinkQueued = Random.nextInt(100) < 18
            }
            if (blinkStartMs >= 0L) {
                val p = (nowMs - blinkStartMs) / blinkDurMs
                if (p >= 1f) {
                    blinkStartMs = -1L
                    blinkLid = 0f
                    if (blinkQueued) {
                        blinkQueued = false
                        blinkIsSecond = true
                        nextBlinkAtMs = nowMs + 60L
                    } else {
                        blinkIsSecond = false
                        nextBlinkAtMs = nowMs + 1800L + Random.nextInt(3600)
                    }
                } else {
                    blinkLid = if (p < 0.38f) smooth(p / 0.38f) else 1f - smooth((p - 0.38f) / 0.62f)
                }
            }
        }

        // реакции, тык, «игры» питомца
        updateReact(nowMs)
        pokeLid = 0f; pokeDy = 0f
        if (pokeStartMs >= 0L) {
            val pt = (nowMs - pokeStartMs) / 420f
            if (pt >= 1f) {
                pokeStartMs = -1L
            } else {
                pokeLid = 0.9f * sin(PIF * pt)
                pokeDy = 3f * sin(PIF * pt)
            }
        }
        smirkAmt = 0f; microTilt = 0f; winkRight = 0f
        actDy = 0f; actStretch = 0f; actYawn = 0f; actMouthO = 0f; actLid = 0f; actPop = 1f
        actGazeX = 0f; actGazeY = 0f
        val calm = lifeActivities && mood == Mood.IDLE && !wakeRunning && sleepAmt < 0.05f &&
            nowMs >= manualLookUntilMs && reactType == 0 && pokeStartMs < 0L
        if (!calm) {
            microKind = 0
            microEnv = 0f
        } else if (microKind == 0) {
            if (nowMs >= nextMicroAtMs) startActivity(nowMs)
        } else {
            updateActivity(nowMs)
        }
        faceO = max(max(actMouthO, reactMouthO), pokeLid)

        // итоговые веки
        val perk = if (microKind == 3) microEnv else 0f
        val drowsyLid = drowsyAmt * (0.42f + 0.08f * sin(breathPhase)) * (1f - perk)
        val lowLid = if (lowBattery && mood == Mood.IDLE) 0.22f else 0f
        lid = if (wakeRunning) wakeLid else max(max(max(blinkLid, sleepAmt), max(drowsyLid, lowLid)), max(max(actLid, reactLid), pokeLid))

        // взгляд
        val sec = nowMs / 1000f
        var gx = 0f
        var gy = 0f
        when {
            wakeRunning -> { gx = wakeGazeX; gy = wakeGazeY }
            reactType in 2..4 -> { gx = reactGazeX; gy = reactGazeY }
            sleepAmt > 0.5f -> { gx = 0f; gy = 2.5f }
            mood == Mood.LISTENING -> { gx = 0f; gy = -2.5f }
            mood == Mood.THINKING -> { gx = 3.5f + 2.5f * sin(sec * 2.3f); gy = -4f + 1.5f * sin(sec * 3.1f) }
            mood == Mood.SPEAKING -> { gx = 1.5f * sin(sec * 5.1f); gy = 1.2f * sin(sec * 3.7f) }
            microKind == 3 -> { gx = microDir * 5.5f * microEnv; gy = -1.5f * microEnv }
            microKind == 4 || microKind == 5 -> { gx = actGazeX; gy = actGazeY }
            drowsyAmt > 0.5f -> { gx = 0f; gy = 1.8f }
            watchingTv && mood == Mood.IDLE -> {
                if (nowMs >= nextGazeAtMs) {
                    tvGlanceUntilMs = if (Random.nextInt(100) < 22) nowMs + 700L + Random.nextInt(900) else 0L
                    nextGazeAtMs = nowMs + 1800L + Random.nextInt(3200)
                }
                if (nowMs < tvGlanceUntilMs) { gx = 0f; gy = 0.5f } else { gx = 5.5f; gy = -2.5f }
            }
            else -> {
                if (nowMs >= nextGazeAtMs) {
                    if (Random.nextInt(100) < 30) {
                        autoGazeX = 0f; autoGazeY = 0f
                    } else {
                        autoGazeX = (Random.nextFloat() * 2f - 1f) * 6f
                        autoGazeY = (Random.nextFloat() * 2f - 1f) * 3.5f - 0.5f
                    }
                    nextGazeAtMs = nowMs + 1300L + Random.nextInt(2900)
                }
                gx = autoGazeX; gy = autoGazeY
            }
        }
        val useTouch = nowMs < manualLookUntilMs
        val tx = if (useTouch) touchLookX else gx
        val ty = if (useTouch) touchLookY else gy
        val kLook = 1f - exp(-dt * 14f)
        currentEyeOffsetX += (tx - currentEyeOffsetX) * kLook
        currentEyeOffsetY += (ty - currentEyeOffsetY) * kLook

        // наклон головы
        val goalTilt = when (mood) {
            Mood.THINKING -> -5f
            Mood.HAPPY -> 3.5f
            else -> 0f
        } + microTilt + wakeTilt + reactTilt + 4f * sleepAmt
        currentTiltDeg += (goalTilt - currentTiltDeg) * (1f - exp(-dt * 10.5f))

        onFrameLevelUpdated?.invoke(level, activeVoice, mood == Mood.ERROR)
    }

    private val density = resources.displayMetrics.density
    private val bodyFillColor = Color.parseColor("#121214")
    private val errorColor = Color.parseColor("#FF5A5F")

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val bodyRect = RectF(115f, 62f, 265f, 190f)
    private val leftCupRect = RectF(94f, 104f, 116f, 148f)
    private val rightCupRect = RectF(264f, 104f, 286f, 148f)
    private val ringRect = RectF()

    private val headbandPath = Path().apply {
        moveTo(104f, 112f)
        cubicTo(104f, 22f, 276f, 22f, 276f, 112f)
    }
    private val smilePath = Path().apply {
        moveTo(178f, 147f)
        quadTo(190f, 156f, 202f, 147f)
    }
    private val happySmilePath = Path().apply {
        moveTo(175f, 146f)
        quadTo(190f, 160f, 205f, 146f)
    }
    private val thinkingMouthPath = Path().apply {
        moveTo(182f, 150f)
        lineTo(198f, 150f)
    }
    private val errorMouthPath = Path().apply {
        moveTo(172f, 150f)
        quadTo(176f, 144f, 180f, 150f)
        quadTo(184f, 156f, 188f, 150f)
        quadTo(192f, 144f, 196f, 150f)
    }
    private val errorLeftEyePath = Path().apply {
        moveTo(154f, 110f)
        lineTo(170f, 120f)
        lineTo(154f, 130f)
    }
    private val errorRightEyePath = Path().apply {
        moveTo(226f, 110f)
        lineTo(210f, 120f)
        lineTo(226f, 130f)
    }
    private val happyLeftEyePath = Path()
    private val happyRightEyePath = Path()
    private val sleepLeftEyePath = Path()
    private val sleepRightEyePath = Path()
    private val smirkPath = Path()
    private val frownPath = Path().apply {
        moveTo(178f, 153f)
        quadTo(190f, 146f, 202f, 153f)
    }
    private val boltPath = Path().apply {
        moveTo(4f, 0f); lineTo(0f, 9f); lineTo(4f, 9f); lineTo(2f, 17f)
        lineTo(10f, 6f); lineTo(6f, 6f); lineTo(9f, 0f); close()
    }
    private val mouthRect = RectF()
    private val zPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }

    private var isLoopRunning = false
    private var moodStartRealtimeMs = SystemClock.elapsedRealtime()
    private var currentTiltDeg = 0f

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        updateAnimationRunningState()
    }

    override fun onDetachedFromWindow() {
        stopAnimationLoop()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        updateAnimationRunningState()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        updateAnimationRunningState()
    }

    private fun updateAnimationRunningState() {
        val shouldRun = isAttachedToWindow && windowVisibility == VISIBLE && isShown
        if (shouldRun && !isLoopRunning) {
            isLoopRunning = true
            Choreographer.getInstance().postFrameCallback(this)
        } else if (!shouldRun && isLoopRunning) {
            stopAnimationLoop()
        }
    }

    private fun stopAnimationLoop() {
        if (isLoopRunning) {
            isLoopRunning = false
            Choreographer.getInstance().removeFrameCallback(this)
        }
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!isLoopRunning || !isShown) {
            isLoopRunning = false
            return
        }
        tick(SystemClock.elapsedRealtime())

        // Глубокий сон — анимируем вполсилы (экономим батарею и GPU старого телефона)
        val deepSleep = sleepAmt > 0.98f && mood == Mood.IDLE && wakeStartMs < 0L
        skipToggle = !skipToggle
        if (!(deepSleep && skipToggle)) invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawEchoToCanvas(canvas, width.toFloat(), height.toFloat())
    }

    /**
     * Универсальная отрисовка маскота на любой Canvas (используется и в EchoView, и внутри капли EchoSiriOrbView).
     */
    fun drawEchoToCanvas(canvas: Canvas, vw: Float, vh: Float, extraTopOffsetPx: Float = 0f) {
        if (vw <= 2f || vh <= 2f) return

        val vpLeft = if (showRings) 52f else 84f
        val vpTop = if (showRings) 10f else 14f
        val vpWidth = if (showRings) 276f else 212f
        val vpHeight = if (showRings) 190f else 184f

        val scale = min(vw / vpWidth, vh / vpHeight)
        val offsetX = (vw - vpWidth * scale) * 0.5f - vpLeft * scale
        val offsetY = (vh - vpHeight * scale) * 0.5f - vpTop * scale + extraTopOffsetPx

        val nowMs = SystemClock.elapsedRealtime()
        val elapsedMoodSec = (nowMs - moodStartRealtimeMs) / 1000f
        val totalSec = (nowMs % 3600_000L) / 1000f

        val baseColor = if (mood == Mood.ERROR) errorColor else accentColor
        // Ночью в покое Эхо слегка приглушён, как ночник
        val activeColor = if (nightDim > 0.01f) {
            ColorUtils.setAlphaComponent(baseColor, 255 - (100f * nightDim).toInt())
        } else baseColor
        val giggling = mood == Mood.IDLE && nowMs < giggleUntilMs
        val faceMood = if (giggling) Mood.HAPPY else mood
        val mainStrokeUnits = max(4.5f, (2.0f * density) / scale)
        val mouthStrokeUnits = max(3.5f, (1.6f * density) / scale)
        val ringStrokeUnits = max(2.5f, (1.3f * density) / scale)

        canvas.save()
        canvas.translate(offsetX, offsetY)
        canvas.scale(scale, scale)

        // 1. Кольца эха (вокруг центра корпуса 190, 126)
        if (showRings && (mood == Mood.LISTENING || mood == Mood.SPEAKING)) {
            val periodSec = 2.1f
            val delays = floatArrayOf(0f, 0.7f, 1.4f)
            strokePaint.strokeWidth = ringStrokeUnits
            for (d in delays) {
                val t = elapsedMoodSec - d
                if (t < 0f) continue
                val phase = (t % periodSec) / periodSec
                val ringScale: Float
                val ringAlpha: Float
                if (mood == Mood.LISTENING) {
                    val easeIn = phase * phase
                    ringScale = 1.50f - (1.50f - 1.02f) * easeIn
                    ringAlpha = if (phase < 0.35f) {
                        (phase / 0.35f) * 0.50f
                    } else {
                        ((1f - phase) / 0.65f) * 0.50f
                    }
                } else {
                    val easeOut = 1f - (1f - phase) * (1f - phase)
                    ringScale = 1.02f + (1.50f - 1.02f) * easeOut
                    ringAlpha = 0.55f * (1f - easeOut)
                }
                val alphaInt = (ringAlpha * 255f).toInt().coerceIn(0, 255)
                if (alphaInt > 4) {
                    strokePaint.color = ColorUtils.setAlphaComponent(activeColor, alphaInt)
                    canvas.save()
                    canvas.scale(ringScale, ringScale, 190f, 126f)
                    ringRect.set(bodyRect)
                    canvas.drawRoundRect(ringRect, 58f, 58f, strokePaint)
                    canvas.restore()
                }
            }
        }

        // 2. Трансформация корпуса
        var bodyScale = 1.0f
        var shakeDx = 0f
        var bodyDy = wakeDy + 2.2f * sleepAmt + actDy + pokeDy

        when (mood) {
            Mood.IDLE, Mood.HAPPY -> {
                val amp = 0.016f + 0.010f * restAmt
                bodyScale = 1.0f + amp * (1f - cos(breathPhase))
                bodyDy += 0.8f * sin(breathPhase)
                if (mood == Mood.HAPPY) {
                    bodyDy -= abs(sin(elapsedMoodSec * 9.5f)) * 3.4f * exp(-elapsedMoodSec * 1.1f)
                }
                if (giggling) {
                    bodyDy -= abs(sin((giggleUntilMs - nowMs) * 0.014f)) * 2.6f
                }
            }
            Mood.SPEAKING -> {
                bodyScale = 1.0f + 0.06f * level
            }
            Mood.ERROR -> {
                if (elapsedMoodSec < 1.2f) {
                    shakeDx = 5.5f * sin(elapsedMoodSec * 4.5f * PIF)
                }
            }
            else -> {}
        }

        canvas.save()
        if (shakeDx != 0f || bodyDy != 0f) {
            canvas.translate(shakeDx, bodyDy)
        }
        if (currentTiltDeg != 0f) {
            canvas.rotate(currentTiltDeg, 190f, 126f)
        }
        val sxAll = bodyScale * wakeSX * (1f - 0.04f * actStretch)
        val syAll = bodyScale * wakeSY * (1f + 0.08f * actStretch)
        val cupLift = wakeCupLift + 4f * actStretch
        if (sxAll != 1.0f || syAll != 1.0f) {
            canvas.scale(sxAll, syAll, 190f, 126f)
        }

        // 2.1. Дужка наушников
        strokePaint.color = activeColor
        strokePaint.strokeWidth = mainStrokeUnits
        canvas.drawPath(headbandPath, strokePaint)

        // 2.2. Амбушюры (при потягивании «подпрыгивают»)
        val cupScale = if (mood == Mood.LISTENING) (1.0f + 0.40f * level) else 1.0f
        fillPaint.color = bodyFillColor
        strokePaint.color = activeColor
        strokePaint.strokeWidth = mainStrokeUnits

        canvas.save()
        if (cupLift != 0f) canvas.translate(0f, -cupLift)
        if (cupScale != 1.0f) canvas.scale(cupScale, cupScale, 105f, 126f)
        canvas.drawRoundRect(leftCupRect, 11f, 11f, fillPaint)
        canvas.drawRoundRect(leftCupRect, 11f, 11f, strokePaint)
        canvas.restore()

        canvas.save()
        if (cupLift != 0f) canvas.translate(0f, -cupLift)
        if (cupScale != 1.0f) canvas.scale(cupScale, cupScale, 275f, 126f)
        canvas.drawRoundRect(rightCupRect, 11f, 11f, fillPaint)
        canvas.drawRoundRect(rightCupRect, 11f, 11f, strokePaint)
        canvas.restore()

        // 2.3. Корпус
        fillPaint.color = bodyFillColor
        canvas.drawRoundRect(bodyRect, 58f, 58f, fillPaint)
        strokePaint.color = activeColor
        strokePaint.strokeWidth = mainStrokeUnits
        canvas.drawRoundRect(bodyRect, 58f, 58f, strokePaint)

        // 2.4. Щёчки (краснеют при ухмылке/счастье)
        val cheekAlpha = if (faceMood == Mood.HAPPY) 96 else (56 + (40f * smirkAmt).toInt())
        fillPaint.color = ColorUtils.setAlphaComponent(activeColor, cheekAlpha)
        canvas.drawCircle(146f, 142f, 6.2f, fillPaint)
        canvas.drawCircle(234f, 142f, 6.2f, fillPaint)

        // 2.5. Глаза
        val lx = 162f + currentEyeOffsetX
        val rx = 218f + currentEyeOffsetX
        val ey = 120f + currentEyeOffsetY

        when (faceMood) {
            Mood.ERROR -> {
                strokePaint.color = activeColor
                strokePaint.strokeWidth = max(5.0f, mainStrokeUnits)
                canvas.drawPath(errorLeftEyePath, strokePaint)
                canvas.drawPath(errorRightEyePath, strokePaint)
            }
            Mood.HAPPY -> {
                strokePaint.color = activeColor
                strokePaint.strokeWidth = max(4.5f, mainStrokeUnits)
                happyLeftEyePath.reset()
                happyLeftEyePath.moveTo(lx - 8.5f, ey + 3f)
                happyLeftEyePath.quadTo(lx, ey - 9.5f, lx + 8.5f, ey + 3f)
                happyRightEyePath.reset()
                happyRightEyePath.moveTo(rx - 8.5f, ey + 3f)
                happyRightEyePath.quadTo(rx, ey - 9.5f, rx + 8.5f, ey + 3f)
                canvas.drawPath(happyLeftEyePath, strokePaint)
                canvas.drawPath(happyRightEyePath, strokePaint)
            }
            else -> {
                val closedArc = lid > 0.88f && (sleepAmt > 0.5f || wakeStartMs >= 0L)
                if (closedArc) {
                    // Спящие закрытые глаза «‿»
                    strokePaint.color = activeColor
                    strokePaint.strokeWidth = max(4.5f, mainStrokeUnits)
                    sleepLeftEyePath.reset()
                    sleepLeftEyePath.moveTo(lx - 8.5f, ey + 1f)
                    sleepLeftEyePath.quadTo(lx, ey + 8f, lx + 8.5f, ey + 1f)
                    sleepRightEyePath.reset()
                    sleepRightEyePath.moveTo(rx - 8.5f, ey + 1f)
                    sleepRightEyePath.quadTo(rx, ey + 8f, rx + 8.5f, ey + 1f)
                    canvas.drawPath(sleepLeftEyePath, strokePaint)
                    canvas.drawPath(sleepRightEyePath, strokePaint)
                } else {
                    val moodSX = if (mood == Mood.LISTENING) 1.18f else 1.0f
                    val moodSY = when (mood) {
                        Mood.SPEAKING -> 0.85f
                        Mood.LISTENING -> 1.18f
                        else -> 1.0f
                    }
                    val popK = if (mood == Mood.LISTENING) 1f + 0.20f * exp(-elapsedMoodSec * 8f) else 1f
                    val sx = moodSX * wakePop * actPop * reactPop * popK
                    val sy = moodSY * wakePop * actPop * reactPop * popK
                    val lidR = max(lid, winkRight)
                    val hl = if (mood == Mood.LISTENING) 3.0f else 2.5f
                    drawEye(canvas, lx, ey, sx, sy * (1f - 0.92f * lid), activeColor, 1f - lid, hl)
                    drawEye(canvas, rx, ey, sx, sy * (1f - 0.92f * lidR), activeColor, 1f - lidR, hl)
                }
            }
        }

        // 2.6. Рот
        strokePaint.color = activeColor
        strokePaint.strokeWidth = mouthStrokeUnits
        when (faceMood) {
            Mood.HAPPY -> canvas.drawPath(happySmilePath, strokePaint)
            Mood.THINKING -> canvas.drawPath(thinkingMouthPath, strokePaint)
            Mood.ERROR -> canvas.drawPath(errorMouthPath, strokePaint)
            Mood.SPEAKING -> {
                // Рот «говорит» в такт голосу
                drawMouthOval(canvas, 8f, 150f, 3f + level * 11f, activeColor)
            }
            Mood.LISTENING -> {
                // Внимательное маленькое «о»
                drawMouthOval(canvas, 3f + 2.2f * level, 150f, 5f + 5f * level, activeColor)
            }
            Mood.IDLE -> {
                val yawn = max(wakeYawn, actYawn)
                when {
                    yawn > 0.02f -> drawMouthOval(canvas, 6f + 4f * yawn, 151f, 3f + 12f * yawn, activeColor)
                    faceO > 0.05f -> drawMouthOval(canvas, 3f + 2f * faceO, 150f, 3f + 8f * faceO, activeColor)
                    sleepAmt > 0.5f -> {
                        val br = 0.5f * (1f - cos(breathPhase))
                        drawMouthOval(canvas, 3f, 150f, 2.2f + 2.2f * br, activeColor)
                    }
                    smirkAmt > 0.01f -> {
                        val a = smirkAmt
                        smirkPath.reset()
                        smirkPath.moveTo(178f, 147f + a)
                        smirkPath.quadTo(190f + a, 156f - a, 202f + 4f * a, 147f - 6f * a)
                        canvas.drawPath(smirkPath, strokePaint)
                    }
                    lowBattery -> canvas.drawPath(frownPath, strokePaint)
                    else -> canvas.drawPath(smilePath, strokePaint)
                }
            }
        }

        canvas.restore()

        // 2.7. Спящий Эхо: всплывающие «z z Z»
        if (sleepAmt > 0.05f) {
            zPaint.color = activeColor
            for (i in 0..2) {
                val ph = (totalSec * 0.45f + i * 0.33f) % 1f
                val alpha = sin(PIF * ph) * sleepAmt * 0.85f
                val ai = (alpha * 255f).toInt().coerceIn(0, 255)
                if (ai > 6) {
                    zPaint.alpha = ai
                    zPaint.textSize = 11f + ph * 11f
                    canvas.drawText(if (i == 1) "Z" else "z", 238f + ph * 30f, 66f - ph * 44f, zPaint)
                }
            }
        }

        // 2.8. Идёт зарядка — над ухом мигает молния
        if (charging && mood == Mood.IDLE) {
            val pulse = 0.55f + 0.45f * sin(totalSec * 3.2f)
            fillPaint.color = ColorUtils.setAlphaComponent(activeColor, (pulse * 210f).toInt().coerceIn(0, 255))
            canvas.save()
            canvas.translate(92f, 34f)
            canvas.drawPath(boltPath, fillPaint)
            canvas.restore()
        }

        // 3. Три точки размышления над головой
        if (mood == Mood.THINKING) {
            val dotXs = floatArrayOf(172f, 190f, 208f)
            val period = 1.2f
            for (i in 0..2) {
                val localT = ((elapsedMoodSec - i * 0.2f).coerceAtLeast(0f)) % period
                val norm = localT / period
                val wave = 0.5f * (1f - cos((2.0 * PI * norm).toFloat()))
                val alpha = 0.25f + 0.75f * wave
                fillPaint.color = ColorUtils.setAlphaComponent(activeColor, (alpha * 255f).toInt().coerceIn(64, 255))
                canvas.drawCircle(dotXs[i], 16f, 5f, fillPaint)
            }
        }

        canvas.restore()
    }

    private fun drawEye(
        canvas: Canvas, cx: Float, cy: Float, sx: Float, sy: Float,
        color: Int, openness: Float, highlightR: Float
    ) {
        fillPaint.color = color
        canvas.save()
        canvas.scale(sx, sy, cx, cy)
        canvas.drawCircle(cx, cy, 8.5f, fillPaint)
        canvas.restore()
        if (openness > 0.45f) {
            val a = ((openness - 0.45f) / 0.55f).coerceIn(0f, 1f)
            fillPaint.color = Color.argb((200f * a).toInt(), 255, 255, 255)
            canvas.drawCircle(cx - 2.8f * sx, cy - 3.0f * sy, highlightR, fillPaint)
        }
    }

    private fun drawMouthOval(canvas: Canvas, halfW: Float, cy: Float, h: Float, color: Int) {
        mouthRect.set(190f - halfW, cy - h * 0.5f, 190f + halfW, cy + h * 0.5f)
        fillPaint.color = ColorUtils.setAlphaComponent(color, 70)
        canvas.drawOval(mouthRect, fillPaint)
        canvas.drawOval(mouthRect, strokePaint)
    }
}
