package com.smartconsole.touch.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import com.smartconsole.touch.network.MiTvController
import com.smartconsole.touch.network.TuyaController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.util.Locale

class VoiceAssistantEngine(
    private val context: Context,
    private val scope: CoroutineScope,
    private val miTvController: MiTvController,
    private val tuyaController: TuyaController,
    private val onVoiceActivityChanged: (Boolean) -> Unit,
    private val onLocalPresetChanged: (TuyaController.LightPreset) -> Unit,
    private val onLocalStripPowerChanged: (Boolean) -> Unit
) : TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isListening = false
    private var isDestroyed = false
    private val mainHandler = Handler(Looper.getMainLooper())

    private val recognizerIntent: Intent by lazy {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
    }

    fun start() {
        if (isDestroyed) return
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
        initSpeechRecognizer()
        startListeningLoop()
    }

    fun stop() {
        isDestroyed = true
        isListening = false
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.destroy()
        speechRecognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ru", "RU")
        }
    }

    private fun initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}

                    override fun onBeginningOfSpeech() {
                        onVoiceActivityChanged(true)
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        if (rmsdB > 4.5f) {
                            onVoiceActivityChanged(true)
                        }
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        onVoiceActivityChanged(false)
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        onVoiceActivityChanged(false)
                        scheduleRestart(1000L)
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        onVoiceActivityChanged(false)
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spokenText = matches?.firstOrNull()?.trim().orEmpty()
                        if (spokenText.isNotEmpty()) {
                            handleRecognizedCommand(spokenText)
                        }
                        scheduleRestart(400L)
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            .orEmpty()
                        if (partial.isNotBlank()) {
                            onVoiceActivityChanged(true)
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        } catch (_: Exception) {
            speechRecognizer = null
        }
    }

    private fun startListeningLoop() {
        if (isDestroyed || isListening || speechRecognizer == null) return
        try {
            isListening = true
            speechRecognizer?.startListening(recognizerIntent)
        } catch (_: Exception) {
            isListening = false
            scheduleRestart(1500L)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (isDestroyed || speechRecognizer == null) return
        mainHandler.postDelayed({ startListeningLoop() }, delayMs)
    }

    fun handleRecognizedCommand(spokenText: String) {
        val tvStatus = miTvController.lastKnownStatus
        val lower = spokenText.lowercase(Locale("ru", "RU"))

        if (tvStatus.isReachable && tvStatus.isInteractive) {
            scope.launch {
                miTvController.forwardVoiceCommandToTv(spokenText)
            }
        } else {
            scope.launch {
                when {
                    lower.contains("выключи свет") || lower.contains("выключи ленту") -> {
                        tuyaController.setPower(tuyaController.stripDeviceId, false)
                        onLocalStripPowerChanged(false)
                        speak("Подсветка выключена")
                    }
                    lower.contains("включи свет") || lower.contains("включи ленту") || lower.contains("подсветк") -> {
                        tuyaController.setPower(tuyaController.stripDeviceId, true)
                        onLocalStripPowerChanged(true)
                        speak("Включаю подсветку")
                    }
                    lower.contains("тёпл") || lower.contains("тепл") -> {
                        tuyaController.applyPreset(tuyaController.stripDeviceId, TuyaController.LightPreset.WARM)
                        onLocalPresetChanged(TuyaController.LightPreset.WARM)
                        speak("Тёплый свет включён")
                    }
                    lower.contains("кибер") -> {
                        tuyaController.applyPreset(tuyaController.stripDeviceId, TuyaController.LightPreset.CYBER)
                        onLocalPresetChanged(TuyaController.LightPreset.CYBER)
                        speak("Режим кибер активирован")
                    }
                    lower.contains("сапфир") || lower.contains("синий") -> {
                        tuyaController.applyPreset(tuyaController.stripDeviceId, TuyaController.LightPreset.SAPPHIRE)
                        onLocalPresetChanged(TuyaController.LightPreset.SAPPHIRE)
                        speak("Включён сапфировый цвет")
                    }
                    lower.contains("фиолет") -> {
                        tuyaController.applyPreset(tuyaController.stripDeviceId, TuyaController.LightPreset.VIOLET)
                        onLocalPresetChanged(TuyaController.LightPreset.VIOLET)
                        speak("Включён фиолетовый цвет")
                    }
                    lower.contains("малин") || lower.contains("розов") -> {
                        tuyaController.applyPreset(tuyaController.stripDeviceId, TuyaController.LightPreset.RASPBERRY)
                        onLocalPresetChanged(TuyaController.LightPreset.RASPBERRY)
                        speak("Включён малиновый цвет")
                    }
                    lower.contains("закат") || lower.contains("оранж") -> {
                        tuyaController.applyPreset(tuyaController.stripDeviceId, TuyaController.LightPreset.SUNSET)
                        onLocalPresetChanged(TuyaController.LightPreset.SUNSET)
                        speak("Режим заката включён")
                    }
                    lower.contains("youtube") || lower.contains("ютуб") -> {
                        miTvController.launchApp(MiTvController.TvApp.YOUTUBE)
                        speak("Запускаю YouTube на телевизоре")
                    }
                }
            }
        }
    }

    private fun speak(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "console_tts")
    }
}
