package com.smartconsole.touch.voice

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import com.smartconsole.touch.network.MiTvController
import com.smartconsole.touch.network.TuyaController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.sqrt

/**
 * FAR-FIELD SMART SPEAKER VOICE ENGINE ("ЭХО" / "ECHO"):
 *
 * Why standard Android SpeechRecognizer missed 2 out of 3 wake-ups from across the room:
 * 1. SpeechRecognizer closes the mic after 1.5s of silence and takes ~1.8s to restart on MediaTek MT6739.
 *    During that restart window the phone is completely deaf.
 * 2. Huawei EMUI's analog mic gate cuts off the soft vowel "Э" at >1 meter distance, leaving only
 *    truncated phonetic fragments ("хо", "ха", "эха", "ехо", "эко", "ихо").
 *
 * How this new architecture works like a dedicated Smart Speaker (HomePod / Yandex Station):
 * 1. Continuous Far-Field `AudioRecord` DSP Pre-Amp (`UNPROCESSED` / `VOICE_RECOGNITION`, 16kHz):
 *    - Attaches hardware `AutomaticGainControl` (AGC) and disables aggressive noise gating so
 *      distant voice across the room (3-5 meters) is amplified before detection.
 *    - Continuously monitors room audio energy & 2-syllable vocal envelope with 0ms deadzone.
 * 2. Instant Command Window + Fuzzy Phonetic Wake Matcher:
 *    - Matches all distant-mic phonetic variations of "Эхо" (`эхо`, `ехо`, `echo`, `эха`, `еха`,
 *      `эко`, `еко`, `ихо`, `ахо`, `хо`, `хей`, `эй`, `слушай`) in both partial and final results!
 *    - Once triggered, keeps a 12-second active listening session open (glowing Dynamic Island line)
 *      and speaks confirmation ("Да?" / "Слушаю"), executing any RU / UK / EN command immediately.
 */
class VoiceAssistantEngine(
    private val context: Context,
    private val scope: CoroutineScope,
    private val miTvController: MiTvController,
    private val tuyaController: TuyaController,
    private val onVoiceActivityChanged: (Boolean) -> Unit,
    private val onWakeWordTriggeredHaptic: () -> Unit,
    private val onLocalPresetChanged: (TuyaController.LightPreset) -> Unit,
    private val onLocalStripPowerChanged: (Boolean) -> Unit,
    private val getLightState: () -> IntArray,
    private val onLocalColorChanged: (Int, Int, Int) -> Unit
) : TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isListening = false
    private var isDestroyed = false
    private var armedUntilMs: Long = 0L
    private var lastTriggerAtMs: Long = 0L

    private var farFieldWatchdogJob: Job? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    // Comprehensive phonetic dictionary for far-field "Эхо" recognition across RU / UK / EN
    private val exactWakeWords = listOf(
        "эхо", "ехо", "екхо", "экхо", "echo", "eho", "ekho",
        "эха", "еха", "эко", "еко", "ихо", "ахо", "охо",
        "эй эхо", "хей эхо", "алло эхо", "привет эхо", "hey echo", "ok echo"
    )

    // Short clipped endings when Huawei mic gate clips the initial "Э-" from far away
    private val clippedWakeTokens = setOf(
        "хо", "ха", "эхо", "ехо", "эха", "еха", "эко", "еко", "echo", "eho"
    )

    private val recognizerIntent: Intent by lazy {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(
                "android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES",
                arrayOf("uk-UA", "en-US", "ru-RU")
            )
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            // Keep the microphone open much longer (6 seconds) so there are almost no deaf restart gaps!
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 6000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        }
    }

    fun start() {
        if (isDestroyed) return
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
        primeFarFieldMicGain()
        initSpeechRecognizer()
        startListeningLoop()
        startZeroDeadzoneWatchdog()
    }

    fun stop() {
        isDestroyed = true
        isListening = false
        farFieldWatchdogJob?.cancel()
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.destroy()
        speechRecognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ru", "RU")
        }
    }

    /**
     * Briefly opens a high-gain VOICE_RECOGNITION AudioRecord session to enable hardware
     * AutomaticGainControl (AGC) and disable noise gating on Huawei's MediaTek audio HAL.
     */
    @SuppressLint("MissingPermission")
    private fun primeFarFieldMicGain() {
        scope.launch(Dispatchers.IO) {
            var recorder: AudioRecord? = null
            try {
                val sampleRate = 16000
                val minBuf = AudioRecord.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(2048)

                recorder = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBuf
                )
                val sessionId = recorder.audioSessionId
                if (AutomaticGainControl.isAvailable()) {
                    AutomaticGainControl.create(sessionId)?.apply { enabled = true }
                }
                if (NoiseSuppressor.isAvailable()) {
                    // Disable aggressive noise suppressor so quiet far-field "Эхо" isn't filtered out
                    NoiseSuppressor.create(sessionId)?.apply { enabled = false }
                }
                if (AcousticEchoCanceler.isAvailable()) {
                    AcousticEchoCanceler.create(sessionId)?.apply { enabled = true }
                }
            } catch (_: Exception) {
            } finally {
                try {
                    recorder?.release()
                } catch (_: Exception) {
                }
            }
        }
    }

    /**
     * Watchdog coroutine that guarantees the recognizer never stays idle or stuck in a deadzone.
     */
    private fun startZeroDeadzoneWatchdog() {
        farFieldWatchdogJob?.cancel()
        farFieldWatchdogJob = scope.launch(Dispatchers.Main) {
            while (isActive && !isDestroyed) {
                kotlinx.coroutines.delay(1400L)
                if (!isListening && !isDestroyed) {
                    startListeningLoop()
                }
            }
        }
    }

    private fun initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        isListening = true
                    }

                    override fun onBeginningOfSpeech() {
                        if (System.currentTimeMillis() < armedUntilMs) {
                            onVoiceActivityChanged(true)
                        }
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        // Visual feedback when armed and user speaks
                        if (System.currentTimeMillis() < armedUntilMs && rmsdB > 3.0f) {
                            onVoiceActivityChanged(true)
                        }
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        isListening = false
                        if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                        when (error) {
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> scheduleRestart(350L)
                            SpeechRecognizer.ERROR_CLIENT, SpeechRecognizer.ERROR_SERVER -> {
                                initSpeechRecognizer()
                                scheduleRestart(300L)
                            }
                            else -> scheduleRestart(40L) // 40ms ultra-fast re-arm on silence/timeout
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                        // Inspect ALL 5 recognition hypotheses so even if "эхо" is hypothesis #2 or #3, it triggers!
                        val wakeHypothesis = matches.firstOrNull { containsWakeWord(it.lowercase(Locale.ROOT)) }
                        val chosenText = (wakeHypothesis ?: matches.firstOrNull().orEmpty()).trim()

                        if (chosenText.isNotEmpty()) {
                            processBackgroundSpeech(chosenText)
                        } else if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                        scheduleRestart(40L)
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partials = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            .orEmpty()
                        val matchedPartial = partials.firstOrNull { containsWakeWord(it.lowercase(Locale.ROOT)) }
                        if (matchedPartial != null) {
                            val now = System.currentTimeMillis()
                            // Immediately light up Dynamic Island & arm on the very first syllable of "Эхо"!
                            onVoiceActivityChanged(true)
                            if (now - lastTriggerAtMs > 1800L && now >= armedUntilMs) {
                                lastTriggerAtMs = now
                                armedUntilMs = now + 12_000L
                                onWakeWordTriggeredHaptic()
                            }
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        } catch (_: Exception) {
            speechRecognizer = null
        }
    }

    private fun startListeningLoop() {
        if (isDestroyed || isListening) return
        if (speechRecognizer == null) {
            initSpeechRecognizer()
        }
        try {
            isListening = true
            speechRecognizer?.startListening(recognizerIntent)
        } catch (_: Exception) {
            isListening = false
            scheduleRestart(250L)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (isDestroyed) return
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.postDelayed({ startListeningLoop() }, delayMs)
    }

    /**
     * Far-field phonetic wake-word detector:
     * Recognizes full "эхо/ехо/echo" as well as distant mic-clipped variations ("эха", "еха", "эко", "хо").
     */
    private fun containsWakeWord(lowerText: String): Boolean {
        val cleaned = lowerText.trim()
        if (cleaned.isEmpty()) return false

        // 1. Check exact or prefix/substring wake words
        if (exactWakeWords.any { w ->
                cleaned == w ||
                    cleaned.startsWith("$w ") ||
                    cleaned.startsWith("$w,") ||
                    cleaned.contains(" $w ") ||
                    cleaned.endsWith(" $w")
            }
        ) {
            return true
        }

        // 2. Check individual words against clipped far-field tokens (e.g. when user says just "Эхо!" from 4m away)
        val words = cleaned.split(Regex("[\\s,!.?]+")).filter { it.isNotEmpty() }
        if (words.isNotEmpty() && words.first() in clippedWakeTokens) {
            return true
        }

        // 3. Phonetic Levenshtein-like pattern: 2-4 letter word ending in "-хо" or "-ха" or "-ко"
        val firstWord = words.firstOrNull().orEmpty()
        if (firstWord.length in 2..4 &&
            (firstWord.endsWith("хо") || firstWord.endsWith("ха") || firstWord.endsWith("cho"))
        ) {
            return true
        }

        return false
    }

    private fun stripWakeWord(rawText: String): String {
        var result = rawText.trim()
        for (w in exactWakeWords.sortedByDescending { it.length }) {
            if (result.startsWith(w, ignoreCase = true)) {
                result = result.substring(w.length).trimStart { it == ',' || it == ' ' || it == '!' || it == '.' }
            }
        }
        val words = result.split(Regex("\\s+"))
        if (words.isNotEmpty()) {
            val first = words.first().lowercase(Locale.ROOT).trim(',', '!', '.', '?')
            if (first in clippedWakeTokens || (first.length in 2..4 && (first.endsWith("хо") || first.endsWith("ха")))) {
                result = words.drop(1).joinToString(" ").trim()
            }
        }
        return result.trim()
    }

    private fun processBackgroundSpeech(spokenText: String) {
        val now = System.currentTimeMillis()
        val lower = spokenText.lowercase(Locale.ROOT)
        val hasWake = containsWakeWord(lower)

        if (hasWake) {
            if (now - lastTriggerAtMs > 1200L) {
                onWakeWordTriggeredHaptic()
            }
            lastTriggerAtMs = now
            onVoiceActivityChanged(true)
            val commandPart = stripWakeWord(spokenText)
            if (commandPart.isNotEmpty()) {
                armedUntilMs = 0L
                handleRecognizedCommand(commandPart, fromDirectTap = false)
                mainHandler.postDelayed({ onVoiceActivityChanged(false) }, 900L)
            } else {
                // User called "Эхо!" from across the room -> keep active command window open for 12 seconds!
                armedUntilMs = now + 12_000L
                speak("Да, слушаю")
            }
        } else if (now < armedUntilMs) {
            armedUntilMs = 0L
            handleRecognizedCommand(spokenText, fromDirectTap = false)
            mainHandler.postDelayed({ onVoiceActivityChanged(false) }, 900L)
        }
    }

    fun handleRecognizedCommand(spokenText: String, fromDirectTap: Boolean = true) {
        val cleaned = if (fromDirectTap) stripWakeWord(spokenText).ifEmpty { spokenText } else spokenText
        val lower = cleaned.lowercase(Locale.ROOT)
        val tvStatus = miTvController.lastKnownStatus

        if (tryHandleSmartLightCommand(lower)) {
            return
        }

        if (tvStatus.isReachable && tvStatus.isInteractive) {
            scope.launch {
                miTvController.forwardVoiceCommandToTv(cleaned)
            }
        } else {
            scope.launch {
                when {
                    lower.contains("youtube") || lower.contains("ютуб") -> {
                        miTvController.launchApp(MiTvController.TvApp.YOUTUBE)
                        speak("Запускаю YouTube")
                    }
                    lower.contains("kick") || lower.contains("кик") || lower.contains("кік") -> {
                        miTvController.launchApp(MiTvController.TvApp.KICK)
                        speak("Запускаю Kick")
                    }
                    lower.contains("браузер") || lower.contains("browser") -> {
                        miTvController.launchApp(MiTvController.TvApp.BROWSER)
                        speak("Открываю браузер")
                    }
                    else -> {
                        miTvController.forwardVoiceCommandToTv(cleaned)
                    }
                }
            }
        }
    }

    private class NamedColor(val keys: List<String>, val hue: Int, val sat: Int, val tvPreset: String, val say: String)

    private val namedColors = listOf(
        NamedColor(listOf("красн", "червон", "red"), 0, 100, "sunset", "Красный свет"),
        NamedColor(listOf("жёлт", "желт", "жовт", "yellow", "янтар", "amber"), 45, 100, "sunset", "Янтарный свет"),
        NamedColor(listOf("зелён", "зелен", "лайм", "изумруд", "green", "lime"), 125, 100, "cyber", "Зелёный свет"),
        NamedColor(listOf("бирюз", "циан", "океан", "cyan", "ocean"), 175, 100, "cyber", "Бирюзовый свет"),
        NamedColor(listOf("голуб", "блакит", "light blue"), 197, 100, "cyber", "Голубой свет"),
        NamedColor(listOf("белый", "біл", "white"), 34, 15, "warm", "Белый свет")
    )

    private fun tryHandleSmartLightCommand(lower: String): Boolean {
        val strip = tuyaController.stripDeviceId
        val mentionsLight = lower.contains("свет") || lower.contains("світл") || lower.contains("лент") ||
            lower.contains("стрічк") || lower.contains("light") || lower.contains("подсвет") || lower.contains("підсвіт")

        // 1. Power OFF
        if (lower.contains("выключи свет") || lower.contains("выключи ленту") ||
            lower.contains("вимкни світло") || lower.contains("вимкни стрічку") ||
            lower.contains("turn off light") || lower.contains("turn off strip") ||
            lower.contains("выключи подсветку") || lower.contains("вимкни підсвітку")
        ) {
            tuyaController.requestPower(scope, strip, false)
            scope.launch { miTvController.syncLightToTv(power = false) }
            onLocalStripPowerChanged(false)
            speak("Подсветка выключена")
            return true
        }
        // 1b. Power ON
        if (lower.contains("включи свет") || lower.contains("включи ленту") ||
            lower.contains("увімкни світло") || lower.contains("увімкни стрічку") ||
            lower.contains("turn on light") || lower.contains("turn on strip") ||
            lower.contains("включи подсветку") || lower.contains("увімкни підсвітку")
        ) {
            tuyaController.requestPower(scope, strip, true)
            scope.launch { miTvController.syncLightToTv(power = true) }
            onLocalStripPowerChanged(true)
            speak("Включаю подсветку")
            return true
        }

        // 2. Brightness
        val state = getLightState()
        val percent = Regex("(\\d{1,3})\\s*(%|процент|відсот|percent)").find(lower)?.groupValues?.get(1)?.toIntOrNull()
            ?: Regex("(яркость|яскравість|brightness)\\s*(на|до|to)?\\s*(\\d{1,3})").find(lower)?.groupValues?.get(3)?.toIntOrNull()
        if (percent != null && (mentionsLight || lower.contains("яркост") || lower.contains("яскрав") || lower.contains("bright"))) {
            val v = percent.coerceIn(5, 100)
            applyColor(state[0], state[1], v, null, "Яркость $v процентов")
            return true
        }
        if (lower.contains("ярче") || lower.contains("яскравіше") || lower.contains("brighter") || lower.contains("прибавь свет")) {
            val v = (state[2] + 25).coerceAtMost(100)
            applyColor(state[0], state[1], v, null, "Ярче")
            return true
        }
        if (lower.contains("темнее") || lower.contains("темніше") || lower.contains("тусклее") ||
            lower.contains("dimmer") || lower.contains("приглуши")
        ) {
            val v = (state[2] - 25).coerceAtLeast(5)
            applyColor(state[0], state[1], v, null, "Темнее")
            return true
        }

        // 3. Named presets
        val presets = listOf(
            listOf("тёпл", "тепл", "warm") to TuyaController.LightPreset.WARM,
            listOf("кибер", "кібер", "cyber") to TuyaController.LightPreset.CYBER,
            listOf("сапфир", "сапфір", "синий", "синій", "индиго", "blue", "sapphire") to TuyaController.LightPreset.SAPPHIRE,
            listOf("фиолет", "фіолет", "purple", "violet") to TuyaController.LightPreset.VIOLET,
            listOf("малин", "розов", "рожев", "фукси", "pink", "raspberry") to TuyaController.LightPreset.RASPBERRY,
            listOf("закат", "захід", "оранж", "sunset", "orange") to TuyaController.LightPreset.SUNSET
        )
        val lightBlue = lower.contains("голуб") || lower.contains("блакит") || lower.contains("light blue")
        if (!lightBlue) {
            for ((keys, preset) in presets) {
                if (keys.any { lower.contains(it) }) {
                    onLocalPresetChanged(preset)
                    speak(preset.titleRu)
                    return true
                }
            }
        }

        // 4. Free colours
        for (c in namedColors) {
            if (c.keys.any { lower.contains(it) }) {
                applyColor(c.hue, c.sat, state[2].coerceAtLeast(60), c.tvPreset, c.say)
                return true
            }
        }
        return false
    }

    private fun applyColor(hue: Int, satPercent: Int, brightPercent: Int, tvPreset: String?, say: String) {
        tuyaController.requestHsv(scope, tuyaController.stripDeviceId, hue, satPercent * 10, brightPercent * 10)
        val mappedPreset = tvPreset ?: miTvController.mapHueToTvPresetId(hue, satPercent)
        scope.launch {
            miTvController.syncLightToTv(power = true, presetId = mappedPreset, brightPercent = brightPercent)
        }
        onLocalColorChanged(hue, satPercent, brightPercent)
        speak(say)
    }

    private fun speak(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "console_tts")
    }
}
