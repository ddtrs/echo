package com.smartconsole.touch.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import com.smartconsole.touch.network.MiTvController
import com.smartconsole.touch.network.TuyaController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Multi-Language Voice Engine with "Эхо" / "Echo" Hotword Wake-Up:
 * - Understands Russian, Ukrainian, and English commands seamlessly.
 * - In background mode, listens for the wake word "Эхо" / "Ехо" / "Echo":
 *   - Saying "Эхо, включи сапфировый свет" or "Эхо, открой YouTube" triggers immediately.
 *   - Saying just "Эхо" activates an 8-second active command window (glowing top neon line)
 *     so the next phrase is executed without needing to repeat "Эхо".
 * - When triggered manually via tap on the top neon line, executes the command directly.
 */
class VoiceAssistantEngine(
    private val context: Context,
    private val scope: CoroutineScope,
    private val miTvController: MiTvController,
    private val tuyaController: TuyaController,
    private val onVoiceActivityChanged: (Boolean) -> Unit,
    private val onWakeWordTriggeredHaptic: () -> Unit,
    private val onLocalPresetChanged: (TuyaController.LightPreset) -> Unit,
    private val onLocalStripPowerChanged: (Boolean) -> Unit
) : TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isListening = false
    private var isDestroyed = false
    private var armedUntilMs: Long = 0L
    private val mainHandler = Handler(Looper.getMainLooper())

    private val wakeWords = listOf("эхо", "ехо", "екхо", "echo", "eho")

    private val recognizerIntent: Intent by lazy {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            // Multi-language support: uses device default + understands RU / UK / EN
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
        }
    }

    fun start() {
        if (isDestroyed) return
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
        initSpeechRecognizer()
        startListeningLoop()
    }

    fun stop() {
        isDestroyed = true
        isListening = false
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.destroy()
        speechRecognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ru", "RU")
        }
    }

    private fun initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}

                    override fun onBeginningOfSpeech() {
                        if (System.currentTimeMillis() < armedUntilMs) {
                            onVoiceActivityChanged(true)
                        }
                    }

                    override fun onRmsChanged(rmsdB: Float) {}

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                        // Fast seamless restart so background listener never dies
                        val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200L else 450L
                        scheduleRestart(delay)
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spokenText = matches?.firstOrNull()?.trim().orEmpty()
                        if (spokenText.isNotEmpty()) {
                            processBackgroundSpeech(spokenText)
                        } else if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                        scheduleRestart(250L)
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            ?.lowercase(Locale.ROOT)
                            .orEmpty()
                        if (partial.isNotBlank() && containsWakeWord(partial)) {
                            onVoiceActivityChanged(true)
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        } catch (_: Exception) {
            speechRecognizer = null
        }
    }

    private fun startListeningLoop() {
        if (isDestroyed || isListening || speechRecognizer == null) return
        try {
            isListening = true
            speechRecognizer?.startListening(recognizerIntent)
        } catch (_: Exception) {
            isListening = false
            scheduleRestart(1000L)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (isDestroyed || speechRecognizer == null) return
        mainHandler.postDelayed({ startListeningLoop() }, delayMs)
    }

    private fun containsWakeWord(lowerText: String): Boolean {
        return wakeWords.any { w ->
            lowerText == w ||
                lowerText.startsWith("$w ") ||
                lowerText.startsWith("$w,") ||
                lowerText.contains(" $w ")
        }
    }

    private fun stripWakeWord(rawText: String): String {
        var result = rawText.trim()
        for (w in wakeWords) {
            val regex = Regex("(?i)^$w[,\\s]*")
            if (regex.containsMatchIn(result)) {
                result = result.replaceFirst(regex, "").trim()
            }
        }
        return result
    }

    private fun processBackgroundSpeech(spokenText: String) {
        val now = System.currentTimeMillis()
        val lower = spokenText.lowercase(Locale.ROOT)
        val hasWake = containsWakeWord(lower)

        if (hasWake) {
            onWakeWordTriggeredHaptic()
            onVoiceActivityChanged(true)
            val commandPart = stripWakeWord(spokenText)
            if (commandPart.isNotEmpty()) {
                armedUntilMs = 0L
                handleRecognizedCommand(commandPart, fromDirectTap = false)
                mainHandler.postDelayed({ onVoiceActivityChanged(false) }, 900L)
            } else {
                // User said just "Эхо!" -> arm active listening window for 8 seconds
                armedUntilMs = now + 8000L
                speak("Слушаю")
            }
        } else if (now < armedUntilMs) {
            // Already armed after "Эхо"
            armedUntilMs = 0L
            handleRecognizedCommand(spokenText, fromDirectTap = false)
            mainHandler.postDelayed({ onVoiceActivityChanged(false) }, 900L)
        }
    }

    /**
     * Executes a recognized voice command in RU, UA, or EN.
     */
    fun handleRecognizedCommand(spokenText: String, fromDirectTap: Boolean = true) {
        val cleaned = if (fromDirectTap) stripWakeWord(spokenText).ifEmpty { spokenText } else spokenText
        val lower = cleaned.lowercase(Locale.ROOT)
        val tvStatus = miTvController.lastKnownStatus

        // Check if command is explicitly a smart-light command first (works regardless of TV state)
        if (tryHandleSmartLightCommand(lower)) {
            return
        }

        if (tvStatus.isReachable && tvStatus.isInteractive) {
            scope.launch {
                miTvController.forwardVoiceCommandToTv(cleaned)
            }
        } else {
            scope.launch {
                when {
                    lower.contains("youtube") || lower.contains("ютуб") -> {
                        miTvController.launchApp(MiTvController.TvApp.YOUTUBE)
                        speak("Запускаю YouTube")
                    }
                    lower.contains("kick") || lower.contains("кик") || lower.contains("кік") -> {
                        miTvController.launchApp(MiTvController.TvApp.KICK)
                        speak("Запускаю Kick")
                    }
                    lower.contains("браузер") || lower.contains("browser") -> {
                        miTvController.launchApp(MiTvController.TvApp.BROWSER)
                        speak("Открываю браузер")
                    }
                    else -> {
                        miTvController.forwardVoiceCommandToTv(cleaned)
                    }
                }
            }
        }
    }

    private fun tryHandleSmartLightCommand(lower: String): Boolean {
        return when {
            lower.contains("выключи свет") || lower.contains("выключи ленту") ||
                lower.contains("вимкни світло") || lower.contains("turn off light") -> {
                scope.launch {
                    tuyaController.setPower(tuyaController.stripDeviceId, false)
                    onLocalStripPowerChanged(false)
                    speak("Подсветка выключена")
                }
                true
            }
            lower.contains("включи свет") || lower.contains("включи ленту") ||
                lower.contains("увімкни світло") || lower.contains("turn on light") -> {
                scope.launch {
                    tuyaController.setPower(tuyaController.stripDeviceId, true)
                    onLocalStripPowerChanged(true)
                    speak("Включаю подсветку")
                }
                true
            }
            lower.contains("тёпл") || lower.contains("тепл") || lower.contains("warm") -> {
                scope.launch {
                    tuyaController.applyPreset(tuyaController.stripDeviceId, TuyaController.LightPreset.WARM)
                    onLocalPresetChanged(TuyaController.LightPreset.WARM)
                    speak("Тёплый свет")
                }
                true
            }
            lower.contains("кибер") || lower.contains("кібер") || lower.contains("cyber") -> {
                scope.launch {
                    tuyaController.applyPreset(tuyaController.stripDeviceId, TuyaController.LightPreset.CYBER)
                    onLocalPresetChanged(TuyaController.LightPreset.CYBER)
                    speak("Режим кибер")
                }
                true
            }
            lower.contains("сапфир") || lower.contains("синий") || lower.contains("синій") || lower.contains("blue") -> {
                scope.launch {
                    tuyaController.applyPreset(tuyaController.stripDeviceId, TuyaController.LightPreset.SAPPHIRE)
                    onLocalPresetChanged(TuyaController.LightPreset.SAPPHIRE)
                    speak("Сапфировый свет")
                }
                true
            }
            lower.contains("фиолет") || lower.contains("фіолет") || lower.contains("purple") || lower.contains("violet") -> {
                scope.launch {
                    tuyaController.applyPreset(tuyaController.stripDeviceId, TuyaController.LightPreset.VIOLET)
                    onLocalPresetChanged(TuyaController.LightPreset.VIOLET)
                    speak("Фиолетовый свет")
                }
                true
            }
            lower.contains("малин") || lower.contains("розов") || lower.contains("рожев") || lower.contains("pink") -> {
                scope.launch {
                    tuyaController.applyPreset(tuyaController.stripDeviceId, TuyaController.LightPreset.RASPBERRY)
                    onLocalPresetChanged(TuyaController.LightPreset.RASPBERRY)
                    speak("Малиновый свет")
                }
                true
            }
            lower.contains("закат") || lower.contains("оранж") || lower.contains("sunset") || lower.contains("orange") -> {
                scope.launch {
                    tuyaController.applyPreset(tuyaController.stripDeviceId, TuyaController.LightPreset.SUNSET)
                    onLocalPresetChanged(TuyaController.LightPreset.SUNSET)
                    speak("Режим заката")
                }
                true
            }
            else -> false
        }
    }

    private fun speak(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "console_tts")
    }
}
