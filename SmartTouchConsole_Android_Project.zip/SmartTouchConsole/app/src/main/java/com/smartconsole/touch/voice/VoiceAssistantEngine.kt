package com.smartconsole.touch.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import com.smartconsole.touch.network.MiTvController
import com.smartconsole.touch.network.TuyaController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * High-Sensitivity Multi-Language Voice Engine (RU / UK / EN) with "Эхо" / "Ехо" / "Echo" Wake-Up:
 * - Configures `EXTRA_ADDITIONAL_LANGUAGES` (`uk-UA`, `ru-RU`, `en-US`) and `EXTRA_PREFER_OFFLINE = false`
 *   so Google Speech Services recognize Russian, Ukrainian, and English phrases accurately.
 * - Zero-Deadzone Listening Loop: immediately re-arms on silence (`ERROR_NO_MATCH` / `ERROR_SPEECH_TIMEOUT`)
 *   within 80ms so the wake word "Эхо" is never missed.
 * - Syncs all voice-triggered light changes to both Tuya Cloud AND the TV Launcher (`/light?...`).
 */
class VoiceAssistantEngine(
    private val context: Context,
    private val scope: CoroutineScope,
    private val miTvController: MiTvController,
    private val tuyaController: TuyaController,
    private val onVoiceActivityChanged: (Boolean) -> Unit,
    private val onWakeWordTriggeredHaptic: () -> Unit,
    private val onLocalPresetChanged: (TuyaController.LightPreset) -> Unit,
    private val onLocalStripPowerChanged: (Boolean) -> Unit,
    private val getLightState: () -> IntArray,
    private val onLocalColorChanged: (Int, Int, Int) -> Unit
) : TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isListening = false
    private var isDestroyed = false
    private var armedUntilMs: Long = 0L
    private val mainHandler = Handler(Looper.getMainLooper())

    private val wakeWords = listOf(
        "эхо", "ехо", "екхо", "echo", "eho", "экхо", "эй эхо", "хей эхо", "hey echo"
    )

    private val recognizerIntent: Intent by lazy {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(
                "android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES",
                arrayOf("uk-UA", "en-US", "ru-RU")
            )
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 2500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
        }
    }

    fun start() {
        if (isDestroyed) return
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
        initSpeechRecognizer()
        startListeningLoop()
    }

    fun stop() {
        isDestroyed = true
        isListening = false
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.destroy()
        speechRecognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ru", "RU")
        }
    }

    private fun initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}

                    override fun onBeginningOfSpeech() {
                        if (System.currentTimeMillis() < armedUntilMs) {
                            onVoiceActivityChanged(true)
                        }
                    }

                    override fun onRmsChanged(rmsdB: Float) {}

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                        when (error) {
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> scheduleRestart(600L)
                            SpeechRecognizer.ERROR_CLIENT, SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                                initSpeechRecognizer()
                                scheduleRestart(800L)
                            }
                            else -> scheduleRestart(90L) // Instant re-arm on silence/no-match
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                        val bestMatch = matches.firstOrNull { containsWakeWord(it.lowercase(Locale.ROOT)) }
                            ?: matches.firstOrNull().orEmpty()
                        val spokenText = bestMatch.trim()
                        if (spokenText.isNotEmpty()) {
                            processBackgroundSpeech(spokenText)
                        } else if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                        scheduleRestart(90L)
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partials = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            .orEmpty()
                        if (partials.any { containsWakeWord(it.lowercase(Locale.ROOT)) }) {
                            onVoiceActivityChanged(true)
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        } catch (_: Exception) {
            speechRecognizer = null
        }
    }

    private fun startListeningLoop() {
        if (isDestroyed || isListening || speechRecognizer == null) return
        try {
            isListening = true
            speechRecognizer?.startListening(recognizerIntent)
        } catch (_: Exception) {
            isListening = false
            scheduleRestart(500L)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (isDestroyed || speechRecognizer == null) return
        mainHandler.postDelayed({ startListeningLoop() }, delayMs)
    }

    private fun containsWakeWord(lowerText: String): Boolean {
        return wakeWords.any { w ->
            lowerText == w ||
                lowerText.startsWith("$w ") ||
                lowerText.startsWith("$w,") ||
                lowerText.contains(" $w ") ||
                lowerText.contains(" $w,")
        }
    }

    private fun stripWakeWord(rawText: String): String {
        var result = rawText.trim()
        for (w in wakeWords.sortedByDescending { it.length }) {
            if (result.startsWith(w, ignoreCase = true)) {
                result = result.substring(w.length).trimStart { it == ',' || it == ' ' || it == '!' || it == '.' }
            }
        }
        return result.trim()
    }

    private fun processBackgroundSpeech(spokenText: String) {
        val now = System.currentTimeMillis()
        val lower = spokenText.lowercase(Locale.ROOT)
        val hasWake = containsWakeWord(lower)

        if (hasWake) {
            onWakeWordTriggeredHaptic()
            onVoiceActivityChanged(true)
            val commandPart = stripWakeWord(spokenText)
            if (commandPart.isNotEmpty()) {
                armedUntilMs = 0L
                handleRecognizedCommand(commandPart, fromDirectTap = false)
                mainHandler.postDelayed({ onVoiceActivityChanged(false) }, 900L)
            } else {
                // User said just "Эхо!" -> arm active listening window for 10 seconds
                armedUntilMs = now + 10_000L
                speak("Слушаю")
            }
        } else if (now < armedUntilMs) {
            armedUntilMs = 0L
            handleRecognizedCommand(spokenText, fromDirectTap = false)
            mainHandler.postDelayed({ onVoiceActivityChanged(false) }, 900L)
        }
    }

    fun handleRecognizedCommand(spokenText: String, fromDirectTap: Boolean = true) {
        val cleaned = if (fromDirectTap) stripWakeWord(spokenText).ifEmpty { spokenText } else spokenText
        val lower = cleaned.lowercase(Locale.ROOT)
        val tvStatus = miTvController.lastKnownStatus

        if (tryHandleSmartLightCommand(lower)) {
            return
        }

        if (tvStatus.isReachable && tvStatus.isInteractive) {
            scope.launch {
                miTvController.forwardVoiceCommandToTv(cleaned)
            }
        } else {
            scope.launch {
                when {
                    lower.contains("youtube") || lower.contains("ютуб") -> {
                        miTvController.launchApp(MiTvController.TvApp.YOUTUBE)
                        speak("Запускаю YouTube")
                    }
                    lower.contains("kick") || lower.contains("кик") || lower.contains("кік") -> {
                        miTvController.launchApp(MiTvController.TvApp.KICK)
                        speak("Запускаю Kick")
                    }
                    lower.contains("браузер") || lower.contains("browser") -> {
                        miTvController.launchApp(MiTvController.TvApp.BROWSER)
                        speak("Открываю браузер")
                    }
                    else -> {
                        miTvController.forwardVoiceCommandToTv(cleaned)
                    }
                }
            }
        }
    }

    private class NamedColor(val keys: List<String>, val hue: Int, val sat: Int, val tvPreset: String, val say: String)

    private val namedColors = listOf(
        NamedColor(listOf("красн", "червон", "red"), 0, 100, "sunset", "Красный свет"),
        NamedColor(listOf("жёлт", "желт", "жовт", "yellow", "янтар", "amber"), 45, 100, "sunset", "Янтарный свет"),
        NamedColor(listOf("зелён", "зелен", "лайм", "изумруд", "green", "lime"), 125, 100, "cyber", "Зелёный свет"),
        NamedColor(listOf("бирюз", "циан", "океан", "cyan", "ocean"), 175, 100, "cyber", "Бирюзовый свет"),
        NamedColor(listOf("голуб", "блакит", "light blue"), 197, 100, "cyber", "Голубой свет"),
        NamedColor(listOf("белый", "біл", "white"), 34, 15, "warm", "Белый свет")
    )

    private fun tryHandleSmartLightCommand(lower: String): Boolean {
        val strip = tuyaController.stripDeviceId
        val mentionsLight = lower.contains("свет") || lower.contains("світл") || lower.contains("лент") ||
            lower.contains("стрічк") || lower.contains("light") || lower.contains("подсвет") || lower.contains("підсвіт")

        // 1. Power OFF
        if (lower.contains("выключи свет") || lower.contains("выключи ленту") ||
            lower.contains("вимкни світло") || lower.contains("вимкни стрічку") ||
            lower.contains("turn off light") || lower.contains("turn off strip") ||
            lower.contains("выключи подсветку") || lower.contains("вимкни підсвітку")
        ) {
            tuyaController.requestPower(scope, strip, false)
            scope.launch { miTvController.syncLightToTv(power = false) }
            onLocalStripPowerChanged(false)
            speak("Подсветка выключена")
            return true
        }
        // 1b. Power ON
        if (lower.contains("включи свет") || lower.contains("включи ленту") ||
            lower.contains("увімкни світло") || lower.contains("увімкни стрічку") ||
            lower.contains("turn on light") || lower.contains("turn on strip") ||
            lower.contains("включи подсветку") || lower.contains("увімкни підсвітку")
        ) {
            tuyaController.requestPower(scope, strip, true)
            scope.launch { miTvController.syncLightToTv(power = true) }
            onLocalStripPowerChanged(true)
            speak("Включаю подсветку")
            return true
        }

        // 2. Brightness: "яркость 40", "свет на 50 процентов", "ярче", "темнее"
        val state = getLightState()
        val percent = Regex("(\\d{1,3})\\s*(%|процент|відсот|percent)").find(lower)?.groupValues?.get(1)?.toIntOrNull()
            ?: Regex("(яркость|яскравість|brightness)\\s*(на|до|to)?\\s*(\\d{1,3})").find(lower)?.groupValues?.get(3)?.toIntOrNull()
        if (percent != null && (mentionsLight || lower.contains("яркост") || lower.contains("яскрав") || lower.contains("bright"))) {
            val v = percent.coerceIn(5, 100)
            applyColor(state[0], state[1], v, null, "Яркость $v процентов")
            return true
        }
        if (lower.contains("ярче") || lower.contains("яскравіше") || lower.contains("brighter") || lower.contains("прибавь свет")) {
            val v = (state[2] + 25).coerceAtMost(100)
            applyColor(state[0], state[1], v, null, "Ярче")
            return true
        }
        if (lower.contains("темнее") || lower.contains("темніше") || lower.contains("тусклее") ||
            lower.contains("dimmer") || lower.contains("приглуши")
        ) {
            val v = (state[2] - 25).coerceAtLeast(5)
            applyColor(state[0], state[1], v, null, "Темнее")
            return true
        }

        // 3. Named presets
        val presets = listOf(
            listOf("тёпл", "тепл", "warm") to TuyaController.LightPreset.WARM,
            listOf("кибер", "кібер", "cyber") to TuyaController.LightPreset.CYBER,
            listOf("сапфир", "сапфір", "синий", "синій", "индиго", "blue", "sapphire") to TuyaController.LightPreset.SAPPHIRE,
            listOf("фиолет", "фіолет", "purple", "violet") to TuyaController.LightPreset.VIOLET,
            listOf("малин", "розов", "рожев", "фукси", "pink", "raspberry") to TuyaController.LightPreset.RASPBERRY,
            listOf("закат", "захід", "оранж", "sunset", "orange") to TuyaController.LightPreset.SUNSET
        )
        val lightBlue = lower.contains("голуб") || lower.contains("блакит") || lower.contains("light blue")
        if (!lightBlue) {
            for ((keys, preset) in presets) {
                if (keys.any { lower.contains(it) }) {
                    onLocalPresetChanged(preset)
                    speak(preset.titleRu)
                    return true
                }
            }
        }

        // 4. Free colours
        for (c in namedColors) {
            if (c.keys.any { lower.contains(it) }) {
                applyColor(c.hue, c.sat, state[2].coerceAtLeast(60), c.tvPreset, c.say)
                return true
            }
        }
        return false
    }

    private fun applyColor(hue: Int, satPercent: Int, brightPercent: Int, tvPreset: String?, say: String) {
        tuyaController.requestHsv(scope, tuyaController.stripDeviceId, hue, satPercent * 10, brightPercent * 10)
        val mappedPreset = tvPreset ?: miTvController.mapHueToTvPresetId(hue, satPercent)
        scope.launch {
            miTvController.syncLightToTv(power = true, presetId = mappedPreset, brightPercent = brightPercent)
        }
        onLocalColorChanged(hue, satPercent, brightPercent)
        speak(say)
    }

    private fun speak(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "console_tts")
    }
}
