package com.smartconsole.touch.voice

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.content.res.AssetManager
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioAttributes
import android.media.AudioTrack
import android.media.audiofx.AudioEffect
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.smartconsole.touch.network.MiTvController
import com.smartconsole.touch.network.TuyaController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.max
import kotlin.math.min

/**
 * FAR-FIELD SMART SPEAKER VOICE ENGINE ("ЭХО" / "ECHO"):
 *
 * Why standard Android SpeechRecognizer missed 2 out of 3 wake-ups from across the room:
 * 1. SpeechRecognizer closes the mic after 1.5s of silence and takes ~1.8s to restart on MediaTek MT6739.
 *    During that restart window the phone is completely deaf.
 * 2. Huawei EMUI's analog mic gate cuts off the soft vowel "Э" at >1 meter distance, leaving only
 *    truncated phonetic fragments ("хо", "ха", "эха", "ехо", "эко", "ихо").
 *
 * How this new architecture works like a dedicated Smart Speaker (HomePod / Yandex Station):
 * 1. Continuous Far-Field `AudioRecord` DSP Pre-Amp (`UNPROCESSED` / `VOICE_RECOGNITION`, 16kHz):
 *    - Attaches hardware `AutomaticGainControl` (AGC) and disables aggressive noise gating so
 *      distant voice across the room (3-5 meters) is amplified before detection.
 *    - Continuously monitors room audio energy & 2-syllable vocal envelope with 0ms deadzone.
 * 2. Instant Command Window + Fuzzy Phonetic Wake Matcher:
 *    - Matches all distant-mic phonetic variations of "Эхо" (`эхо`, `ехо`, `echo`, `эха`, `еха`,
 *      `эко`, `еко`, `ихо`, `ахо`, `хо`, `хей`, `эй`, `слушай`) in both partial and final results!
 *    - Once triggered, keeps a 12-second active listening session open (glowing Dynamic Island line)
 *      and speaks confirmation ("Да?" / "Слушаю"), executing any RU / UK / EN command immediately.
 */
class VoiceAssistantEngine(
    private val context: Context,
    private val scope: CoroutineScope,
    private val miTvController: MiTvController,
    private val tuyaController: TuyaController,
    private val onVoiceActivityChanged: (Boolean) -> Unit,
    private val onWakeWordTriggeredHaptic: () -> Unit,
    private val onLocalPresetChanged: (TuyaController.LightPreset) -> Unit,
    private val onLocalStripPowerChanged: (Boolean) -> Unit,
    private val getLightState: () -> IntArray,
    private val onLocalColorChanged: (Int, Int, Int) -> Unit
) : TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isListening = false
    private var isDestroyed = false
    @Volatile private var armedUntilMs: Long = 0L
    private var lastTriggerAtMs: Long = 0L

    private var farFieldWatchdogJob: Job? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    // Comprehensive phonetic dictionary for far-field "Эхо" recognition across RU / UK / EN
    private val exactWakeWords = listOf(
        "эхо", "ехо", "екхо", "экхо", "echo", "eho", "ekho",
        "эха", "еха", "эко", "еко", "ихо", "ахо", "охо",
        "эй эхо", "хей эхо", "алло эхо", "привет эхо", "hey echo", "ok echo"
    )

    // Short clipped endings when Huawei mic gate clips the initial "Э-" from far away
    private val clippedWakeTokens = setOf(
        "хо", "ха", "эхо", "ехо", "эха", "еха", "эко", "еко", "echo", "eho"
    )

    private val recognizerIntent: Intent by lazy {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(
                "android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES",
                arrayOf("uk-UA", "en-US", "ru-RU")
            )
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            // Keep the microphone open much longer (6 seconds) so there are almost no deaf restart gaps!
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 6000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        }
    }

    fun start() {
        if (isDestroyed) return
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
        // Preferred path: always-on OFFLINE pipeline (one never-closed mic stream, zero deaf gaps).
        // If the Vosk model is not bundled / fails to load, we fall back to the legacy recognizer loop.
        startOffline()
    }

    private fun startLegacy() {
        if (isDestroyed) return
        initSpeechRecognizer()
        startListeningLoop()
        startZeroDeadzoneWatchdog()
    }

    fun stop() {
        isDestroyed = true
        isListening = false
        offlineActive = false
        offlineJob?.cancel()
        farFieldWatchdogJob?.cancel()
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.destroy()
        speechRecognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ru", "RU")
            // Deaf-while-speaking guard: the mic stays muted only for the real duration of our own voice.
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    mutedUntilMs = System.currentTimeMillis() + 8000L
                }
                override fun onDone(utteranceId: String?) {
                    mutedUntilMs = System.currentTimeMillis() + 350L
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    mutedUntilMs = System.currentTimeMillis() + 350L
                }
            })
        }
    }

    /**
     * Watchdog coroutine that guarantees the recognizer never stays idle or stuck in a deadzone.
     */
    private fun startZeroDeadzoneWatchdog() {
        farFieldWatchdogJob?.cancel()
        farFieldWatchdogJob = scope.launch(Dispatchers.Main) {
            while (isActive && !isDestroyed) {
                kotlinx.coroutines.delay(1400L)
                if (!isListening && !isDestroyed && !offlineActive) {
                    startListeningLoop()
                }
            }
        }
    }

    private fun initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        isListening = true
                    }

                    override fun onBeginningOfSpeech() {
                        if (System.currentTimeMillis() < armedUntilMs) {
                            onVoiceActivityChanged(true)
                        }
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        // Visual feedback when armed and user speaks
                        if (System.currentTimeMillis() < armedUntilMs && rmsdB > 3.0f) {
                            onVoiceActivityChanged(true)
                        }
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        isListening = false
                        if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                        when (error) {
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> scheduleRestart(350L)
                            SpeechRecognizer.ERROR_CLIENT, SpeechRecognizer.ERROR_SERVER -> {
                                initSpeechRecognizer()
                                scheduleRestart(300L)
                            }
                            else -> scheduleRestart(40L) // 40ms ultra-fast re-arm on silence/timeout
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                        // Inspect ALL 5 recognition hypotheses so even if "эхо" is hypothesis #2 or #3, it triggers!
                        val wakeHypothesis = matches.firstOrNull { containsWakeWord(it.lowercase(Locale.ROOT)) }
                        val chosenText = (wakeHypothesis ?: matches.firstOrNull().orEmpty()).trim()

                        if (chosenText.isNotEmpty()) {
                            processBackgroundSpeech(chosenText)
                        } else if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                        scheduleRestart(40L)
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partials = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            .orEmpty()
                        val matchedPartial = partials.firstOrNull { containsWakeWord(it.lowercase(Locale.ROOT)) }
                        if (matchedPartial != null) {
                            val now = System.currentTimeMillis()
                            // Immediately light up Dynamic Island & arm on the very first syllable of "Эхо"!
                            onVoiceActivityChanged(true)
                            if (now - lastTriggerAtMs > 1800L && now >= armedUntilMs) {
                                lastTriggerAtMs = now
                                armedUntilMs = now + 12_000L
                                onWakeWordTriggeredHaptic()
                            }
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        } catch (_: Exception) {
            speechRecognizer = null
        }
    }

    private fun startListeningLoop() {
        if (isDestroyed || isListening) return
        if (speechRecognizer == null) {
            initSpeechRecognizer()
        }
        try {
            isListening = true
            speechRecognizer?.startListening(recognizerIntent)
        } catch (_: Exception) {
            isListening = false
            scheduleRestart(250L)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (isDestroyed) return
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.postDelayed({ startListeningLoop() }, delayMs)
    }

    /**
     * Far-field phonetic wake-word detector:
     * Recognizes full "эхо/ехо/echo" as well as distant mic-clipped variations ("эха", "еха", "эко", "хо").
     */
    private fun containsWakeWord(lowerText: String): Boolean {
        val cleaned = lowerText.trim()
        if (cleaned.isEmpty()) return false

        // 1. Check exact or prefix/substring wake words
        if (exactWakeWords.any { w ->
                cleaned == w ||
                    cleaned.startsWith("$w ") ||
                    cleaned.startsWith("$w,") ||
                    cleaned.contains(" $w ") ||
                    cleaned.endsWith(" $w")
            }
        ) {
            return true
        }

        // 2. Check individual words against clipped far-field tokens (e.g. when user says just "Эхо!" from 4m away)
        val words = cleaned.split(Regex("[\\s,!.?]+")).filter { it.isNotEmpty() }
        if (words.isNotEmpty() && words.first() in clippedWakeTokens) {
            return true
        }

        // 3. Phonetic Levenshtein-like pattern: 2-4 letter word ending in "-хо" or "-ха" or "-ко"
        val firstWord = words.firstOrNull().orEmpty()
        if (firstWord.length in 2..4 &&
            (firstWord.endsWith("хо") || firstWord.endsWith("ха") || firstWord.endsWith("cho"))
        ) {
            return true
        }

        return false
    }

    private fun stripWakeWord(rawText: String): String {
        var result = rawText.trim()
        for (w in exactWakeWords.sortedByDescending { it.length }) {
            if (result.startsWith(w, ignoreCase = true)) {
                result = result.substring(w.length).trimStart { it == ',' || it == ' ' || it == '!' || it == '.' }
            }
        }
        val words = result.split(Regex("\\s+"))
        if (words.isNotEmpty()) {
            val first = words.first().lowercase(Locale.ROOT).trim(',', '!', '.', '?')
            if (first in clippedWakeTokens || (first.length in 2..4 && (first.endsWith("хо") || first.endsWith("ха")))) {
                result = words.drop(1).joinToString(" ").trim()
            }
        }
        return result.trim()
    }

    private fun processBackgroundSpeech(spokenText: String, knownWake: Boolean = false) {
        val now = System.currentTimeMillis()
        val lower = spokenText.lowercase(Locale.ROOT)
        val hasWake = knownWake || containsWakeWord(lower)

        if (hasWake) {
            if (now - lastTriggerAtMs > 1200L) {
                onWakeWordTriggeredHaptic()
            }
            lastTriggerAtMs = now
            onVoiceActivityChanged(true)
            val commandPart = stripWakeWord(spokenText)
            if (commandPart.isNotEmpty()) {
                armedUntilMs = 0L
                handleRecognizedCommand(commandPart, fromDirectTap = false)
                mainHandler.postDelayed({ onVoiceActivityChanged(false) }, 900L)
            } else {
                // User called "Эхо!" from across the room -> keep active command window open for 12 seconds!
                armedUntilMs = now + 12_000L
                playChime(wake = true) // instant melodic earcon instead of a spoken answer
            }
        } else if (now < armedUntilMs) {
            armedUntilMs = 0L
            handleRecognizedCommand(spokenText, fromDirectTap = false)
            mainHandler.postDelayed({ onVoiceActivityChanged(false) }, 900L)
        }
    }

    fun handleRecognizedCommand(spokenText: String, fromDirectTap: Boolean = true) {
        val cleaned = if (fromDirectTap) stripWakeWord(spokenText).ifEmpty { spokenText } else spokenText
        val lower = cleaned.lowercase(Locale.ROOT)
        val tvStatus = miTvController.lastKnownStatus

        if (tryHandleSmartLightCommand(lower)) {
            return
        }

        if (tvStatus.isReachable && tvStatus.isInteractive) {
            scope.launch {
                miTvController.forwardVoiceCommandToTv(cleaned)
            }
        } else {
            scope.launch {
                when {
                    lower.contains("youtube") || lower.contains("ютуб") -> {
                        miTvController.launchApp(MiTvController.TvApp.YOUTUBE)
                        speak("Запускаю YouTube")
                    }
                    lower.contains("kick") || lower.contains("кик") || lower.contains("кік") -> {
                        miTvController.launchApp(MiTvController.TvApp.KICK)
                        speak("Запускаю Kick")
                    }
                    lower.contains("браузер") || lower.contains("browser") -> {
                        miTvController.launchApp(MiTvController.TvApp.BROWSER)
                        speak("Открываю браузер")
                    }
                    else -> {
                        miTvController.forwardVoiceCommandToTv(cleaned)
                    }
                }
            }
        }
    }

    private class NamedColor(val keys: List<String>, val hue: Int, val sat: Int, val tvPreset: String, val say: String)

    private val namedColors = listOf(
        NamedColor(listOf("красн", "червон", "red"), 0, 100, "sunset", "Красный свет"),
        NamedColor(listOf("жёлт", "желт", "жовт", "yellow", "янтар", "amber"), 45, 100, "sunset", "Янтарный свет"),
        NamedColor(listOf("зелён", "зелен", "лайм", "изумруд", "green", "lime"), 125, 100, "cyber", "Зелёный свет"),
        NamedColor(listOf("бирюз", "циан", "океан", "cyan", "ocean"), 175, 100, "cyber", "Бирюзовый свет"),
        NamedColor(listOf("голуб", "блакит", "light blue"), 197, 100, "cyber", "Голубой свет"),
        NamedColor(listOf("белый", "біл", "white"), 34, 15, "warm", "Белый свет")
    )

    private fun tryHandleSmartLightCommand(lower: String): Boolean {
        val strip = tuyaController.stripDeviceId
        val mentionsLight = lower.contains("свет") || lower.contains("світл") || lower.contains("лент") ||
            lower.contains("стрічк") || lower.contains("light") || lower.contains("подсвет") || lower.contains("підсвіт")

        // 1. Power OFF
        if (lower.contains("выключи свет") || lower.contains("выключи ленту") ||
            lower.contains("вимкни світло") || lower.contains("вимкни стрічку") ||
            lower.contains("turn off light") || lower.contains("turn off strip") ||
            lower.contains("выключи подсветку") || lower.contains("вимкни підсвітку")
        ) {
            tuyaController.requestPower(scope, strip, false)
            scope.launch { miTvController.syncLightToTv(power = false) }
            onLocalStripPowerChanged(false)
            speak("Подсветка выключена")
            return true
        }
        // 1b. Power ON
        if (lower.contains("включи свет") || lower.contains("включи ленту") ||
            lower.contains("увімкни світло") || lower.contains("увімкни стрічку") ||
            lower.contains("turn on light") || lower.contains("turn on strip") ||
            lower.contains("включи подсветку") || lower.contains("увімкни підсвітку")
        ) {
            tuyaController.requestPower(scope, strip, true)
            scope.launch { miTvController.syncLightToTv(power = true) }
            onLocalStripPowerChanged(true)
            speak("Включаю подсветку")
            return true
        }

        // 2. Brightness
        val state = getLightState()
        val percent = Regex("(\\d{1,3})\\s*(%|процент|відсот|percent)").find(lower)?.groupValues?.get(1)?.toIntOrNull()
            ?: Regex("(яркость|яскравість|brightness)\\s*(на|до|to)?\\s*(\\d{1,3})").find(lower)?.groupValues?.get(3)?.toIntOrNull()
        if (percent != null && (mentionsLight || lower.contains("яркост") || lower.contains("яскрав") || lower.contains("bright"))) {
            val v = percent.coerceIn(5, 100)
            applyColor(state[0], state[1], v, null, "Яркость $v процентов")
            return true
        }
        if (lower.contains("ярче") || lower.contains("яскравіше") || lower.contains("brighter") || lower.contains("прибавь свет")) {
            val v = (state[2] + 25).coerceAtMost(100)
            applyColor(state[0], state[1], v, null, "Ярче")
            return true
        }
        if (lower.contains("темнее") || lower.contains("темніше") || lower.contains("тусклее") ||
            lower.contains("dimmer") || lower.contains("приглуши")
        ) {
            val v = (state[2] - 25).coerceAtLeast(5)
            applyColor(state[0], state[1], v, null, "Темнее")
            return true
        }

        // 3. Named presets
        val presets = listOf(
            listOf("тёпл", "тепл", "warm") to TuyaController.LightPreset.WARM,
            listOf("кибер", "кібер", "cyber") to TuyaController.LightPreset.CYBER,
            listOf("сапфир", "сапфір", "синий", "синій", "индиго", "blue", "sapphire") to TuyaController.LightPreset.SAPPHIRE,
            listOf("фиолет", "фіолет", "purple", "violet") to TuyaController.LightPreset.VIOLET,
            listOf("малин", "розов", "рожев", "фукси", "pink", "raspberry") to TuyaController.LightPreset.RASPBERRY,
            listOf("закат", "захід", "оранж", "sunset", "orange") to TuyaController.LightPreset.SUNSET
        )
        val lightBlue = lower.contains("голуб") || lower.contains("блакит") || lower.contains("light blue")
        if (!lightBlue) {
            for ((keys, preset) in presets) {
                if (keys.any { lower.contains(it) }) {
                    onLocalPresetChanged(preset)
                    speak(preset.titleRu)
                    return true
                }
            }
        }

        // 4. Free colours
        for (c in namedColors) {
            if (c.keys.any { lower.contains(it) }) {
                applyColor(c.hue, c.sat, state[2].coerceAtLeast(60), c.tvPreset, c.say)
                return true
            }
        }
        return false
    }

    private fun applyColor(hue: Int, satPercent: Int, brightPercent: Int, tvPreset: String?, say: String) {
        tuyaController.requestHsv(scope, tuyaController.stripDeviceId, hue, satPercent * 10, brightPercent * 10)
        val colorName = miTvController.getFriendlyColorName(hue, satPercent)
        scope.launch {
            miTvController.syncLightToTv(
                power = true,
                presetId = tvPreset,
                hue = hue,
                satPercent = satPercent,
                brightPercent = brightPercent,
                colorName = colorName
            )
        }
        onLocalColorChanged(hue, satPercent, brightPercent)
        speak(say)
    }

    private fun speak(message: String) {
        if (!SPEAK_CONFIRMATIONS) {
            playChime(wake = false)
            return
        }
        mutedUntilMs = System.currentTimeMillis() + 8000L
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "console_tts")
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // ALWAYS-ON OFFLINE PIPELINE (Vosk)
    //  • ONE AudioRecord that is never closed  → no restart gaps, works without Google services.
    //  • Software far-field gain (adaptive, up to x14) before detection.
    //  • Cheap grammar recognizer listens only for «Эхо»; on trigger the last 1.2 s of audio
    //    (ring buffer) is replayed into a free-form recognizer, so "Эхо, включи свет" said in a single
    //    breath is understood, and a lone "Эхо" opens a 12 s command window with an instant beep.
    //  • Mic is muted while the assistant itself talks/beeps (no self-triggering).
    // ─────────────────────────────────────────────────────────────────────────────
    private var offlineJob: Job? = null
    @Volatile private var offlineActive = false
    @Volatile private var mutedUntilMs = 0L
    @Volatile private var commandDeadlineMs = 0L
    private var wakeChime: ShortArray? = null
    private var doneChime: ShortArray? = null
    private val audioEffects = mutableListOf<AudioEffect>()

    private fun startOffline() {
        offlineJob?.cancel()
        offlineJob = scope.launch(Dispatchers.IO) {
            val model = try {
                loadModel()
            } catch (_: Throwable) {
                null
            }
            if (model == null || isDestroyed) {
                offlineActive = false
                mainHandler.post { startLegacy() }
                return@launch
            }
            offlineActive = true
            try {
                runOfflineLoop(model)
            } catch (_: Throwable) {
                offlineActive = false
                mainHandler.post { startLegacy() }
            }
        }
    }

    private fun loadModel(): Model? {
        sharedModel?.let { return it }
        val am = context.assets
        val bundled = try {
            am.list(MODEL_ASSET)?.isNotEmpty() == true
        } catch (_: Exception) {
            false
        }
        if (!bundled) return null
        val target = File(context.filesDir, "vosk-model")
        val marker = File(target, ".ready")
        if (!marker.exists()) {
            target.deleteRecursively()
            copyAssetDir(am, MODEL_ASSET, target)
            marker.writeText("ok")
        }
        return Model(target.absolutePath).also { sharedModel = it }
    }

    private fun copyAssetDir(am: AssetManager, src: String, dst: File) {
        val children = am.list(src) ?: emptyArray()
        if (children.isEmpty()) {
            try {
                dst.parentFile?.mkdirs()
                am.open(src).use { input -> FileOutputStream(dst).use { out -> input.copyTo(out) } }
            } catch (_: java.io.FileNotFoundException) {
                dst.mkdirs() // empty directory inside the model
            }
        } else {
            dst.mkdirs()
            for (name in children) copyAssetDir(am, "$src/$name", File(dst, name))
        }
    }

    private fun releaseRecorder(r: AudioRecord?) {
        audioEffects.forEach { try { it.release() } catch (_: Exception) {} }
        audioEffects.clear()
        try { r?.stop() } catch (_: Exception) {}
        try { r?.release() } catch (_: Exception) {}
    }

    @SuppressLint("MissingPermission")
    private fun createRecorder(rate: Int, bufBytes: Int): AudioRecord? {
        return try {
            val r = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                rate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufBytes
            )
            if (r.state != AudioRecord.STATE_INITIALIZED) {
                r.release()
                return null
            }
            // Effects are attached to THIS live session (they do nothing on a released one).
            val sid = r.audioSessionId
            try {
                if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(sid)?.let { it.enabled = false; audioEffects += it }
                if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(sid)?.let { it.enabled = false; audioEffects += it }
                if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(sid)?.let { it.enabled = true; audioEffects += it }
            } catch (_: Exception) {
            }
            r.startRecording()
            if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                releaseRecorder(r)
                return null
            }
            r
        } catch (_: Throwable) {
            null
        }
    }

    private fun runOfflineLoop(model: Model) {
        val rate = 16000
        val wakeGrammar = "[\"эхо\", \"эй эхо\", \"привет эхо\", \"алло эхо\", \"слушай\", \"[unk]\"]"
        val wakeRec = Recognizer(model, rate.toFloat(), wakeGrammar)
        val cmdRec = Recognizer(model, rate.toFloat())
        val ring = ShortArray(rate * 2)
        var ringPos = 0
        var ringFilled = 0
        val chunk = ShortArray(rate / 10) // 100 ms
        val bufBytes = max(
            AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT),
            rate * 2
        )
        var recorder: AudioRecord? = null
        var envPeak = 400f
        var inCommand = false
        var wasMuted = false
        var lastPartial = ""

        try {
            while (!isDestroyed) {
                if (recorder == null) {
                    recorder = createRecorder(rate, bufBytes)
                    if (recorder == null) {
                        Thread.sleep(1500L) // e.g. permission not granted yet / mic busy: keep retrying forever
                        continue
                    }
                }
                val n = recorder.read(chunk, 0, chunk.size)
                if (n <= 0) {
                    releaseRecorder(recorder)
                    recorder = null
                    Thread.sleep(400L)
                    continue
                }
                val now = System.currentTimeMillis()

                // Adaptive software gain for far-field voice (slow decay envelope follower)
                var peak = 0
                for (i in 0 until n) {
                    val a = abs(chunk[i].toInt())
                    if (a > peak) peak = a
                }
                envPeak = max(peak.toFloat(), envPeak * 0.985f).coerceAtLeast(400f)
                val gain = (9000f / envPeak).coerceIn(1f, 14f)
                for (i in 0 until n) {
                    chunk[i] = (chunk[i] * gain).toInt().coerceIn(-32768, 32767).toShort()
                }

                // Don't listen to ourselves
                if (now < mutedUntilMs) {
                    wasMuted = true
                    continue
                }
                if (wasMuted) {
                    wasMuted = false
                    wakeRec.reset()
                    cmdRec.reset()
                    ringFilled = 0
                }

                for (i in 0 until n) {
                    ring[ringPos] = chunk[i]
                    ringPos = (ringPos + 1) % ring.size
                }
                ringFilled = min(ring.size, ringFilled + n)

                if (now < commandDeadlineMs) {
                    // ── COMMAND WINDOW: free-form offline recognition
                    inCommand = true
                    if (cmdRec.acceptWaveForm(chunk, n)) {
                        val text = JSONObject(cmdRec.result).optString("text").trim()
                        cmdRec.reset()
                        wakeRec.reset()
                        lastPartial = ""
                        commandDeadlineMs = now + 1500L // short grace until main thread decides
                        val first = now >= armedUntilMs
                        mainHandler.post {
                            if (text.isNotEmpty()) {
                                processBackgroundSpeech(text, knownWake = first)
                            }
                            val t = System.currentTimeMillis()
                            commandDeadlineMs = if (armedUntilMs > t) armedUntilMs else 0L
                            if (commandDeadlineMs == 0L) {
                                mainHandler.postDelayed({
                                    if (System.currentTimeMillis() >= armedUntilMs) onVoiceActivityChanged(false)
                                }, 900L)
                            }
                        }
                    } else {
                        val p = JSONObject(cmdRec.partialResult).optString("partial")
                        if (p.isNotEmpty() && p != lastPartial) {
                            lastPartial = p
                            commandDeadlineMs = max(commandDeadlineMs, now + 2500L) // user still talking
                        }
                    }
                } else {
                    // ── WAKE MODE: cheap grammar spotter for «Эхо»
                    if (inCommand) {
                        inCommand = false
                        wakeRec.reset()
                        cmdRec.reset()
                        lastPartial = ""
                        mainHandler.post {
                            if (System.currentTimeMillis() >= armedUntilMs) onVoiceActivityChanged(false)
                        }
                    }
                    val done = wakeRec.acceptWaveForm(chunk, n)
                    val heard = if (done) {
                        JSONObject(wakeRec.result).optString("text")
                    } else {
                        JSONObject(wakeRec.partialResult).optString("partial")
                    }
                    if (heard.contains("эхо") && now - lastTriggerAtMs > 1500L) {
                        lastTriggerAtMs = now
                        wakeRec.reset()
                        cmdRec.reset()
                        // Replay the last ~1.2 s so the command spoken right after "Эхо" is not lost
                        val len = min(ringFilled, (rate * 12) / 10)
                        val tmp = ShortArray(len)
                        val start = (ringPos - len + ring.size) % ring.size
                        for (k in 0 until len) tmp[k] = ring[(start + k) % ring.size]
                        cmdRec.acceptWaveForm(tmp, len)
                        commandDeadlineMs = now + 6000L
                        inCommand = true
                        lastPartial = ""
                        onWakeWordTriggeredHaptic()
                        onVoiceActivityChanged(true)
                    }
                }
            }
        } finally {
            releaseRecorder(recorder)
            try { wakeRec.close() } catch (_: Exception) {}
            try { cmdRec.close() } catch (_: Exception) {}
        }
    }

    /** Soft bell-like arpeggio: pure sine + 2 quiet overtones, fast attack, exponential decay. */
    private fun synthChime(freqs: List<Double>, stepMs: Int, tailMs: Int): ShortArray {
        val sr = CHIME_RATE
        val step = sr * stepMs / 1000
        val noteLen = sr * (stepMs + tailMs) / 1000
        val total = step * (freqs.size - 1) + noteLen
        val buf = DoubleArray(total)
        freqs.forEachIndexed { i, f ->
            val start = i * step
            for (k in 0 until noteLen) {
                val t = k / sr.toDouble()
                val env = min(1.0, k / (sr * 0.005)) * exp(-t * 6.5)
                val v = (sin(2 * PI * f * t) + 0.30 * sin(4 * PI * f * t) + 0.10 * sin(6 * PI * f * t)) * env
                buf[start + k] += v
            }
        }
        var peak = 1e-9
        for (v in buf) peak = max(peak, abs(v))
        val out = ShortArray(total)
        for (i in 0 until total) out[i] = (buf[i] / peak * 0.5 * 32767).toInt().toShort()
        return out
    }

    /** wake = bright rising fifth «ту-дун ↑»; done = gentle 3-note major arpeggio «успех». */
    private fun playChime(wake: Boolean) {
        try {
            val data = if (wake) {
                wakeChime ?: synthChime(listOf(659.25, 987.77), 110, 420).also { wakeChime = it } // E5 → B5
            } else {
                doneChime ?: synthChime(listOf(784.0, 1046.5, 1318.5), 85, 380).also { doneChime = it } // G5 → C6 → E6
            }
            val ms = data.size * 1000L / CHIME_RATE
            mutedUntilMs = System.currentTimeMillis() + ms + 250L // don't hear our own chime
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(CHIME_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setTransferMode(AudioTrack.MODE_STATIC)
                .setBufferSizeInBytes(data.size * 2)
                .build()
            track.write(data, 0, data.size)
            track.play()
            mainHandler.postDelayed({
                try { track.stop() } catch (_: Exception) {}
                try { track.release() } catch (_: Exception) {}
            }, ms + 300L)
        } catch (_: Exception) {
        }
    }

    companion object {
        private const val MODEL_ASSET = "model-ru"
        private const val CHIME_RATE = 44100
        /** false = confirmations are a short chime (consistent); true = Echo also speaks them aloud. */
        private const val SPEAK_CONFIRMATIONS = false
        @Volatile private var sharedModel: Model? = null
    }
}
