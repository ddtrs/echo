package com.smartconsole.touch.ui

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import com.smartconsole.touch.R
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Round clickpad container: adds swipe + "tap on the ring" support.
 * It never sends anything by itself: it just calls performClick() on the existing
 * arrow views (btnDpadUp/Down/Left/Right), so your own click handlers do the work.
 */
class ClickpadLayout @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private val swipeThreshold = 22f * resources.displayMetrics.density
    private var downX = 0f
    private var downY = 0f
    private var swiped = false

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y; swiped = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!swiped && hypot(ev.x - downX, ev.y - downY) > swipeThreshold) {
                    swiped = true
                    fire(ev.x - downX, ev.y - downY)
                    return true // children receive CANCEL
                }
            }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y; swiped = false
                // Only react inside the round disc
                val r = width / 2f
                return hypot(ev.x - r, ev.y - height / 2f) <= r
            }
            MotionEvent.ACTION_UP -> {
                if (!swiped && hypot(ev.x - downX, ev.y - downY) < swipeThreshold) {
                    // tap on the ring between arrows -> nearest direction
                    fire(ev.x - width / 2f, ev.y - height / 2f)
                }
                swiped = false
            }
            MotionEvent.ACTION_CANCEL -> swiped = false
        }
        return true
    }

    private fun fire(dx: Float, dy: Float) {
        val id = if (abs(dx) > abs(dy)) {
            if (dx > 0) R.id.btnDpadRight else R.id.btnDpadLeft
        } else {
            if (dy > 0) R.id.btnDpadDown else R.id.btnDpadUp
        }
        val arrow: View = findViewById(id) ?: return
        arrow.isPressed = true
        arrow.performClick()
        arrow.postDelayed({ arrow.isPressed = false }, 170L)
    }
}
