#!/usr/bin/env python3
"""
Trains the custom Far-Field Neural Keyword Spotter (echo_neural_kws.bin) for "Эй Эхо" / "Эхо".
- In GitHub Actions (with internet): uses Microsoft Edge Neural TTS (ru-RU & uk-UA voices) +
  room reverberation (1m..5m simulation) + 35 Russian phonetic hard-negative decoy words.
- Offline fallback: synthesizes formant trajectories for "эй эхо" / "эхо" vs decoy patterns.
Exports exact float32 weights + prototypes to app/src/main/assets/echo_neural_kws.bin.
"""
import asyncio
import glob
import math
import os
import random
import struct
import numpy as np

SR = 16000
N_FFT = 512
WIN_LEN = 400      # 25 ms
HOP_LEN = 800      # 50 ms (20 fps)
N_MELS = 32
N_FRAMES = 24      # 1.20 seconds window
FEAT_DIM = N_FRAMES * N_MELS  # 768

def hz_to_mel(hz):
    return 2595.0 * np.log10(1.0 + hz / 700.0)

def mel_to_hz(mel):
    return 700.0 * (10.0 ** (mel / 2595.0) - 1.0)

def build_mel_filterbank():
    low_mel = hz_to_mel(130.0)
    high_mel = hz_to_mel(6800.0)
    mel_points = np.linspace(low_mel, high_mel, N_MELS + 2)
    hz_points = mel_to_hz(mel_points)
    bin_points = np.floor((N_FFT + 1) * hz_points / SR).astype(int)
    fb = np.zeros((N_MELS, N_FFT // 2 + 1), dtype=np.float32)
    for m in range(1, N_MELS + 1):
        f_m_minus = bin_points[m - 1]
        f_m = bin_points[m]
        f_m_plus = bin_points[m + 1]
        for k in range(f_m_minus, f_m):
            if f_m > f_m_minus:
                fb[m - 1, k] = (k - f_m_minus) / (f_m - f_m_minus)
        for k in range(f_m, f_m_plus):
            if f_m_plus > f_m:
                fb[m - 1, k] = (f_m_plus - k) / (f_m_plus - f_m)
    return fb

MEL_FB = build_mel_filterbank()
HAMMING = (0.54 - 0.46 * np.cos(2.0 * np.pi * np.arange(WIN_LEN) / (WIN_LEN - 1))).astype(np.float32)

def extract_log_mel_window(y):
    target_len = (N_FRAMES - 1) * HOP_LEN + WIN_LEN
    if len(y) < target_len:
        pad_l = (target_len - len(y)) // 2
        y = np.pad(y, (pad_l, target_len - len(y) - pad_l))
    elif len(y) > target_len:
        # Center around peak energy
        best_start = 0
        best_e = -1.0
        for st in range(0, len(y) - target_len + 1, 800):
            e = float(np.sum(y[st:st + target_len] ** 2))
            if e > best_e:
                best_e = e
                best_start = st
        y = y[best_start:best_start + target_len]

    # High-pass 120Hz + gentle pre-emphasis 0.15 (identical to Kotlin DSP)
    hp = np.zeros_like(y, dtype=np.float32)
    prev_in = 0.0
    prev_out = 0.0
    for i in range(len(y)):
        x = float(y[i])
        prev_out = 0.955 * (prev_out + x - prev_in)
        prev_in = x
        hp[i] = prev_out
    pe = np.empty_like(hp)
    pe[0] = hp[0]
    pe[1:] = hp[1:] - 0.15 * hp[:-1]

    frames = np.zeros((N_FRAMES, N_MELS), dtype=np.float32)
    for t in range(N_FRAMES):
        start = t * HOP_LEN
        seg = pe[start:start + WIN_LEN] * HAMMING
        padded = np.zeros(N_FFT, dtype=np.float32)
        padded[:WIN_LEN] = seg
        spec = np.abs(np.fft.rfft(padded)) ** 2
        mel_e = np.dot(MEL_FB, spec)
        frames[t] = np.log(np.maximum(mel_e, 1e-7))

    flat = frames.reshape(-1)
    mean = float(np.mean(flat))
    std = float(np.sqrt(np.var(flat) + 1e-5))
    return ((flat - mean) / std).astype(np.float32)

def augment_far_field(y):
    delay = random.randint(220, 680)
    decay = random.uniform(0.15, 0.42)
    rev = np.zeros_like(y)
    rev[delay:] = y[:-delay] * decay
    y = y + rev
    gain = random.uniform(0.12, 1.0)
    noise = np.random.normal(0.0, random.uniform(0.001, 0.015), len(y)).astype(np.float32)
    return np.clip(y * gain + noise, -1.0, 1.0)

def synth_formant_utterance(is_positive):
    """Fallback synthetic formant generator when running offline without edge-tts."""
    dur = int(SR * 1.2)
    t = np.arange(dur, dtype=np.float32) / SR
    y = np.random.normal(0, 0.004, dur).astype(np.float32)
    f0 = random.uniform(110.0, 240.0)
    if is_positive:
        # "Эй Э-хо" / "Э-хо": vowel E (500Hz, 1850Hz) -> fricative X (1600-3200Hz noise) -> vowel O (450Hz, 900Hz)
        s1 = int(random.uniform(0.15, 0.30) * SR)
        s2 = s1 + int(random.uniform(0.14, 0.22) * SR)
        s3 = s2 + int(random.uniform(0.08, 0.14) * SR)
        s4 = min(dur, s3 + int(random.uniform(0.16, 0.26) * SR))
        # Vowel E
        te = t[s1:s2]
        y[s1:s2] += 0.4 * (np.sin(2 * np.pi * f0 * te) + 0.6 * np.sin(2 * np.pi * 530 * te) + 0.4 * np.sin(2 * np.pi * 1850 * te))
        # Velar fricative X
        noise_x = np.random.normal(0, 0.25, s3 - s2).astype(np.float32)
        tx = t[s2:s3]
        y[s2:s3] += noise_x * np.sin(2 * np.pi * 2200 * tx)
        # Vowel O
        to = t[s3:s4]
        y[s3:s4] += 0.38 * (np.sin(2 * np.pi * (f0 * 0.92) * to) + 0.7 * np.sin(2 * np.pi * 460 * to) + 0.35 * np.sin(2 * np.pi * 920 * to))
    else:
        # Random decoy speech / TV noise / single bursts
        mode = random.randint(0, 2)
        if mode == 0:
            f1 = random.uniform(250, 900)
            f2 = random.uniform(1000, 2600)
            s1 = int(random.uniform(0.1, 0.4) * SR)
            s2 = min(dur, s1 + int(random.uniform(0.2, 0.6) * SR))
            ts = t[s1:s2]
            y[s1:s2] += 0.35 * (np.sin(2 * np.pi * f0 * ts) + 0.5 * np.sin(2 * np.pi * f1 * ts) + 0.3 * np.sin(2 * np.pi * f2 * ts))
        elif mode == 1:
            # Sharp click / thump
            pos = random.randint(500, dur - 1000)
            y[pos:pos + 400] += np.random.normal(0, 0.6, 400).astype(np.float32) * np.exp(-np.linspace(0, 5, 400))
    return augment_far_field(y)

async def try_generate_tts_dataset():
    import edge_tts
    os.makedirs("/tmp/echo_tts/pos", exist_ok=True)
    os.makedirs("/tmp/echo_tts/neg", exist_ok=True)
    voices = ["ru-RU-DmitryNeural", "ru-RU-SvetlanaNeural", "uk-UA-OstapNeural", "uk-UA-PolinaNeural"]
    positives = ["эй эхо", "эхо", "привет эхо", "алло эхо", "слушай эхо"]
    negatives = [
        "это", "этого", "этому", "тихо", "плохо", "сухо", "ухо", "хорошо", "хочу", "хотя",
        "ехать", "уехал", "всех", "тех", "их", "выход", "вход", "смех", "верх", "эпоха",
        "экран", "эфир", "эффект", "слушать", "случайно", "да", "нет", "ну", "вот", "так"
    ]
    idx = 0
    for p in positives:
        for v in voices:
            for rate in ["-12%", "+0%", "+15%"]:
                out = f"/tmp/echo_tts/pos/p_{idx}.mp3"
                await edge_tts.Communicate(p, v, rate=rate).save(out)
                idx += 1
    idx = 0
    for n in negatives:
        for v in voices[:2]:
            out = f"/tmp/echo_tts/neg/n_{idx}.mp3"
            await edge_tts.Communicate(n, v).save(out)
            idx += 1

def build_dataset():
    X, Y = [], []
    try:
        import edge_tts
        import librosa
        print("Generating Edge-TTS Russian & Ukrainian dataset...")
        asyncio.get_event_loop().run_until_complete(try_generate_tts_dataset())
        for f in glob.glob("/tmp/echo_tts/pos/*.mp3"):
            y, _ = librosa.load(f, sr=SR, mono=True)
            for _ in range(8):
                X.append(extract_log_mel_window(augment_far_field(y)))
                Y.append(1.0)
        for f in glob.glob("/tmp/echo_tts/neg/*.mp3"):
            y, _ = librosa.load(f, sr=SR, mono=True)
            for _ in range(5):
                X.append(extract_log_mel_window(augment_far_field(y)))
                Y.append(0.0)
    except Exception as e:
        print(f"TTS generation skipped ({e}), using formant acoustic synthesis + augmentation...")

    # Always supplement with formant & noise acoustic sweeps
    for _ in range(600):
        X.append(extract_log_mel_window(synth_formant_utterance(True)))
        Y.append(1.0)
    for _ in range(900):
        X.append(extract_log_mel_window(synth_formant_utterance(False)))
        Y.append(0.0)

    return np.array(X, dtype=np.float32), np.array(Y, dtype=np.float32)[:, None]

def train_and_export(out_path):
    np.random.seed(42)
    random.seed(42)
    X, Y = build_dataset()
    N = len(X)
    perm = np.random.permutation(N)
    X, Y = X[perm], Y[perm]

    # Network: 768 -> 128 (ReLU) -> 64 (ReLU + L2 norm) -> 1 (Sigmoid)
    W1 = (np.random.randn(FEAT_DIM, 128) * np.sqrt(2.0 / FEAT_DIM)).astype(np.float32)
    b1 = np.zeros(128, dtype=np.float32)
    W2 = (np.random.randn(128, 64) * np.sqrt(2.0 / 128)).astype(np.float32)
    b2 = np.zeros(64, dtype=np.float32)
    W3 = (np.random.randn(64, 1) * np.sqrt(2.0 / 64)).astype(np.float32)
    b3 = np.zeros(1, dtype=np.float32)

    lr = 0.008
    batch_size = 64
    for epoch in range(45):
        for i in range(0, N, batch_size):
            xb = X[i:i + batch_size]
            yb = Y[i:i + batch_size]
            bs = len(xb)

            # Forward
            z1 = xb @ W1 + b1
            h1 = np.maximum(0.0, z1)
            z2 = h1 @ W2 + b2
            h2_raw = np.maximum(0.0, z2)
            norms = np.linalg.norm(h2_raw, axis=1, keepdims=True) + 1e-6
            emb = h2_raw / norms
            logits = emb @ W3 + b3
            probs = 1.0 / (1.0 + np.exp(-np.clip(logits, -20.0, 20.0)))

            # Weighted BCE loss derivative (2.5x penalty on False Positives)
            weights = np.where(yb == 0.0, 2.5, 1.0).astype(np.float32)
            dlogits = (probs - yb) * weights / bs

            dW3 = emb.T @ dlogits
            db3 = np.sum(dlogits, axis=0)

            demb = dlogits @ W3.T
            dh2_raw = demb / norms
            dz2 = dh2_raw * (z2 > 0.0)
            dW2 = h1.T @ dz2
            db2 = np.sum(dz2, axis=0)

            dh1 = dz2 @ W2.T
            dz1 = dh1 * (z1 > 0.0)
            dW1 = xb.T @ dz1
            db1 = np.sum(dz1, axis=0)

            W3 -= lr * (dW3 + 1e-4 * W3)
            b3 -= lr * db3
            W2 -= lr * (dW2 + 1e-4 * W2)
            b2 -= lr * db2
            W1 -= lr * (dW1 + 1e-4 * W1)
            b1 -= lr * db1
        lr *= 0.96

    # Compute final positive & negative embedding centroids
    h1_all = np.maximum(0.0, X @ W1 + b1)
    h2_all = np.maximum(0.0, h1_all @ W2 + b2)
    emb_all = h2_all / (np.linalg.norm(h2_all, axis=1, keepdims=True) + 1e-6)
    pos_mask = (Y[:, 0] > 0.5)
    proto_pos = np.mean(emb_all[pos_mask], axis=0).astype(np.float32)
    proto_pos /= (np.linalg.norm(proto_pos) + 1e-6)
    proto_neg = np.mean(emb_all[~pos_mask], axis=0).astype(np.float32)
    proto_neg /= (np.linalg.norm(proto_neg) + 1e-6)

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "wb") as f:
        f.write(struct.pack("<II", 0x4543484F, 1))
        f.write(W1.astype("<f4").tobytes())
        f.write(b1.astype("<f4").tobytes())
        f.write(W2.astype("<f4").tobytes())
        f.write(b2.astype("<f4").tobytes())
        f.write(W3.reshape(-1).astype("<f4").tobytes())
        f.write(b3.reshape(-1).astype("<f4").tobytes())
        f.write(proto_pos.astype("<f4").tobytes())
        f.write(proto_neg.astype("<f4").tobytes())

    print(f"Exported trained neural KWS weights to {out_path} ({os.path.getsize(out_path)} bytes)")

if __name__ == "__main__":
    train_and_export("app/src/main/assets/echo_neural_kws.bin")
