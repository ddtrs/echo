package com.smartconsole.touch.ui

import android.annotation.SuppressLint
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator

/**
 * Makes a view feel like a real key: on touch it sinks (slight scale-down + moves down),
 * on release it springs back with a small overshoot. Works together with the layered
 * "raised key" backgrounds; does not consume the touch, so clicks and long-clicks still work.
 */
object PressEffect {

    @SuppressLint("ClickableViewAccessibility")
    fun attach(view: View, depthDp: Float = 2f, pressedScale: Float = 0.96f) {
        val density = view.resources.displayMetrics.density
        val sink = depthDp * density
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.animate().cancel()
                    v.animate()
                        .scaleX(pressedScale)
                        .scaleY(pressedScale)
                        .translationY(sink)
                        .setDuration(60L)
                        .setInterpolator(DecelerateInterpolator())
                        .start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().cancel()
                    v.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .translationY(0f)
                        .setDuration(260L)
                        .setInterpolator(OvershootInterpolator(2.4f))
                        .start()
                }
            }
            false
        }
    }

    fun attachAll(vararg views: View) = views.forEach { attach(it) }
}
