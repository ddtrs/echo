package com.smartconsole.touch

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognizerIntent
import android.text.InputFilter
import android.text.InputType
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.smartconsole.touch.databinding.ActivityMainBinding
import com.smartconsole.touch.network.MiTvController
import com.smartconsole.touch.network.TuyaController
import com.smartconsole.touch.ui.PressEffect
import com.smartconsole.touch.ui.TouchClickpadView
import com.smartconsole.touch.voice.VoiceAssistantEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    enum class ConsoleMode {
        TV_REMOTE,
        LIGHT_STRIP,
        LIGHT_SCONCE
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var miTvController: MiTvController
    private val tuyaController = TuyaController()
    private var voiceEngine: VoiceAssistantEngine? = null

    private var clockAndStatusJob: Job? = null
    private var colorSendDebounceJob: Job? = null
    private var neonPulseAnimator: ObjectAnimator? = null
    private var lastColorSentAtMs: Long = 0L

    private var currentMode: ConsoleMode = ConsoleMode.TV_REMOTE
    private var isHubOpen: Boolean = false

    // Tuya state
    private var isStripOn: Boolean = true
    private var isSconceOn: Boolean = false
    private var currentHue: Float = 271f
    private var currentSatPercent: Int = 95
    private var currentBrightPercent: Int = 100
    private var activePreset: TuyaController.LightPreset? = TuyaController.LightPreset.VIOLET

    private val timeFormat = SimpleDateFormat("HH:mm", Locale("ru", "RU"))
    private val dateFormat = SimpleDateFormat("EE · d MMM", Locale("ru", "RU"))

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) {
                val pct = (level * 100) / scale
                updateBatteryAmbientUi(pct)
            }
        }
    }

    private val speechDialogLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = matches?.firstOrNull()?.trim().orEmpty()
            if (spokenText.isNotEmpty()) {
                animateTopNeonVoiceLine(true)
                voiceEngine?.handleRecognizedCommand(spokenText, fromDirectTap = true)
                binding.root.postDelayed({ animateTopNeonVoiceLine(false) }, 800L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        miTvController = MiTvController(context = this, initialIp = "192.168.0.3", tvPort = 8765)

        lockImmersiveFullscreen()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        setupTopPowerAndPairingActions()
        setupTvClickpadAndButtons()
        setupLightColorWheelAndSliders()
        setupBottomSwipeHubDrawer()
        setupVoiceIslandFallback()
        setupPressEffects()
        setupBackendCallbacks()
        startClockAndTvPolling()
        checkAudioPermissionAndStartVoiceEngine()
    }

    private fun setupPressEffects() {
        PressEffect.attachAll(
            binding.btnBack, binding.btnHome, binding.btnPlayPause,
            binding.btnQuickTvSettings, binding.btnQuickYoutube, binding.btnQuickKick, binding.btnQuickBrowser,
            binding.btnTvPowerToggle,
            binding.cardHubTv, binding.cardHubStrip, binding.cardHubSconce
        )
    }

    private var lastErrorToastAtMs = 0L
    private var pairingDialogShowing = false

    /** Tuya errors become visible (throttled) and Google Remote pairing is offered when needed. */
    private fun setupBackendCallbacks() {
        tuyaController.onError = { message ->
            runOnUiThread {
                val now = System.currentTimeMillis()
                if (now - lastErrorToastAtMs > 5000L) {
                    lastErrorToastAtMs = now
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                }
            }
        }
        miTvController.onPairingRequired = { runOnUiThread { showPairingFlow() } }

        lifecycleScope.launch { tuyaController.warmUp() }
        lifecycleScope.launch { miTvController.warmUpRemote() }
    }

    private fun showPairingFlow() {
        if (pairingDialogShowing || isFinishing || isDestroyed) return
        pairingDialogShowing = true
        AlertDialog.Builder(this)
            .setTitle("Сопряжение с ТВ")
            .setMessage("Кнопки работают через Google Remote. Один раз нужно сопрячься: на экране ТВ появится код из 6 символов.")
            .setPositiveButton("Показать код на ТВ") { _, _ -> startPairingOnTv() }
            .setNegativeButton("Позже") { _, _ -> pairingDialogShowing = false }
            .setOnCancelListener { pairingDialogShowing = false }
            .show()
    }

    private fun startPairingOnTv() {
        lifecycleScope.launch {
            val started = miTvController.beginPairing()
            if (!started) {
                pairingDialogShowing = false
                Toast.makeText(
                    this@MainActivity,
                    "ТВ не отвечает на сопряжение. Он включён и в той же Wi-Fi сети?",
                    Toast.LENGTH_LONG
                ).show()
                return@launch
            }
            val input = EditText(this@MainActivity).apply {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                filters = arrayOf(InputFilter.LengthFilter(6))
                hint = "Код с экрана ТВ"
            }
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Введите код с экрана ТВ")
                .setView(input)
                .setCancelable(false)
                .setPositiveButton("Подтвердить") { _, _ ->
                    lifecycleScope.launch {
                        val ok = miTvController.finishPairing(input.text.toString())
                        pairingDialogShowing = false
                        Toast.makeText(
                            this@MainActivity,
                            if (ok) "ТВ сопряжён" else "Неверный код. Попробуйте снова через долгое нажатие на кнопку ТВ.",
                            Toast.LENGTH_LONG
                        ).show()
                        if (ok) miTvController.warmUpRemote()
                    }
                }
                .setNegativeButton("Отмена") { _, _ ->
                    miTvController.remote.closePairing()
                    pairingDialogShowing = false
                }
                .show()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            lockImmersiveFullscreen()
        }
    }

    private fun lockImmersiveFullscreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                )
        }
    }

    private fun updateBatteryAmbientUi(percent: Int) {
        val clamped = percent.coerceIn(1, 100)
        binding.tvBatterySubtle.text = "$clamped%"
        binding.batteryAmbientBarTrack.post {
            val totalWidth = binding.batteryAmbientBarTrack.width
            if (totalWidth > 0) {
                val params = binding.batteryAmbientBarFill.layoutParams
                params.width = (totalWidth * clamped) / 100
                binding.batteryAmbientBarFill.layoutParams = params
            }
        }
    }

    /**
     * Top-right button:
     * - Short tap -> Toggles TV Power (`POWER` keycode 26)
     * - Long press -> Opens network auto-scan / manual IP dialog
     */
    private fun setupTopPowerAndPairingActions() {
        binding.btnTvPowerToggle.setOnClickListener { view ->
            performLightHaptic(view)
            lifecycleScope.launch {
                miTvController.toggleTvPower()
                delay(400L)
                val status = miTvController.pollScreenStatus()
                updatePowerPillUi(status.isReachable && status.isInteractive)
                status.volumePercent?.let { tvVol ->
                    binding.touchClickpad.volumePercent = tvVol
                }
            }
        }

        binding.btnTvPowerToggle.setOnLongClickListener { view ->
            performLightHaptic(view)
            showManualIpDialog()
            true
        }
    }

    private fun showManualIpDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_PHONE
            setText(miTvController.tvIp)
            setSelection(text.length)
        }
        AlertDialog.Builder(this)
            .setTitle("Гибридное сопряжение с ТВ (${miTvController.tvIp})")
            .setMessage("mDNS и автопоиск находят Mi TV Stick автоматически. При необходимости укажите IP вручную:")
            .setView(input)
            .setPositiveButton("Сохранить") { _, _ ->
                val entered = input.text.toString().trim()
                if (entered.isNotEmpty()) {
                    miTvController.setManualIp(entered)
                }
            }
            .setNeutralButton("Найти ТВ") { _, _ ->
                lifecycleScope.launch {
                    val found = miTvController.forceScanSubnet()
                    if (found != null) {
                        updatePowerPillUi(true)
                        Toast.makeText(this@MainActivity, "Подключено к ТВ: $found", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Сопряжение") { _, _ ->
                pairingDialogShowing = false
                showPairingFlow()
            }
            .show()
    }

    private fun setupVoiceIslandFallback() {
        binding.neonVoiceContainer.setOnClickListener { view ->
            performLightHaptic(view)
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.voice_dialog_prompt))
                }
                speechDialogLauncher.launch(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "Голосовой ввод недоступен", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Sets up the 222dp TouchClickpadView (with Rotary Volume Jog Dial) and buttons.
     */
    private fun setupTvClickpadAndButtons() {
        binding.touchClickpad.onZonePressedHaptic = {
            performLightHaptic(binding.touchClickpad)
        }

        // Directional taps + Center OK
        binding.touchClickpad.onZoneClicked = { zone ->
            lifecycleScope.launch {
                when (zone) {
                    TouchClickpadView.Zone.UP -> miTvController.sendKey(MiTvController.TvKey.DPAD_UP)
                    TouchClickpadView.Zone.DOWN -> miTvController.sendKey(MiTvController.TvKey.DPAD_DOWN)
                    TouchClickpadView.Zone.LEFT -> miTvController.sendKey(MiTvController.TvKey.DPAD_LEFT)
                    TouchClickpadView.Zone.RIGHT -> miTvController.sendKey(MiTvController.TvKey.DPAD_RIGHT)
                    TouchClickpadView.Zone.CENTER -> miTvController.sendKey(MiTvController.TvKey.DPAD_CENTER)
                    TouchClickpadView.Zone.NONE -> {}
                }
            }
        }

        // Rotary Jog Dial Volume (+1 = Clockwise Vol Up, -1 = Counter-Clockwise Vol Down)
        binding.touchClickpad.onVolumeRotaryStep = { direction ->
            val step = if (direction > 0) 7 else -7
            binding.touchClickpad.volumePercent = (binding.touchClickpad.volumePercent + step).coerceIn(0, 100)
            lifecycleScope.launch {
                if (direction > 0) {
                    miTvController.sendKey(MiTvController.TvKey.VOLUME_UP)
                } else {
                    miTvController.sendKey(MiTvController.TvKey.VOLUME_DOWN)
                }
            }
        }

        // Row under disc: 1. [Wi-Fi | Sliders] TV Control Panel, 2. YouTube, 3. Kick, 4. Browser
        bindRemoteAction(binding.btnQuickTvSettings) {
            miTvController.openTvControlPanel()
        }
        bindRemoteAction(binding.btnQuickYoutube) {
            miTvController.launchApp(MiTvController.TvApp.YOUTUBE)
        }
        bindRemoteAction(binding.btnQuickKick) {
            miTvController.launchApp(MiTvController.TvApp.KICK)
        }
        bindRemoteAction(binding.btnQuickBrowser) {
            miTvController.launchApp(MiTvController.TvApp.BROWSER)
        }

        // 3 Lifted Matte Capsules: Back, Home, Play/Pause
        bindRemoteAction(binding.btnBack) { miTvController.sendKey(MiTvController.TvKey.BACK) }
        bindRemoteAction(binding.btnHome) { miTvController.sendKey(MiTvController.TvKey.HOME) }
        bindRemoteAction(binding.btnPlayPause) { miTvController.sendKey(MiTvController.TvKey.PLAY_PAUSE) }
    }

    private fun bindRemoteAction(target: View, action: suspend () -> Unit) {
        target.setOnClickListener { view ->
            performLightHaptic(view)
            lifecycleScope.launch {
                action()
            }
        }
    }

    /**
     * Sets up Mode B: Tuya Color Wheel + Brightness & Saturation SeekBars (Zero Cloud Spam!).
     */
    private fun setupLightColorWheelAndSliders() {
        renderColorPresetSwatches()

        binding.tuyaColorWheel.hue = currentHue
        binding.tuyaColorWheel.saturation = currentSatPercent / 100f
        binding.tuyaColorWheel.brightness = currentBrightPercent / 100f

        binding.tuyaColorWheel.onHapticTick = {
            performLightHaptic(binding.tuyaColorWheel)
        }

        binding.tuyaColorWheel.onCenterPowerToggle = {
            val targetDevice = activeLightDeviceId()
            if (currentMode == ConsoleMode.LIGHT_SCONCE) {
                isSconceOn = !isSconceOn
                binding.tuyaColorWheel.isLightOn = isSconceOn
                updateHubCardsUi()
                tuyaController.requestPower(lifecycleScope, targetDevice, isSconceOn)
            } else {
                isStripOn = !isStripOn
                binding.tuyaColorWheel.isLightOn = isStripOn
                updateHubCardsUi()
                tuyaController.requestPower(lifecycleScope, targetDevice, isStripOn)
            }
        }

        // Only send network command when finger is released (isFinal == true) or throttled >= 500ms
        binding.tuyaColorWheel.onHueChanged = { newHue, isFinal ->
            currentHue = newHue
            activePreset = null
            renderColorPresetSwatches()
            if (currentMode == ConsoleMode.LIGHT_SCONCE) isSconceOn = true else isStripOn = true
            updateHubCardsUi()
            dispatchLightHsvUpdate(isFinal = isFinal)
        }

        binding.seekLightBrightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val clamped = progress.coerceAtLeast(1)
                currentBrightPercent = clamped
                binding.tvBrightnessPercent.text = "$clamped%"
                binding.tuyaColorWheel.brightness = clamped / 100f
                if (fromUser) dispatchLightHsvUpdate(isFinal = false)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                performLightHaptic(binding.seekLightBrightness)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                dispatchLightHsvUpdate(isFinal = true)
            }
        })

        binding.seekLightSaturation.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val clamped = progress.coerceAtLeast(5)
                currentSatPercent = clamped
                binding.tvSaturationPercent.text = "$clamped%"
                binding.tuyaColorWheel.saturation = clamped / 100f
                if (fromUser) dispatchLightHsvUpdate(isFinal = false)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                performLightHaptic(binding.seekLightSaturation)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                dispatchLightHsvUpdate(isFinal = true)
            }
        })

        val presetMap = listOf(
            binding.presetCyber to TuyaController.LightPreset.CYBER,
            binding.presetSapphire to TuyaController.LightPreset.SAPPHIRE,
            binding.presetViolet to TuyaController.LightPreset.VIOLET,
            binding.presetRaspberry to TuyaController.LightPreset.RASPBERRY,
            binding.presetSunset to TuyaController.LightPreset.SUNSET,
            binding.presetWarm to TuyaController.LightPreset.WARM
        )

        presetMap.forEach { (container, preset) ->
            container.setOnClickListener { view ->
                performLightHaptic(view)
                applyPresetToUiAndDevice(preset)
            }
        }
    }

    private fun applyPresetToUiAndDevice(preset: TuyaController.LightPreset) {
        activePreset = preset
        currentHue = preset.hue.toFloat()
        currentSatPercent = (preset.satPromille / 10).coerceIn(5, 100)
        currentBrightPercent = (preset.valPromille / 10).coerceIn(1, 100)

        binding.tuyaColorWheel.hue = currentHue
        binding.tuyaColorWheel.saturation = currentSatPercent / 100f
        binding.tuyaColorWheel.brightness = currentBrightPercent / 100f
        binding.tuyaColorWheel.isLightOn = true

        binding.seekLightBrightness.progress = currentBrightPercent
        binding.tvBrightnessPercent.text = "$currentBrightPercent%"
        binding.seekLightSaturation.progress = currentSatPercent
        binding.tvSaturationPercent.text = "$currentSatPercent%"

        if (currentMode == ConsoleMode.LIGHT_SCONCE) isSconceOn = true else isStripOn = true
        updateHubCardsUi()
        renderColorPresetSwatches()

        tuyaController.requestPreset(lifecycleScope, activeLightDeviceId(), preset)
        if (currentMode == ConsoleMode.LIGHT_STRIP) {
            lifecycleScope.launch {
                miTvController.syncLightToTv(
                    power = true,
                    presetName = preset.titleRu,
                    bright = currentBrightPercent
                )
            }
        }
    }

    /**
     * Live colour control without lag: every change is handed to the conflated sender,
     * which keeps only the latest value while a request is in flight (no queue, no spam).
     */
    private fun dispatchLightHsvUpdate(isFinal: Boolean) {
        val sPromille = (currentSatPercent * 10).coerceIn(10, 1000)
        val vPromille = (currentBrightPercent * 10).coerceIn(10, 1000)
        tuyaController.requestHsv(
            lifecycleScope, activeLightDeviceId(), currentHue.toInt(), sPromille, vPromille
        )
        if (isFinal && currentMode == ConsoleMode.LIGHT_STRIP) {
            val presetTitle = activePreset?.titleRu
            lifecycleScope.launch {
                miTvController.syncLightToTv(
                    power = true,
                    presetName = presetTitle,
                    bright = currentBrightPercent,
                    hue = currentHue.toInt(),
                    sat = currentSatPercent
                )
            }
        }
    }

    /** Applies an arbitrary colour set by the voice assistant to the on-screen controls. */
    private fun applyHsvToUi(hue: Int, satPercent: Int, brightPercent: Int) {
        currentHue = hue.toFloat()
        currentSatPercent = satPercent.coerceIn(5, 100)
        currentBrightPercent = brightPercent.coerceIn(1, 100)
        activePreset = null
        isStripOn = true
        binding.tuyaColorWheel.hue = currentHue
        binding.tuyaColorWheel.saturation = currentSatPercent / 100f
        binding.tuyaColorWheel.brightness = currentBrightPercent / 100f
        if (currentMode == ConsoleMode.LIGHT_STRIP) binding.tuyaColorWheel.isLightOn = true
        binding.seekLightBrightness.progress = currentBrightPercent
        binding.tvBrightnessPercent.text = "$currentBrightPercent%"
        binding.seekLightSaturation.progress = currentSatPercent
        binding.tvSaturationPercent.text = "$currentSatPercent%"
        renderColorPresetSwatches()
        updateHubCardsUi()
    }

    private fun activeLightDeviceId(): String {
        return if (currentMode == ConsoleMode.LIGHT_SCONCE) {
            tuyaController.sconceDeviceId
        } else {
            tuyaController.stripDeviceId
        }
    }

    private fun setupBottomSwipeHubDrawer() {
        val gestureDetector = GestureDetector(
            this,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onSingleTapUp(e: MotionEvent): Boolean {
                    openHubDrawer()
                    return true
                }

                override fun onFling(
                    e1: MotionEvent?,
                    e2: MotionEvent,
                    velocityX: Float,
                    velocityY: Float
                ): Boolean {
                    if (velocityY < -150f) {
                        openHubDrawer()
                        return true
                    }
                    return false
                }
            }
        )

        binding.bottomSwipeHandleArea.setOnTouchListener { view, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                performLightHaptic(view)
            }
            gestureDetector.onTouchEvent(event)
            true
        }

        binding.hubScrimOverlay.setOnClickListener {
            closeHubDrawer()
        }

        binding.sheetTopDragPill.setOnClickListener {
            closeHubDrawer()
        }

        binding.cardHubTv.setOnClickListener { view ->
            performLightHaptic(view)
            switchConsoleMode(ConsoleMode.TV_REMOTE)
            closeHubDrawer()
        }

        binding.cardHubStrip.setOnClickListener { view ->
            performLightHaptic(view)
            isStripOn = !isStripOn
            if (currentMode == ConsoleMode.LIGHT_STRIP) {
                binding.tuyaColorWheel.isLightOn = isStripOn
            }
            updateHubCardsUi()
            tuyaController.requestPower(lifecycleScope, tuyaController.stripDeviceId, isStripOn)
        }

        binding.cardHubStrip.setOnLongClickListener { view ->
            performLightHaptic(view)
            isStripOn = true
            switchConsoleMode(ConsoleMode.LIGHT_STRIP)
            closeHubDrawer()
            true
        }

        binding.cardHubSconce.setOnClickListener { view ->
            performLightHaptic(view)
            isSconceOn = !isSconceOn
            if (currentMode == ConsoleMode.LIGHT_SCONCE) {
                binding.tuyaColorWheel.isLightOn = isSconceOn
            }
            updateHubCardsUi()
            tuyaController.requestPower(lifecycleScope, tuyaController.sconceDeviceId, isSconceOn)
        }

        binding.cardHubSconce.setOnLongClickListener { view ->
            performLightHaptic(view)
            isSconceOn = true
            switchConsoleMode(ConsoleMode.LIGHT_SCONCE)
            closeHubDrawer()
            true
        }

        updateHubCardsUi()
    }

    private fun switchConsoleMode(newMode: ConsoleMode) {
        currentMode = newMode
        when (newMode) {
            ConsoleMode.TV_REMOTE -> {
                binding.lightControlModeContainer.visibility = View.GONE
                binding.tvRemoteModeContainer.visibility = View.VISIBLE
            }
            ConsoleMode.LIGHT_STRIP -> {
                binding.tvRemoteModeContainer.visibility = View.GONE
                binding.lightControlModeContainer.visibility = View.VISIBLE
                binding.tvActiveLightTitle.text = "SMART LED STRIP"
                binding.tuyaColorWheel.isLightOn = isStripOn
            }
            ConsoleMode.LIGHT_SCONCE -> {
                binding.tvRemoteModeContainer.visibility = View.GONE
                binding.lightControlModeContainer.visibility = View.VISIBLE
                binding.tvActiveLightTitle.text = "SMART LAMP / БРА"
                binding.tuyaColorWheel.isLightOn = isSconceOn
            }
        }
        updateHubCardsUi()
    }

    private fun openHubDrawer() {
        if (isHubOpen) return
        isHubOpen = true
        updateHubCardsUi()
        binding.hubScrimOverlay.visibility = View.VISIBLE
        binding.hubBottomSheet.visibility = View.VISIBLE

        binding.hubScrimOverlay.animate()
            .alpha(1f)
            .setDuration(200L)
            .start()

        binding.hubBottomSheet.animate()
            .translationY(0f)
            .setDuration(240L)
            .start()
    }

    private fun closeHubDrawer() {
        if (!isHubOpen) return
        isHubOpen = false

        binding.hubScrimOverlay.animate()
            .alpha(0f)
            .setDuration(180L)
            .withEndAction {
                binding.hubScrimOverlay.visibility = View.GONE
            }
            .start()

        binding.hubBottomSheet.animate()
            .translationY(420f)
            .setDuration(220L)
            .withEndAction {
                binding.hubBottomSheet.visibility = View.GONE
            }
            .start()
    }

    private fun updateHubCardsUi() {
        binding.cardHubTv.isSelected = (currentMode == ConsoleMode.TV_REMOTE)
        binding.cardHubStrip.isSelected = (currentMode == ConsoleMode.LIGHT_STRIP)
        binding.cardHubSconce.isSelected = (currentMode == ConsoleMode.LIGHT_SCONCE)

        binding.tvHubTvSub.text = if (currentMode == ConsoleMode.TV_REMOTE) "На экране" else "Выбрать"
        binding.tvHubTvSub.setTextColor(
            ContextCompat.getColor(
                this,
                if (currentMode == ConsoleMode.TV_REMOTE) R.color.preset_cyber else R.color.text_secondary
            )
        )

        binding.tvHubStripSub.text = if (isStripOn) "ВКЛ · Зажми" else "ВЫКЛ · Зажми"
        binding.tvHubStripSub.setTextColor(
            ContextCompat.getColor(
                this,
                if (isStripOn) R.color.status_online else R.color.text_secondary
            )
        )

        binding.tvHubSconceSub.text = if (isSconceOn) "ВКЛ · Зажми" else "ВЫКЛ · Зажми"
        binding.tvHubSconceSub.setTextColor(
            ContextCompat.getColor(
                this,
                if (isSconceOn) R.color.status_online else R.color.text_secondary
            )
        )
    }

    private fun renderColorPresetSwatches() {
        val swatches = listOf(
            binding.swatchCyber to TuyaController.LightPreset.CYBER,
            binding.swatchSapphire to TuyaController.LightPreset.SAPPHIRE,
            binding.swatchViolet to TuyaController.LightPreset.VIOLET,
            binding.swatchRaspberry to TuyaController.LightPreset.RASPBERRY,
            binding.swatchSunset to TuyaController.LightPreset.SUNSET,
            binding.swatchWarm to TuyaController.LightPreset.WARM
        )

        val density = resources.displayMetrics.density
        swatches.forEach { (view, preset) ->
            val isSelected = (preset == activePreset)
            val drawable = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(preset.previewHexColor)
                if (isSelected) {
                    setStroke((2.5f * density).toInt(), Color.WHITE)
                } else {
                    setStroke((1f * density).toInt(), Color.parseColor("#33FFFFFF"))
                }
            }
            view.background = drawable
            view.scaleX = if (isSelected) 1.15f else 1.0f
            view.scaleY = if (isSelected) 1.15f else 1.0f
        }
    }

    private fun updatePowerPillUi(isOnline: Boolean) {
        val colorRes = if (isOnline) R.color.status_online else R.color.status_sleeping
        val resolvedColor = ContextCompat.getColor(this, colorRes)
        (binding.statusDotView.background as? GradientDrawable)?.setColor(resolvedColor)
        binding.tvPowerStatusLabel.text = getString(
            if (isOnline) R.string.tv_power_on else R.string.tv_power_sleep
        )
    }

    private fun startClockAndTvPolling() {
        clockAndStatusJob?.cancel()
        clockAndStatusJob = lifecycleScope.launch {
            while (isActive) {
                val now = Date()
                binding.tvClock.text = timeFormat.format(now)
                binding.tvDate.text = dateFormat.format(now).uppercase(Locale("ru", "RU"))

                val status = miTvController.pollScreenStatus()
                updatePowerPillUi(status.isReachable && status.isInteractive)

                delay(3000L)
            }
        }
    }

    private fun animateTopNeonVoiceLine(active: Boolean) {
        runOnUiThread {
            if (active) {
                if (neonPulseAnimator == null) {
                    val alphaHolder = PropertyValuesHolder.ofFloat(View.ALPHA, 0.35f, 1.0f)
                    val scaleXHolder = PropertyValuesHolder.ofFloat(View.SCALE_X, 0.7f, 1.35f)
                    neonPulseAnimator = ObjectAnimator.ofPropertyValuesHolder(
                        binding.neonVoiceLine,
                        alphaHolder,
                        scaleXHolder
                    ).apply {
                        duration = 480L
                        repeatCount = ObjectAnimator.INFINITE
                        repeatMode = ObjectAnimator.REVERSE
                    }
                }
                if (neonPulseAnimator?.isRunning != true) {
                    neonPulseAnimator?.start()
                }
            } else {
                neonPulseAnimator?.cancel()
                binding.neonVoiceLine.animate()
                    .alpha(0.28f)
                    .scaleX(1.0f)
                    .setDuration(220L)
                    .start()
            }
        }
    }

    private fun checkAudioPermissionAndStartVoiceEngine() {
        initVoiceEngine()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                1001
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            initVoiceEngine()
        }
    }

    private fun initVoiceEngine() {
        voiceEngine?.stop()
        voiceEngine = VoiceAssistantEngine(
            context = this,
            scope = lifecycleScope,
            miTvController = miTvController,
            tuyaController = tuyaController,
            onVoiceActivityChanged = { active -> animateTopNeonVoiceLine(active) },
            onWakeWordTriggeredHaptic = {
                runOnUiThread { performLightHaptic(binding.neonVoiceContainer) }
            },
            onLocalPresetChanged = { preset ->
                runOnUiThread {
                    applyPresetToUiAndDevice(preset)
                }
            },
            onLocalStripPowerChanged = { enabled ->
                runOnUiThread {
                    isStripOn = enabled
                    binding.tuyaColorWheel.isLightOn = enabled
                    updateHubCardsUi()
                }
            },
            getLightState = { intArrayOf(currentHue.toInt(), currentSatPercent, currentBrightPercent) },
            onLocalColorChanged = { h, sat, bright ->
                runOnUiThread { applyHsvToUi(h, sat, bright) }
            }
        ).also { it.start() }
    }

    private fun performLightHaptic(view: View) {
        view.performHapticFeedback(
            HapticFeedbackConstants.KEYBOARD_TAP,
            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
        )
        try {
            val vibrator = getSystemService(Vibrator::class.java)
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(14L, 90))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(14L)
                }
            }
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(batteryReceiver)
        } catch (_: Exception) {
        }
        clockAndStatusJob?.cancel()
        colorSendDebounceJob?.cancel()
        miTvController.stopMdnsAutoDiscovery()
        voiceEngine?.stop()
        super.onDestroy()
    }
}
