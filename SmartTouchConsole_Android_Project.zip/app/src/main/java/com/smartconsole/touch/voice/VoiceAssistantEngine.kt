package com.smartconsole.touch.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import com.smartconsole.touch.network.MiTvController
import com.smartconsole.touch.network.TuyaController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Multi-Language Voice Engine with "Эхо" / "Echo" Hotword Wake-Up:
 * - Understands Russian, Ukrainian, and English commands seamlessly.
 * - In background mode, listens for the wake word "Эхо" / "Ехо" / "Echo":
 *   - Saying "Эхо, включи сапфировый свет" or "Эхо, открой YouTube" triggers immediately.
 *   - Saying just "Эхо" activates an 8-second active command window (glowing top neon line)
 *     so the next phrase is executed without needing to repeat "Эхо".
 * - When triggered manually via tap on the top neon line, executes the command directly.
 */
class VoiceAssistantEngine(
    private val context: Context,
    private val scope: CoroutineScope,
    private val miTvController: MiTvController,
    private val tuyaController: TuyaController,
    private val onVoiceActivityChanged: (Boolean) -> Unit,
    private val onWakeWordTriggeredHaptic: () -> Unit,
    private val onLocalPresetChanged: (TuyaController.LightPreset) -> Unit,
    private val onLocalStripPowerChanged: (Boolean) -> Unit,
    /** Returns the current strip state as [hue 0..360, saturation %, brightness %]. */
    private val getLightState: () -> IntArray,
    /** Called after the assistant sets an arbitrary colour: (hue, saturation %, brightness %). */
    private val onLocalColorChanged: (Int, Int, Int) -> Unit
) : TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isListening = false
    private var isDestroyed = false
    private var armedUntilMs: Long = 0L
    private val mainHandler = Handler(Looper.getMainLooper())

    private val wakeWords = listOf("эхо", "ехо", "екхо", "echo", "eho")

    private val recognizerIntent: Intent by lazy {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            // Multi-language support: uses device default + understands RU / UK / EN
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
        }
    }

    fun start() {
        if (isDestroyed) return
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
        initSpeechRecognizer()
        startListeningLoop()
    }

    fun stop() {
        isDestroyed = true
        isListening = false
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.destroy()
        speechRecognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ru", "RU")
        }
    }

    private fun initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}

                    override fun onBeginningOfSpeech() {
                        if (System.currentTimeMillis() < armedUntilMs) {
                            onVoiceActivityChanged(true)
                        }
                    }

                    override fun onRmsChanged(rmsdB: Float) {}

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                        // Fast seamless restart so background listener never dies
                        val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200L else 450L
                        scheduleRestart(delay)
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spokenText = matches?.firstOrNull()?.trim().orEmpty()
                        if (spokenText.isNotEmpty()) {
                            processBackgroundSpeech(spokenText)
                        } else if (System.currentTimeMillis() >= armedUntilMs) {
                            onVoiceActivityChanged(false)
                        }
                        scheduleRestart(250L)
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            ?.lowercase(Locale.ROOT)
                            .orEmpty()
                        if (partial.isNotBlank() && containsWakeWord(partial)) {
                            onVoiceActivityChanged(true)
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        } catch (_: Exception) {
            speechRecognizer = null
        }
    }

    private fun startListeningLoop() {
        if (isDestroyed || isListening || speechRecognizer == null) return
        try {
            isListening = true
            speechRecognizer?.startListening(recognizerIntent)
        } catch (_: Exception) {
            isListening = false
            scheduleRestart(1000L)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (isDestroyed || speechRecognizer == null) return
        mainHandler.postDelayed({ startListeningLoop() }, delayMs)
    }

    private fun containsWakeWord(lowerText: String): Boolean {
        return wakeWords.any { w ->
            lowerText == w ||
                lowerText.startsWith("$w ") ||
                lowerText.startsWith("$w,") ||
                lowerText.contains(" $w ")
        }
    }

    private fun stripWakeWord(rawText: String): String {
        var result = rawText.trim()
        for (w in wakeWords) {
            val regex = Regex("(?i)^$w[,\\s]*")
            if (regex.containsMatchIn(result)) {
                result = result.replaceFirst(regex, "").trim()
            }
        }
        return result
    }

    private fun processBackgroundSpeech(spokenText: String) {
        val now = System.currentTimeMillis()
        val lower = spokenText.lowercase(Locale.ROOT)
        val hasWake = containsWakeWord(lower)

        if (hasWake) {
            onWakeWordTriggeredHaptic()
            onVoiceActivityChanged(true)
            val commandPart = stripWakeWord(spokenText)
            if (commandPart.isNotEmpty()) {
                armedUntilMs = 0L
                handleRecognizedCommand(commandPart, fromDirectTap = false)
                mainHandler.postDelayed({ onVoiceActivityChanged(false) }, 900L)
            } else {
                // User said just "Эхо!" -> arm active listening window for 8 seconds
                armedUntilMs = now + 8000L
                speak("Слушаю")
            }
        } else if (now < armedUntilMs) {
            // Already armed after "Эхо"
            armedUntilMs = 0L
            handleRecognizedCommand(spokenText, fromDirectTap = false)
            mainHandler.postDelayed({ onVoiceActivityChanged(false) }, 900L)
        }
    }

    /**
     * Executes a recognized voice command in RU, UA, or EN.
     */
    fun handleRecognizedCommand(spokenText: String, fromDirectTap: Boolean = true) {
        val cleaned = if (fromDirectTap) stripWakeWord(spokenText).ifEmpty { spokenText } else spokenText
        val lower = cleaned.lowercase(Locale.ROOT)
        val tvStatus = miTvController.lastKnownStatus

        // Check if command is explicitly a smart-light command first (works regardless of TV state)
        if (tryHandleSmartLightCommand(lower)) {
            return
        }

        if (tvStatus.isReachable && tvStatus.isInteractive) {
            scope.launch {
                miTvController.forwardVoiceCommandToTv(cleaned)
            }
        } else {
            scope.launch {
                when {
                    lower.contains("youtube") || lower.contains("ютуб") -> {
                        miTvController.launchApp(MiTvController.TvApp.YOUTUBE)
                        speak("Запускаю YouTube")
                    }
                    lower.contains("kick") || lower.contains("кик") || lower.contains("кік") -> {
                        miTvController.launchApp(MiTvController.TvApp.KICK)
                        speak("Запускаю Kick")
                    }
                    lower.contains("браузер") || lower.contains("browser") -> {
                        miTvController.launchApp(MiTvController.TvApp.BROWSER)
                        speak("Открываю браузер")
                    }
                    else -> {
                        miTvController.forwardVoiceCommandToTv(cleaned)
                    }
                }
            }
        }
    }

    private class NamedColor(val keys: List<String>, val hue: Int, val sat: Int, val say: String)

    private val namedColors = listOf(
        NamedColor(listOf("красн", "червон", "red"), 0, 100, "Красный свет"),
        NamedColor(listOf("жёлт", "желт", "жовт", "yellow"), 55, 100, "Жёлтый свет"),
        NamedColor(listOf("зелён", "зелен", "зелен", "green"), 125, 100, "Зелёный свет"),
        NamedColor(listOf("бирюз", "циан", "cyan"), 175, 100, "Бирюзовый свет"),
        NamedColor(listOf("голуб", "блакит", "light blue"), 197, 100, "Голубой свет"),
        NamedColor(listOf("белый", "біл", "white"), 0, 8, "Белый свет")
    )

    private fun tryHandleSmartLightCommand(lower: String): Boolean {
        val strip = tuyaController.stripDeviceId
        val mentionsLight = lower.contains("свет") || lower.contains("світл") || lower.contains("лент") ||
            lower.contains("light") || lower.contains("подсвет") || lower.contains("підсвіт")

        // 1. Power
        if (lower.contains("выключи свет") || lower.contains("выключи ленту") ||
            lower.contains("вимкни світло") || lower.contains("turn off light") ||
            lower.contains("выключи подсветку") || lower.contains("вимкни підсвітку")
        ) {
            tuyaController.requestPower(scope, strip, false)
            onLocalStripPowerChanged(false)
            speak("Подсветка выключена")
            return true
        }
        if (lower.contains("включи свет") || lower.contains("включи ленту") ||
            lower.contains("увімкни світло") || lower.contains("turn on light") ||
            lower.contains("включи подсветку") || lower.contains("увімкни підсвітку")
        ) {
            tuyaController.requestPower(scope, strip, true)
            onLocalStripPowerChanged(true)
            speak("Включаю подсветку")
            return true
        }

        // 2. Brightness: "яркость 40", "свет на 50 процентов", "ярче", "темнее"
        val state = getLightState()
        val percent = Regex("(\\d{1,3})\\s*(%|процент|відсот|percent)").find(lower)?.groupValues?.get(1)?.toIntOrNull()
            ?: Regex("(яркость|яскравість|brightness)\\s*(на|до|to)?\\s*(\\d{1,3})").find(lower)?.groupValues?.get(3)?.toIntOrNull()
        if (percent != null && (mentionsLight || lower.contains("яркост") || lower.contains("яскрав") || lower.contains("bright"))) {
            val v = percent.coerceIn(1, 100)
            applyColor(state[0], state[1], v, "Яркость $v процентов")
            return true
        }
        if (lower.contains("ярче") || lower.contains("яскравіше") || lower.contains("brighter") || lower.contains("прибавь свет")) {
            applyColor(state[0], state[1], (state[2] + 25).coerceAtMost(100), "Ярче")
            return true
        }
        if (lower.contains("темнее") || lower.contains("темніше") || lower.contains("тусклее") ||
            lower.contains("dimmer") || lower.contains("приглуши")
        ) {
            applyColor(state[0], state[1], (state[2] - 25).coerceAtLeast(5), "Темнее")
            return true
        }

        // 3. Named presets (also move the on-screen wheel)
        val presets = listOf(
            listOf("тёпл", "тепл", "warm") to TuyaController.LightPreset.WARM,
            listOf("кибер", "кібер", "cyber") to TuyaController.LightPreset.CYBER,
            listOf("сапфир", "синий", "синій", "blue") to TuyaController.LightPreset.SAPPHIRE,
            listOf("фиолет", "фіолет", "purple", "violet") to TuyaController.LightPreset.VIOLET,
            listOf("малин", "розов", "рожев", "pink") to TuyaController.LightPreset.RASPBERRY,
            listOf("закат", "оранж", "sunset", "orange") to TuyaController.LightPreset.SUNSET
        )
        // "голубой" must not be caught by the "синий/blue" preset
        val lightBlue = lower.contains("голуб") || lower.contains("блакит") || lower.contains("light blue")
        if (!lightBlue) {
            for ((keys, preset) in presets) {
                if (keys.any { lower.contains(it) }) {
                    onLocalPresetChanged(preset) // UI applies it and sends the command
                    speak(preset.titleRu)
                    return true
                }
            }
        }

        // 4. Free colours
        for (c in namedColors) {
            if (c.keys.any { lower.contains(it) }) {
                applyColor(c.hue, c.sat, state[2].coerceAtLeast(60), c.say)
                return true
            }
        }
        return false
    }

    private fun applyColor(hue: Int, satPercent: Int, brightPercent: Int, say: String) {
        tuyaController.requestHsv(scope, tuyaController.stripDeviceId, hue, satPercent * 10, brightPercent * 10)
        onLocalColorChanged(hue, satPercent, brightPercent)
        speak(say)
    }

    private fun speak(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "console_tts")
    }
}
