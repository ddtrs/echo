package com.smartconsole.touch.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * Ergonomic Brushed-Metal Touch Clickpad View (220dp) with Bang & Olufsen Mechanical Knurled Bezel:
 * 1. Tapping the 4 outer sectors -> UP, DOWN, LEFT, RIGHT navigation with 3D mechanical tilt.
 * 2. Tapping the center circle -> OK / Enter with tactile spring depression.
 * 3. Rotating your thumb in a circle along the outer ring -> rotates the precision knurled bezel
 *    while keeping the 4 directional chevrons stationary, displaying the exact volume % in the center.
 */
class TouchClickpadView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class Zone { NONE, CENTER, UP, DOWN, LEFT, RIGHT }

    var onZoneClicked: ((Zone) -> Unit)? = null
    var onZonePressedHaptic: (() -> Unit)? = null
    var onVolumeRotaryStep: ((Int) -> Unit)? = null // +1 for Vol Up (CW), -1 for Vol Down (CCW)

    var volumePercent: Int = 50
        set(value) {
            field = value.coerceIn(0, 100)
            invalidate()
        }

    private var activeZone: Zone = Zone.NONE
    private var isRotatingVolume: Boolean = false
    private var lastTouchAngleDeg: Float = 0f
    private var accumulatedRotationDeg: Float = 0f
    private var bezelRotationDeg: Float = 0f
    private var currentRotaryIndicatorDeg: Float = 0f

    private val outerRect = RectF()
    private val rotaryArcRect = RectF()

    private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = Color.parseColor("#2AFFFFFF")
    }
    private val groovePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
        color = Color.parseColor("#14FFFFFF")
    }
    private val bezelTickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val rotaryGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#B300F0FF")
    }
    private val rotaryDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val centerBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        color = Color.parseColor("#38FFFFFF")
    }
    private val chevronPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4.5f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.parseColor("#B8C0D4")
    }
    private val okTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F5F7FA")
        textSize = 42f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val subTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#9900F0FF")
        textSize = 20f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    init {
        cameraDistance = 8000f * resources.displayMetrics.density
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        val r = min(cx, cy) - 6f
        outerRect.set(cx - r, cy - r, cx + r, cy + r)
        val arcR = r * 0.91f
        rotaryArcRect.set(cx - arcR, cy - arcR, cx + arcR, cy + arcR)

        discPaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(
                Color.parseColor("#141720"),
                Color.parseColor("#232838"),
                Color.parseColor("#141720"),
                Color.parseColor("#232838"),
                Color.parseColor("#141720")
            ),
            null
        )

        centerPaint.shader = RadialGradient(
            cx, cy, r * 0.40f,
            Color.parseColor("#2A3042"),
            Color.parseColor("#171A24"),
            Shader.TileMode.CLAMP
        )
        okTextPaint.textSize = r * 0.16f
        subTextPaint.textSize = r * 0.085f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val outerR = min(cx, cy) - 6f
        val centerR = outerR * 0.39f

        // 1. Base brushed metal disc + Rotating Knurled Bezel
        canvas.save()
        canvas.rotate(bezelRotationDeg, cx, cy)
        canvas.drawCircle(cx, cy, outerR, discPaint)
        canvas.drawCircle(cx, cy, outerR, borderPaint)

        // Concentric machined grooves
        canvas.drawCircle(cx, cy, outerR * 0.84f, groovePaint)
        canvas.drawCircle(cx, cy, outerR * 0.56f, groovePaint)

        // 72 precision knurled ticks along the outer bezel
        val tickOuterR = outerR * 0.955f
        for (i in 0 until 72) {
            val deg = i * 5f
            val rad = Math.toRadians(deg.toDouble())
            val isMajor = (i % 6 == 0)
            val tickInnerR = if (isMajor) outerR * 0.875f else outerR * 0.905f
            bezelTickPaint.strokeWidth = if (isMajor) 2.6f else 1.5f
            bezelTickPaint.color = if (isRotatingVolume) {
                if (isMajor) Color.parseColor("#9900F0FF") else Color.parseColor("#38FFFFFF")
            } else {
                if (isMajor) Color.parseColor("#44FFFFFF") else Color.parseColor("#1EFFFFFF")
            }
            val x1 = cx + tickInnerR * cos(rad).toFloat()
            val y1 = cy + tickInnerR * sin(rad).toFloat()
            val x2 = cx + tickOuterR * cos(rad).toFloat()
            val y2 = cy + tickOuterR * sin(rad).toFloat()
            canvas.drawLine(x1, y1, x2, y2, bezelTickPaint)
        }
        canvas.restore()

        // 2. If in rotary volume mode, draw subtle glowing cyan trail + indicator dot on rim
        if (isRotatingVolume) {
            canvas.drawArc(
                rotaryArcRect,
                currentRotaryIndicatorDeg - 22f,
                44f,
                false,
                rotaryGlowPaint
            )
            val rad = Math.toRadians(currentRotaryIndicatorDeg.toDouble())
            val dotX = cx + (outerR * 0.91f) * cos(rad).toFloat()
            val dotY = cy + (outerR * 0.91f) * sin(rad).toFloat()
            canvas.drawCircle(dotX, dotY, 5.5f, rotaryDotPaint)
        }

        // 3. Draw 4 crisp stationary vector chevrons on the ring (no cheap sector fill)
        val chevDist = outerR * 0.69f
        val chevSize = outerR * 0.065f
        drawChevron(canvas, cx, cy - chevDist, chevSize, 0f, !isRotatingVolume && activeZone == Zone.UP)
        drawChevron(canvas, cx, cy + chevDist, chevSize, 180f, !isRotatingVolume && activeZone == Zone.DOWN)
        drawChevron(canvas, cx - chevDist, cy, chevSize, 270f, !isRotatingVolume && activeZone == Zone.LEFT)
        drawChevron(canvas, cx + chevDist, cy, chevSize, 90f, !isRotatingVolume && activeZone == Zone.RIGHT)

        // 4. Center OK button with spring scale (or Volume % indicator while rotating)
        val okScale = if (!isRotatingVolume && activeZone == Zone.CENTER) 0.93f else 1.0f
        canvas.save()
        canvas.scale(okScale, okScale, cx, cy)
        canvas.drawCircle(cx, cy, centerR, centerPaint)
        centerBorderPaint.color = if (!isRotatingVolume && activeZone == Zone.CENTER) {
            Color.parseColor("#88FFFFFF")
        } else {
            Color.parseColor("#38FFFFFF")
        }
        canvas.drawCircle(cx, cy, centerR, centerBorderPaint)

        if (isRotatingVolume) {
            val pctText = "$volumePercent%"
            val mainY = cy - (okTextPaint.descent() + okTextPaint.ascent()) / 2f - (outerR * 0.04f)
            canvas.drawText(pctText, cx, mainY, okTextPaint)
            canvas.drawText("VOL", cx, mainY + (outerR * 0.13f), subTextPaint)
        } else {
            val textY = cy - (okTextPaint.descent() + okTextPaint.ascent()) / 2f
            canvas.drawText("OK", cx, textY, okTextPaint)
        }
        canvas.restore()
    }

    private fun drawChevron(
        canvas: Canvas,
        x: Float,
        y: Float,
        size: Float,
        rotationDeg: Float,
        highlighted: Boolean
    ) {
        chevronPaint.color = if (highlighted) Color.WHITE else Color.parseColor("#9BA3B8")
        chevronPaint.strokeWidth = if (highlighted) 5.5f else 4.5f
        canvas.save()
        canvas.translate(x, y)
        canvas.rotate(rotationDeg)
        val path = Path().apply {
            moveTo(-size, size * 0.45f)
            lineTo(0f, -size * 0.55f)
            lineTo(size, size * 0.45f)
        }
        canvas.drawPath(path, chevronPaint)
        canvas.restore()
    }

    private fun applyMechanicalTilt(zone: Zone) {
        val tiltDeg = 6.5f
        val (targetRotX, targetRotY, targetScale) = when (zone) {
            Zone.UP -> Triple(tiltDeg, 0f, 0.985f)
            Zone.DOWN -> Triple(-tiltDeg, 0f, 0.985f)
            Zone.LEFT -> Triple(0f, -tiltDeg, 0.985f)
            Zone.RIGHT -> Triple(0f, tiltDeg, 0.985f)
            Zone.CENTER -> Triple(0f, 0f, 0.975f)
            Zone.NONE -> Triple(0f, 0f, 1.0f)
        }
        animate()
            .rotationX(targetRotX)
            .rotationY(targetRotY)
            .scaleX(targetScale)
            .scaleY(targetScale)
            .setDuration(110L)
            .start()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val cx = width / 2f
        val cy = height / 2f
        val outerR = min(cx, cy) - 6f
        val dx = event.x - cx
        val dy = event.y - cy
        val dist = hypot(dx, dy)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (dist > outerR) return false
                activeZone = resolveZone(dx, dy, dist, outerR)
                isRotatingVolume = false
                accumulatedRotationDeg = 0f
                lastTouchAngleDeg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
                if (lastTouchAngleDeg < 0f) lastTouchAngleDeg += 360f
                currentRotaryIndicatorDeg = lastTouchAngleDeg

                applyMechanicalTilt(activeZone)
                onZonePressedHaptic?.invoke()
                invalidate()
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (activeZone == Zone.NONE && !isRotatingVolume) return false

                // Outer ring gesture -> check for circular Jog Dial rotation
                if (dist > outerR * 0.42f) {
                    var currentAngle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
                    if (currentAngle < 0f) currentAngle += 360f

                    var delta = currentAngle - lastTouchAngleDeg
                    if (delta > 180f) delta -= 360f
                    if (delta < -180f) delta += 360f

                    lastTouchAngleDeg = currentAngle
                    currentRotaryIndicatorDeg = currentAngle
                    accumulatedRotationDeg += delta

                    if (!isRotatingVolume && abs(accumulatedRotationDeg) > 15f) {
                        isRotatingVolume = true
                        activeZone = Zone.NONE
                        applyMechanicalTilt(Zone.NONE)
                    }

                    if (isRotatingVolume) {
                        bezelRotationDeg = (bezelRotationDeg + delta) % 360f
                        // Trigger 1 Volume step every 18 degrees of circular thumb travel
                        val stepThreshold = 18f
                        while (accumulatedRotationDeg >= stepThreshold) {
                            accumulatedRotationDeg -= stepThreshold
                            onZonePressedHaptic?.invoke()
                            onVolumeRotaryStep?.invoke(1) // Clockwise = Volume Up
                        }
                        while (accumulatedRotationDeg <= -stepThreshold) {
                            accumulatedRotationDeg += stepThreshold
                            onZonePressedHaptic?.invoke()
                            onVolumeRotaryStep?.invoke(-1) // Counter-Clockwise = Volume Down
                        }
                        invalidate()
                        return true
                    }
                }

                val newZone = if (dist <= outerR * 1.15f) {
                    resolveZone(dx, dy, dist, outerR)
                } else {
                    Zone.NONE
                }
                if (newZone != activeZone) {
                    activeZone = newZone
                    applyMechanicalTilt(activeZone)
                    if (activeZone != Zone.NONE) {
                        onZonePressedHaptic?.invoke()
                    }
                    invalidate()
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                if (!isRotatingVolume && activeZone != Zone.NONE) {
                    val firedZone = activeZone
                    activeZone = Zone.NONE
                    applyMechanicalTilt(Zone.NONE)
                    invalidate()
                    onZoneClicked?.invoke(firedZone)
                } else {
                    isRotatingVolume = false
                    activeZone = Zone.NONE
                    applyMechanicalTilt(Zone.NONE)
                    invalidate()
                }
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                isRotatingVolume = false
                activeZone = Zone.NONE
                applyMechanicalTilt(Zone.NONE)
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun resolveZone(dx: Float, dy: Float, dist: Float, outerR: Float): Zone {
        if (dist <= outerR * 0.39f) {
            return Zone.CENTER
        }
        val angleDeg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble()))
        return when {
            angleDeg >= -45.0 && angleDeg < 45.0 -> Zone.RIGHT
            angleDeg >= 45.0 && angleDeg < 135.0 -> Zone.DOWN
            angleDeg >= -135.0 && angleDeg < -45.0 -> Zone.UP
            else -> Zone.LEFT
        }
    }
}
