package com.smartconsole.touch.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * Ergonomic Brushed-Metal Touch Clickpad View (220dp) with Bang & Olufsen / iPod Rotary Jog Dial:
 * 1. Tapping the 4 outer sectors -> UP, DOWN, LEFT, RIGHT navigation.
 * 2. Tapping the center circle -> OK / Enter with spring animation.
 * 3. Rotating your thumb in a circle along the outer ring -> smooth rotary Volume Up (clockwise)
 *    and Volume Down (counter-clockwise) with haptic clicks every 22 degrees and a glowing arc indicator!
 */
class TouchClickpadView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class Zone { NONE, CENTER, UP, DOWN, LEFT, RIGHT }

    var onZoneClicked: ((Zone) -> Unit)? = null
    var onZonePressedHaptic: (() -> Unit)? = null
    var onVolumeRotaryStep: ((Int) -> Unit)? = null // +1 for Vol Up (CW), -1 for Vol Down (CCW)

    private var activeZone: Zone = Zone.NONE
    private var isRotatingVolume: Boolean = false
    private var lastTouchAngleDeg: Float = 0f
    private var accumulatedRotationDeg: Float = 0f
    private var currentRotaryIndicatorDeg: Float = 0f

    private val outerRect = RectF()
    private val rotaryArcRect = RectF()

    private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = Color.parseColor("#2AFFFFFF")
    }
    private val groovePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
        color = Color.parseColor("#14FFFFFF")
    }
    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#2E00F0FF")
    }
    private val rotaryGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 8f
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#CC00F0FF")
    }
    private val rotaryDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val centerBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        color = Color.parseColor("#38FFFFFF")
    }
    private val chevronPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4.5f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.parseColor("#B8C0D4")
    }
    private val okTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F5F7FA")
        textSize = 42f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        val r = min(cx, cy) - 6f
        outerRect.set(cx - r, cy - r, cx + r, cy + r)
        val arcR = r * 0.92f
        rotaryArcRect.set(cx - arcR, cy - arcR, cx + arcR, cy + arcR)

        discPaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(
                Color.parseColor("#141720"),
                Color.parseColor("#232838"),
                Color.parseColor("#141720"),
                Color.parseColor("#232838"),
                Color.parseColor("#141720")
            ),
            null
        )

        centerPaint.shader = RadialGradient(
            cx, cy, r * 0.40f,
            Color.parseColor("#2A3042"),
            Color.parseColor("#171A24"),
            Shader.TileMode.CLAMP
        )
        okTextPaint.textSize = r * 0.16f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val outerR = min(cx, cy) - 6f
        val centerR = outerR * 0.39f

        // 1. Base brushed metal disc
        canvas.drawCircle(cx, cy, outerR, discPaint)
        canvas.drawCircle(cx, cy, outerR, borderPaint)

        // Concentric machined grooves
        canvas.drawCircle(cx, cy, outerR * 0.84f, groovePaint)
        canvas.drawCircle(cx, cy, outerR * 0.68f, groovePaint)

        // 2. If in rotary volume mode, draw glowing cyan rotary trail + indicator dot
        if (isRotatingVolume) {
            canvas.drawArc(
                rotaryArcRect,
                currentRotaryIndicatorDeg - 28f,
                56f,
                false,
                rotaryGlowPaint
            )
            val rad = Math.toRadians(currentRotaryIndicatorDeg.toDouble())
            val dotX = cx + (outerR * 0.92f) * cos(rad).toFloat()
            val dotY = cy + (outerR * 0.92f) * sin(rad).toFloat()
            canvas.drawCircle(dotX, dotY, 7f, rotaryDotPaint)
        } else {
            // Highlight active directional sector when pressed
            when (activeZone) {
                Zone.RIGHT -> canvas.drawArc(outerRect, -45f, 90f, true, highlightPaint)
                Zone.DOWN -> canvas.drawArc(outerRect, 45f, 90f, true, highlightPaint)
                Zone.LEFT -> canvas.drawArc(outerRect, 135f, 90f, true, highlightPaint)
                Zone.UP -> canvas.drawArc(outerRect, 225f, 90f, true, highlightPaint)
                else -> {}
            }
        }

        // 3. Draw 4 crisp vector chevrons on the ring
        val chevDist = outerR * 0.69f
        val chevSize = outerR * 0.065f
        drawChevron(canvas, cx, cy - chevDist, chevSize, 0f, !isRotatingVolume && activeZone == Zone.UP)
        drawChevron(canvas, cx, cy + chevDist, chevSize, 180f, !isRotatingVolume && activeZone == Zone.DOWN)
        drawChevron(canvas, cx - chevDist, cy, chevSize, 270f, !isRotatingVolume && activeZone == Zone.LEFT)
        drawChevron(canvas, cx + chevDist, cy, chevSize, 90f, !isRotatingVolume && activeZone == Zone.RIGHT)

        // 4. Center OK button with spring scale (or VOL indicator while rotating)
        val okScale = if (!isRotatingVolume && activeZone == Zone.CENTER) 0.91f else 1.0f
        canvas.save()
        canvas.scale(okScale, okScale, cx, cy)
        canvas.drawCircle(cx, cy, centerR, centerPaint)
        if (!isRotatingVolume && activeZone == Zone.CENTER) {
            canvas.drawCircle(cx, cy, centerR, highlightPaint)
        }
        canvas.drawCircle(cx, cy, centerR, centerBorderPaint)

        val centerLabel = if (isRotatingVolume) "VOL" else "OK"
        val textY = cy - (okTextPaint.descent() + okTextPaint.ascent()) / 2f
        canvas.drawText(centerLabel, cx, textY, okTextPaint)
        canvas.restore()
    }

    private fun drawChevron(
        canvas: Canvas,
        x: Float,
        y: Float,
        size: Float,
        rotationDeg: Float,
        highlighted: Boolean
    ) {
        chevronPaint.color = if (highlighted) Color.WHITE else Color.parseColor("#9BA3B8")
        canvas.save()
        canvas.translate(x, y)
        canvas.rotate(rotationDeg)
        val path = Path().apply {
            moveTo(-size, size * 0.45f)
            lineTo(0f, -size * 0.55f)
            lineTo(size, size * 0.45f)
        }
        canvas.drawPath(path, chevronPaint)
        canvas.restore()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val cx = width / 2f
        val cy = height / 2f
        val outerR = min(cx, cy) - 6f
        val centerR = outerR * 0.39f

        val dx = event.x - cx
        val dy = event.y - cy
        val dist = hypot(dx, dy)
        val angleDeg = computeAngleDeg(dx, dy)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (dist > outerR * 1.08f) return false
                isRotatingVolume = false
                accumulatedRotationDeg = 0f
                lastTouchAngleDeg = angleDeg
                currentRotaryIndicatorDeg = angleDeg
                activeZone = detectZone(dx, dy, dist, centerR)
                onZonePressedHaptic?.invoke()
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                // If user moves finger along the outer ring (outside the center OK button), track circular rotation
                if (dist > centerR * 0.95f) {
                    var delta = angleDeg - lastTouchAngleDeg
                    if (delta > 180f) delta -= 360f
                    if (delta < -180f) delta += 360f

                    // Ignore wild jumps near center
                    if (abs(delta) < 45f) {
                        accumulatedRotationDeg += delta
                        currentRotaryIndicatorDeg = angleDeg
                    }
                    lastTouchAngleDeg = angleDeg

                    // Enter rotary volume mode once finger rotates >= 18 degrees
                    if (!isRotatingVolume && abs(accumulatedRotationDeg) >= 18f) {
                        isRotatingVolume = true
                        activeZone = Zone.NONE
                    }

                    // Every 20 degrees of rotation triggers 1 volume step (+1 CW / -1 CCW) + haptic click
                    val stepThreshold = 20f
                    while (accumulatedRotationDeg >= stepThreshold) {
                        accumulatedRotationDeg -= stepThreshold
                        onZonePressedHaptic?.invoke()
                        onVolumeRotaryStep?.invoke(1)
                    }
                    while (accumulatedRotationDeg <= -stepThreshold) {
                        accumulatedRotationDeg += stepThreshold
                        onZonePressedHaptic?.invoke()
                        onVolumeRotaryStep?.invoke(-1)
                    }
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                val wasRotating = isRotatingVolume
                val triggered = activeZone
                isRotatingVolume = false
                activeZone = Zone.NONE
                accumulatedRotationDeg = 0f
                invalidate()
                if (!wasRotating && triggered != Zone.NONE) {
                    onZoneClicked?.invoke(triggered)
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                isRotatingVolume = false
                activeZone = Zone.NONE
                accumulatedRotationDeg = 0f
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun computeAngleDeg(dx: Float, dy: Float): Float {
        var deg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
        if (deg < 0f) deg += 360f
        return deg
    }

    private fun detectZone(dx: Float, dy: Float, dist: Float, centerR: Float): Zone {
        if (dist <= centerR) return Zone.CENTER
        val deg = computeAngleDeg(dx, dy)
        return when {
            deg >= 315f || deg < 45f -> Zone.RIGHT
            deg >= 45f && deg < 135f -> Zone.DOWN
            deg >= 135f && deg < 225f -> Zone.LEFT
            else -> Zone.UP
        }
    }
}
